# Resolution-scaled shadow density experiment

Not accepted or integrated. Reconstruct from the archived base with:

    python3 materialize.py /path/to/beastie density /tmp/beastie-density

Build beastie-game tests under dev-perf, then run offscreen_renderer_benchmark ignored
with BEASTIE_BENCH_SIZE=low or4k and BEASTIE_BENCH_OUTPUT/BEASTIE_BENCH_PNG paths.
BEASTIE_DENSITY_CONTROL=1 restores the previous fixed1080p policy (4k uses rays).
Default candidate preserves directional-map texel density with power-of-two dimensions:
640x360 uses512 dynamic and256 static;1920x1080 uses1024/512;3840x2160 uses2048/1024.
Caps are3840x2160,2048/1024 maps (120MiB Depth16),12 array layers and a dynamic
atlas width at most the device texture limit. Cache buffers use production adaptive
sample count, including one sample at4k. Native main also accepts BENCH_SIZE to
set a matching window for scratch verification. Controls change renderer policy only.

No GPU measurements or image acceptance existed when this package was prepared.


Initial16:9 offscreen results (AppleM5Max, dev-perf,210frames,30warmup,10-frame batches):
640x360 scaled warm0.630–0.649ms versus0.709–0.737ms fixed policy,7.5MiB versus30MiB depth.
3840x2160 scaled warm5.936–5.981ms versus8.706–9.071ms ray fallback,120MiB additional depth.
All timestamp batches valid. Controls repeat pixel-exactly. Low-resolution output changes
573/230400RGBpixels versus higher-density maps;4k changes4841/8294400 versus rays.
Sparse worst differences are eyelid/eyebrow contact pixels. Reviewed stills retain broad
appearance, but motion acceptance is pending. No energy measurements or native density
performance claims. The next scratch revision uses min rather than max viewport ratio
for uniform-fit letterboxing;16:9 measurements are unchanged.


Final motion validation: optimized dev-perf test binary, 12 consecutive 16 ms
frames spanning the complete blink while the creature moves. Four same-binary
runs compare low fixed maps against scaled maps and 4K ray fallback against
scaled maps. `run-density-motion.py` records each candidate's original-ray
comparison; `analyze-density-motion.py` compares the two candidates directly.
All four GPU tests and portable translation passed. `motion-review/metrics.json`
contains paired RGB metrics. Filmstrips put control above candidate for each
six-frame block. Native-size blink/contact appearance was reviewed and accepted;
sparse shadow edge differences are visible when enlarged. Native window resize
validation is a separate remaining production gate, not claimed by this archive.

The archived source now uses min(width/1920,height/1080), matching uniform scene
fit; initial timing was measured with max on the same 16:9 sizes, where these
expressions are identical. The motion source includes actual indexed atlas draws
and the finite-distance Depth16 fallback correction. Production removes the
BEASTIE_DENSITY_CONTROL experiment flag and keeps only the existing original-ray
control. No binaries are included. Hashes identify the tested local binaries.
