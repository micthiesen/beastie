import os,subprocess,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909')
for size in ['low','4k']:
 for name,control in [('control-before',True),('scaled',False),('scaled-repeat',False),('control-after',True)]:
  env=dict(os.environ,BEASTIE_BENCH_SIZE=size,BEASTIE_BENCH_OUTPUT=str(r/f'density-{size}-{name}.json'),BEASTIE_BENCH_PNG=str(r/f'density-{size}-{name}.png'))
  if control: env['BEASTIE_DENSITY_CONTROL']='1'
  else:env.pop('BEASTIE_DENSITY_CONTROL',None)
  with (r/f'density-{size}-{name}.log').open('w') as out:
   subprocess.run([str(r/'beastie-density-test'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,cwd=r/'density-src',stdout=out,stderr=subprocess.STDOUT,check=True)
  print(size,name,'done',flush=True)
