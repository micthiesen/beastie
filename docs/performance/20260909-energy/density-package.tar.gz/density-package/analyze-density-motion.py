from PIL import Image,ImageDraw
from PIL import ImageChops,ImageStat
import json,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909'); out=r/'density-motion-review';out.mkdir(exist_ok=True)
summary={}
for size in ['low','4k']:
 rows=[]; frames=[]
 for i in range(12):
  a=Image.open(r/f'density-motion-{size}-control/{i:02}-motion-maps.png').convert('RGB'); b=Image.open(r/f'density-motion-{size}-scaled/{i:02}-motion-maps.png').convert('RGB')
  d=ImageChops.difference(a,b); values=list(d.getdata()); mx=max(max(v) for v in values); pos=next(j for j,v in enumerate(values) if max(v)==mx);x=pos%a.width;y=pos//a.width
  rows.append(dict(frame=i,different_rgb_pixels=sum(any(v) for v in values),max_rgb_difference=mx,mean_rgb_difference=sum(ImageStat.Stat(d).mean)/3,worst_xy=[x,y]))
  frames.append((a,b))
 summary[size]=rows
 # Face and floor fixed scene-relative crops, consecutive 12 frames control above candidate.
 w,h=frames[0][0].size
 for region,box in [('face',(.40,.28,.59,.43)),('floor',(.38,.53,.62,.70))]:
  box=tuple(round(v*(w if j%2==0 else h)) for j,v in enumerate(box));cw,ch=box[2]-box[0],box[3]-box[1]
  sheet=Image.new('RGB',(cw*6,ch*4+48),'#222222');dr=ImageDraw.Draw(sheet)
  for i,(a,b) in enumerate(frames):
   col=i%6;row=i//6;yy=row*(ch*2+24)
   dr.text((col*cw,yy),str(i),fill='white');sheet.paste(a.crop(box),(col*cw,yy+24));sheet.paste(b.crop(box),(col*cw,yy+24+ch))
  sheet.save(out/f'{size}-{region}-1x.png')
  if size=='low':sheet.resize((sheet.width*4,sheet.height*4),Image.Resampling.NEAREST).save(out/f'{size}-{region}-4x.png')
 # Actual worst contact crop fixed around first frame's error.
 x,y=rows[0]['worst_xy'];cw=100 if size=='low' else 240;ch=cw
 sheet=Image.new('RGB',(cw*6,ch*4+48),'#222222')
 for i,(a,b) in enumerate(frames):
  box=(x-cw//2,y-ch//2,x+cw//2,y+ch//2);col=i%6;yy=(i//6)*(ch*2+24)
  ImageDraw.Draw(sheet).text((col*cw,yy),str(i),fill='white');sheet.paste(a.crop(box),(col*cw,yy+24));sheet.paste(b.crop(box),(col*cw,yy+24+ch))
 sheet.save(out/f'{size}-worst-contact-1x.png')
 if size=='4k':sheet.resize((sheet.width*2,sheet.height*2),Image.Resampling.NEAREST).save(out/f'{size}-worst-contact-2x.png')
(out/'metrics.json').write_text(json.dumps(summary,indent=2))
for size,rows in summary.items():print(size,'pixels',min(x['different_rgb_pixels'] for x in rows),max(x['different_rgb_pixels'] for x in rows),'max',max(x['max_rgb_difference'] for x in rows),'MAE',min(x['mean_rgb_difference'] for x in rows),max(x['mean_rgb_difference'] for x in rows), 'worst',rows[0]['worst_xy'])
