import os,subprocess,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909')
for size in ['low','4k']:
 for name,control in [('control',True),('scaled',False)]:
  env=dict(os.environ,BEASTIE_BENCH_SIZE=size,BEASTIE_DENSITY_MOTION='1',BEASTIE_CACHE_ORACLE_OUTPUT=str(r/f'density-motion-{size}-{name}.json'),BEASTIE_MAP_ORACLE_CAPTURE_DIR=str(r/f'density-motion-{size}-{name}'))
  if control:env['BEASTIE_DENSITY_CONTROL']='1'
  else:env.pop('BEASTIE_DENSITY_CONTROL',None)
  with (r/f'density-motion-{size}-{name}.log').open('w') as out:
   subprocess.run([str(r/'beastie-density-motion-test'),'moving_shadow_maps_preserve_bounded_image_error','--ignored','--nocapture'],env=env,cwd=r/'density-src',stdout=out,stderr=subprocess.STDOUT,check=True)
  print(size,name,'done',flush=True)
