The water-colored strip above the top tank border is pre-existing in41c7006.
Baseline renderer/raytrace/environment sources verified byte-identical to that
commit; only CycleWindowScale and ToggleFullscreen scenario parser aliases added.
Both captures are3024x1898. Paired native-pixel crops show the same top strip.
Launch: beastie-baseline-sizes --fake-ai --script fixtures/scenarios/renderer-window-sizes.jsonl --capture-dir baseline-sizes-check
No renderer or shading changes were made in the baseline source.
This is a visual regression check, not a timing comparison.
