import pathlib,subprocess,sys,json,tarfile,io,hashlib
package=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(sys.argv[1]).resolve();variant=sys.argv[2];destination=pathlib.Path(sys.argv[3]).resolve()
manifest=json.loads((package/'manifest.json').read_text());info=manifest['variants'][variant]
patch=package/f'{variant}.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()==info['patch_sha256']
destination.mkdir(parents=True,exist_ok=False)
data=subprocess.check_output(['git','archive',manifest['base_commit']],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data)) as archive: archive.extractall(destination,filter='data')
subprocess.run(['git','apply',str(patch)],cwd=destination,check=True)
for name,digest in info['source_hashes'].items():assert hashlib.sha256((destination/name).read_bytes()).hexdigest()==digest,name
print(destination)
