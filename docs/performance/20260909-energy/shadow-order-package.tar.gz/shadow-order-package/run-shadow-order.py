import os,subprocess,json
from pathlib import Path
r=Path('/tmp/beastie-energy-20260909')
for name,ordered in [('control-before',False),('ordered',True),('ordered-repeat',True),('control-after',False)]:
 env=os.environ.copy();env.pop('BEASTIE_SHADOW_CACHE_ORDER',None)
 if ordered:env['BEASTIE_SHADOW_CACHE_ORDER']='1'
 env.update(BEASTIE_SHADOW_LOD_ERROR='0.002',BEASTIE_BENCH_SUBMISSION='batched',BEASTIE_BENCH_OUTPUT=str(r/f'shadow-order-{name}.json'),BEASTIE_BENCH_PNG=str(r/f'shadow-order-{name}.png'))
 with (r/f'shadow-order-{name}.log').open('w') as out:
  subprocess.run([str(r/'shadow-order-tests'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,cwd=r/'shadow-order-src',stdout=out,stderr=subprocess.STDOUT,check=True)
 print(name,'done',flush=True)
