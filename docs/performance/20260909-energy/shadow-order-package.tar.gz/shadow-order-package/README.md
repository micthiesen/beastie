# Vertex-cache ordering: rejected

Same-binary control/order/order/control at 1920x1080 and .002 LOD. Reorder original
and selected simplified ranges after simplification, preserving all positions.
meshopt::optimize_vertex_cache changes only triangle ordering. The oriented triangle
multiset test passed; all four captured RGB images were bit-identical.

Warm bounded GPU envelope: control1.47562/1.47823 ms, order1.47563/1.46883 ms.
Warm within-batch median cadence: control1.32421/1.32304 ms, order1.32225/1.32088 ms.
All timestamp validity checks passed. No repeatable material gain; rejected to
avoid additional CPU preparation work. No production ordering changes were made.

Source rationale: https://github.com/zeux/meshoptimizer#vertex-cache-optimization
Actual vertex reuse differs across GPU architectures; this one-device result is
not a universal claim about the technique. Captures are frozen-scene GPU tests,
not native CPU or battery measurements. The snapshot predates final density/async
integration and is compared only with its own same-binary .002 LOD control.

Reproduce source: python3 materialize.py /path/to/beastie order /tmp/order-source
Build: cargo test -p beastie-game --profile dev-perf --no-run
Run offscreen_renderer_benchmark --ignored --nocapture with
BEASTIE_SHADOW_LOD_ERROR=0.002, BEASTIE_BENCH_SUBMISSION=batched,
BEASTIE_BENCH_OUTPUT=report.json, BEASTIE_BENCH_PNG=image.png.
Candidate adds BEASTIE_SHADOW_CACHE_ORDER=1; control omits it.
run-shadow-order.py preserves exact session commands, with task-specific paths.
No binaries included. Manifest records source and measured test-binary hashes.
