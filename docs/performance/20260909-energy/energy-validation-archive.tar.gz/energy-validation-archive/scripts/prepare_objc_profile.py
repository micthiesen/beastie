from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path('/Users/michael/Code/beastie');base=Path('/tmp/beastie-energy-20260909');control=base/'objc-control-src';candidate=base/'objc-candidate-src'
assert not control.exists() and not candidate.exists()
names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
for name in set(names):
 if not name or name.startswith('docs/performance/'):continue
 p=root/name
 if p.is_file():
  out=control/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
p=control/'crates/beastie-game/src/args.rs';s=p.read_text();a='        requires_all = ["script", "feel_dir"],\n        conflicts_with = "new_game"\n';assert s.count(a)==1;p.write_text(s.replace(a,'        conflicts_with = "new_game"\n'))
shutil.copytree(control,candidate)
p=candidate/'Cargo.toml';p.write_text(p.read_text()+'\n# Diagnostic candidate: isolate objc2 development-only runtime checks.\n[profile.dev-perf.package."objc2@0.6.4"]\ndebug-assertions = false\n')
def hashes(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file()}
a=hashes(control);b=hashes(candidate);assert {k for k in a if a[k]!=b[k]}=={'Cargo.toml'}
(base/'objc-profile-source.json').write_text(json.dumps({'control':str(control),'candidate':str(candidate),'only_difference':'Cargo.toml dev-perf.package.objc2@0.6.4 debug-assertions=false','shared_fixture_change':'Args feel_initial_save requires_all removed; fixture disables save writing','control_hashes':a,'candidate_Cargo_sha256':b['Cargo.toml']},indent=2)+'\n')
print(control,candidate)
