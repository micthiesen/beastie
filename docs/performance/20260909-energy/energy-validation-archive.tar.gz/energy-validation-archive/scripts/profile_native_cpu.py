#!/usr/bin/env python3
"""Attach a bounded macOS sample profiler to an already-running ordinary game."""
import argparse,ctypes,hashlib,json,subprocess,time
from pathlib import Path
import sample_process as meter
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
lib=meter.lib;lib.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32];b=ctypes.create_string_buffer(4096)
assert lib.proc_pidpath(a.pid,b,len(b))>0,'PID unavailable'
actual=Path(b.value.decode()).resolve();assert actual==a.binary.resolve(),'Wrong executable'
commandline=subprocess.check_output(['ps','-p',str(a.pid),'-o','args='],text=True).strip()
assert '--render-report' not in commandline and '--script' not in commandline,'Use ordinary game without report or script'
start=meter.sample(a.pid);cmd=['sample',str(a.pid),'5','1','-fullPaths','-file',str(a.output)]
result=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
end=meter.sample(a.pid);assert start['counters']['ri_proc_start_abstime']==end['counters']['ri_proc_start_abstime'],'PID reused'
meta={'schema':1,'binary':str(actual),'binary_sha256':hashlib.sha256(actual.read_bytes()).hexdigest(),'target_commandline':commandline,'profiler_command':cmd,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'samples':[start,end],'scope':'Diagnostic stack profiling perturbs workload. These CPU energy/time samples must not be used as clean performance comparison. sample includes blocked/waiting threads; their stack frequency is not CPU utilization.'}
a.output.with_suffix(a.output.suffix+'.json').write_text(json.dumps(meta,indent=2)+'\n')
print(a.output);raise SystemExit(result.returncode)
