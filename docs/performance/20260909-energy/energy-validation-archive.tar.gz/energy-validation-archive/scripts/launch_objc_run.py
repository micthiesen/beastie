from pathlib import Path
import argparse,subprocess,json,hashlib,shutil,sys
b=Path('/tmp/beastie-energy-20260909');p=argparse.ArgumentParser();p.add_argument('mode',choices=['control','candidate','baseline']);p.add_argument('run');a=p.parse_args()
source=b/f'beastie-objc-{a.mode}';exe=b/'Beastie Hidden Verification.app/Contents/MacOS/beastie-hidden';shutil.copy2(source,exe)
args=[str(exe),'--fake-ai','--feel-initial-save','/Users/michael/Code/beastie/fixtures/saves/feel/familiar-ball.json']
with (b/f'objc-{a.run}-native.log').open('w') as log:
 proc=subprocess.Popen(args,cwd='/Users/michael/Code/beastie',stdout=log,stderr=subprocess.STDOUT)
 meta={'pid':proc.pid,'mode':a.mode,'run':a.run,'command':args,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'fixture_only_qa':True,'profile':'dev-perf','window_policy':'1920x1080,Fifo,scale_override1.0 from unchanged settings and source; no runtime cadence instrumentation'}
 (b/f'objc-{a.run}-launch.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
 sys.exit(proc.wait())
