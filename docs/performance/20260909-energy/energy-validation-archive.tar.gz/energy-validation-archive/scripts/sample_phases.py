#!/usr/bin/env python3
"""Serial phase-tagged libproc recording; phase-file changes reflect external native actions."""
import argparse,ctypes,hashlib,json,time
from pathlib import Path
import sample_process as counters
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--binary',type=Path,required=True);p.add_argument('--phase-file',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--duration',type=float,default=120);p.add_argument('--interval',type=float,choices=[0.1,1.0],default=1.0);a=p.parse_args()
counters.lib.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32]
b=ctypes.create_string_buffer(4096)
if counters.lib.proc_pidpath(a.pid,b,len(b))<=0:raise RuntimeError('Cannot identify PID executable')
actual=Path(b.value.decode()).resolve();expected=a.binary.resolve()
if actual!=expected:raise RuntimeError(f'PID executable mismatch: {actual} != {expected}')
first=counters.sample(a.pid);start=first['monotonic_s'];start_id=first['counters']['ri_proc_start_abstime']
meta={'type':'metadata','pid':a.pid,'binary':str(actual),'binary_sha256':hashlib.sha256(actual.read_bytes()).hexdigest(),'process_start_abstime':start_id,'timebase_numer':counters.tb.numer,'timebase_denom':counters.tb.denom,'scope':'Kernel-accounted task CPU energy only, not GPU/battery energy','source':'https://github.com/apple-oss-distributions/xnu/blob/main/doc/observability/recount.md','interval_s':a.interval}
with a.output.open('w',buffering=1) as out:
 out.write(json.dumps(meta)+'\n')
 while time.monotonic()-start<a.duration:
  tick=time.monotonic();row=counters.sample(a.pid)
  if row['counters']['ri_proc_start_abstime']!=start_id:raise RuntimeError('PID reused')
  row.update(type='sample',phase=a.phase_file.read_text().strip() if a.phase_file.exists() else 'unmarked')
  out.write(json.dumps(row)+'\n');time.sleep(max(0,a.interval-(time.monotonic()-tick)))
print(a.output)
