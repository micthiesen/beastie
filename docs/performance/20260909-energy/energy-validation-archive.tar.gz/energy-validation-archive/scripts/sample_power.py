#!/usr/bin/env python3
"""Read-only whole-machine raw power telemetry; no claim of per-app joules."""
import argparse,json,plistlib,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--samples',type=int,default=60);p.add_argument('--interval',type=float,default=1);a=p.parse_args()
keys=['ExternalConnected','IsCharging','Voltage','Amperage','InstantAmperage','UpdateTime','PowerTelemetryData']
rows=[]
for i in range(a.samples):
 start=time.monotonic(); raw=plistlib.loads(subprocess.check_output(['ioreg','-r','-c','AppleSmartBattery','-a']))
 rows.append({'monotonic_s':start,'unix_s':time.time(),'battery':{k:raw[0].get(k) for k in keys}})
 if i+1<a.samples:time.sleep(max(0,a.interval-(time.monotonic()-start)))
a.output.write_text(json.dumps({'schema':1,'meaning':'Raw undocumented whole-machine AppleSmartBattery fields; refresh and units must be validated. Not per-process energy. No watt/joule conversion claimed.','samples':rows},indent=2)+'\n')
print(a.output)
print('unique power records',len({json.dumps(r['battery']['PowerTelemetryData'],sort_keys=True) for r in rows}))
