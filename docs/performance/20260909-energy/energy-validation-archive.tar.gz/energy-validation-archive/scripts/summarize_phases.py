#!/usr/bin/env python3
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('--settle',type=float,default=2);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
rows=[json.loads(l) for l in a.input.read_text().splitlines()];meta=rows[0];samples=rows[1:];segments=[]
for s in samples:
 if not segments or segments[-1][0]['phase']!=s['phase']:segments.append([])
 segments[-1].append(s)
results=[]
for segment in segments:
 valid=[s for s in segment if s['monotonic_s']-segment[0]['monotonic_s']>=a.settle]
 if len(valid)<2:continue
 first,last=valid[0],valid[-1];dt=last['monotonic_s']-first['monotonic_s'];d={k:last['counters'][k]-first['counters'][k] for k in ['ri_user_time','ri_system_time','ri_energy_nj','ri_penergy_nj','ri_pkg_idle_wkups','ri_interrupt_wkups']}
 assert all(v>=0 for v in d.values()),'Counter regression'
 cpu=(d['ri_user_time']+d['ri_system_time'])*meta['timebase_numer']/meta['timebase_denom']/1e9
 results.append({'phase':first['phase'],'seconds':dt,'sample_count':len(valid),'cpu_seconds':cpu,'cpu_core_equivalents':cpu/dt,'accounted_cpu_joules':d['ri_energy_nj']/1e9,'accounted_cpu_watts':d['ri_energy_nj']/1e9/dt,'package_idle_wakeups_per_s':d['ri_pkg_idle_wkups']/dt,'interrupt_wakeups_per_s':d['ri_interrupt_wkups']/dt,'raw_counter_deltas':d})
a.output.write_text(json.dumps({'metadata':meta,'excluded_transition_seconds':a.settle,'segments':results},indent=2)+'\n');print(a.output)
