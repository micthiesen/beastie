from pathlib import Path
import json
b=Path('/tmp/beastie-energy-20260909')
beats=[json.loads(l.split('HIDDEN_RENDER_VERIFY ',1)[1]) for l in (b/'hidden10-native.log').read_text().splitlines() if l.startswith('HIDDEN_RENDER_VERIFY ')]
hidden=[x for x in beats if x['hidden']]; start=hidden[0]['unix_ms']/1000;end=hidden[-1]['unix_ms']/1000
rows=[json.loads(l) for l in (b/'hidden10-energy.jsonl').read_text().splitlines()];samples=[r for r in rows if r.get('type')=='sample'];out={'metadata':rows[0],'hidden_heartbeat_bounds_unix_s':[start,end],'windows':{}}
for name,sel in [('visible',lambda r:r['unix_s']<start-2),('minimized',lambda r:start+2<=r['unix_s']<=end-2),('restored',lambda r:r['unix_s']>=end+5)]:
 rr=[r for r in samples if sel(r)];a,z=rr[0],rr[-1];dt=z['monotonic_s']-a['monotonic_s'];c=lambda k:z['counters'][k]-a['counters'][k]
 out['windows'][name]={'seconds':dt,'sample_count':len(rr),'first_unix_s':a['unix_s'],'last_unix_s':z['unix_s'],'accounted_cpu_watts':c('ri_energy_nj')/1e9/dt,'cpu_core_equivalents':(c('ri_user_time')+c('ri_system_time'))*125/3/1e9/dt}
a,z=hidden[2],hidden[-2];dt=(z['elapsed_ms']-a['elapsed_ms'])/1000
out['hidden_progress']={'seconds':dt,'updates_per_s':(z['host_updates']-a['host_updates'])/dt,'simulation_ms_per_s':((z['host_elapsed_ms']+z['host_remainder_ms'])-(a['host_elapsed_ms']+a['host_remainder_ms']))/dt,'render_entry_delta':z['render_calls']-a['render_calls'],'dispatch_delta':z['compute_dispatches']-a['compute_dispatches'],'early_return_delta':z['hidden_calls']-a['hidden_calls']}
out['window']=beats[-1]['window'];(b/'hidden10-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
