from pathlib import Path
import subprocess,sys,os,json,time,hashlib
import sample_process as meter
base=Path('/tmp/beastie-energy-20260909');repo=Path('/Users/michael/Code/beastie')
binary=base/sys.argv[1];scenario=sys.argv[2];name=sys.argv[3]
args=[str(binary),'--fake-ai','--script',str(repo/f'fixtures/scenarios/renderer-perf-{scenario}.jsonl'),'--render-report',str(base/f'{name}.json'),'--render-uncapped']
samples=[];started=time.monotonic()
with (base/f'{name}.log').open('w') as log:
    child=subprocess.Popen(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    while child.poll() is None:
        try:
            row=meter.sample(child.pid);row['since_launch_seconds']=time.monotonic()-started;samples.append(row)
        except OSError: pass
        time.sleep(.1)
    code=child.wait()
assert code==0,code
data={'schema':1,'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scenario':scenario,'command':args,'scope':'Kernel-accounted CPU energy excludes GPU, display, AI workers and battery losses','timebase_numer':meter.tb.numer,'timebase_denom':meter.tb.denom,'samples':samples}
warm=[r for r in samples if r['since_launch_seconds']>=3]
if len(warm)>1:
    first,last=warm[0],warm[-1];duration=last['monotonic_s']-first['monotonic_s']
    assert first['counters']['ri_proc_start_abstime']==last['counters']['ri_proc_start_abstime']
    delta={k:last['counters'][k]-first['counters'][k] for k in first['counters'] if k not in ['ri_phys_footprint','ri_proc_start_abstime']}
    assert all(v>=0 for v in delta.values())
    data['warm_summary']={'seconds':duration,'cpu_joules':delta['ri_energy_nj']/1e9,'cpu_watts':delta['ri_energy_nj']/1e9/duration,'cpu_core_equivalents':(delta['ri_user_time']+delta['ri_system_time'])*meter.tb.numer/meter.tb.denom/1e9/duration,'interrupt_wakeups_per_s':delta['ri_interrupt_wkups']/duration,'package_idle_wakeups_per_s':delta['ri_pkg_idle_wkups']/duration,'peak_process_footprint_bytes':max(r['counters']['ri_phys_footprint'] for r in samples),'raw_counter_delta':delta}
(base/f'{name}-energy.json').write_text(json.dumps(data,indent=2)+'\n')
report=json.loads((base/f'{name}.json').read_text())
print(name,{k:report[k] for k in ['wall_frame_p50_ms','wall_frame_p99_ms','wall_frame_max_ms','wall_frames_over_33_ms']},data.get('warm_summary'),flush=True)
