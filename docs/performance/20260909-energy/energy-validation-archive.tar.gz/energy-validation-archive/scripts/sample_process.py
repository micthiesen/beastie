#!/usr/bin/env python3
"""Sample kernel-accounted process CPU energy, CPU ticks and wakeups; not GPU energy."""
import argparse,ctypes,json,os,re,time,subprocess
from pathlib import Path
sdk=Path(subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip())
header=(sdk/'usr/include/sys/resource.h').read_text()
body=header.split('struct rusage_info_v6 {')[1].split('};')[0]
fields=[]
for typ,name,count in re.findall(r'(uint8_t|uint64_t)\s+(\w+)(?:\[(\d+)\])?;',body):
    c=ctypes.c_uint8 if typ=='uint8_t' else ctypes.c_uint64
    fields.append((name,c*int(count) if count else c))
class Info(ctypes.Structure):_fields_=fields
class Timebase(ctypes.Structure):_fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
system=ctypes.CDLL('/usr/lib/libSystem.B.dylib');tb=Timebase();system.mach_timebase_info(ctypes.byref(tb))
selected=['ri_user_time','ri_system_time','ri_pkg_idle_wkups','ri_interrupt_wkups','ri_cycles','ri_instructions','ri_energy_nj','ri_penergy_nj','ri_phys_footprint','ri_proc_start_abstime']
def sample(pid):
    info=Info()
    if lib.proc_pid_rusage(pid,6,ctypes.byref(info))!=0:raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
    return {'monotonic_s':time.monotonic(),'unix_s':time.time(),'counters':{n:getattr(info,n) for n in selected}}
def main():
    p=argparse.ArgumentParser();p.add_argument('--pid',type=int,default=os.getpid());p.add_argument('--samples',type=int,default=31);p.add_argument('--interval',type=float,default=1);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    rows=[]
    for i in range(a.samples):
        start=time.monotonic();rows.append(sample(a.pid))
        a.output.write_text(json.dumps({'schema':1,'pid':a.pid,'source':'libproc proc_pid_rusage RUSAGE_INFO_V6','cpu_time_units':'Mach absolute ticks; multiply by timebase_numer/timebase_denom for nanoseconds','timebase_numer':tb.numer,'timebase_denom':tb.denom,'energy_scope':'Kernel-accounted task CPU energy ri_energy_nj in nanojoules; excludes GPU, display, other processes and battery losses. Not whole-device energy.','samples':rows},indent=2)+'\n')
        if i+1<a.samples:time.sleep(max(0,a.interval-(time.monotonic()-start)))
    print(a.output)
if __name__=='__main__':main()
