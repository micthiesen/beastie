#!/usr/bin/env python3
"""Patch only a scratch source copy; no production runtime debug override."""
from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args();root=a.source.resolve()
assert str(root).startswith(('/private/tmp/','/tmp/')), 'Scratch source only'
r=root/'crates/beastie-game/src/raytrace.rs';policy=root/'crates/beastie-game/src/render_activity.rs'
args_path=root/'crates/beastie-game/src/args.rs'
args_source=args_path.read_text()
args_pattern=r'(    /// Validated deterministic starting state used only by scripted feel evidence\.[\s\S]*?)        requires_all = \["script", "feel_dir"\],\n'
assert len(re.findall(args_pattern,args_source))==1,'Fixture args anchor changed'
args_patched=re.sub(args_pattern,r'\1',args_source)
s=r.read_text();q=policy.read_text();before={str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [r,policy,args_path]}
pattern=r'    if activity\s*\.as_ref\(\)\s*\.is_some_and\(\|activity\| !activity\.should_render\(\)\)\s*\{'
matches=list(re.finditer(pattern,s));assert len(matches)==1,'Hidden return anchor changed'
i=matches[0].start();s=s[:i]+'    crate::render_activity::verify_render_entry(activity.as_ref().is_some_and(|a| !a.should_render()));\n'+s[i:]
pattern=r'(?m)^(\s*)(pass\.dispatch_workgroups\([^;]+;)'
assert len(re.findall(pattern,s))==1,'Dispatch count changed: review all paths'
s=re.sub(pattern,r'\1crate::render_activity::verify_dispatch();\n\1\2',s)
old='force_render: args.script.is_some()';assert q.count(old)==1
q=q.replace(old,'force_render: !VERIFY_HIDDEN_RENDERING && (args.script.is_some()')
old='                || args.smoke,';assert q.count(old)==1
q=q.replace(old,'                || args.smoke),')
old='.add_systems(PreUpdate, update_activity);';assert q.count(old)==1
q=q.replace(old,'.add_systems(PreUpdate, update_activity)\n        .add_systems(Last, verify_hidden_heartbeat);')
q+='''
// SCRATCH ONLY: never ship this compile-time capture/report override or counters.
const VERIFY_HIDDEN_RENDERING: bool = true;
static VERIFY_RENDER_CALLS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static VERIFY_HIDDEN_CALLS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static VERIFY_DISPATCHES: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
pub(crate) fn verify_render_entry(hidden: bool) {
    use std::sync::atomic::Ordering::Relaxed;
    VERIFY_RENDER_CALLS.fetch_add(1, Relaxed);
    if hidden { VERIFY_HIDDEN_CALLS.fetch_add(1, Relaxed); }
}
pub(crate) fn verify_dispatch() {
    VERIFY_DISPATCHES.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
}
#[derive(Default)]
struct VerifyHeartbeat { started: Option<std::time::Instant>, last_ms: u128, state: Option<bool>, updates: u64 }
fn verify_hidden_heartbeat(
    activity: Res<RenderActivity>,
    frame: Option<Res<crate::renderer::SceneFrame>>,
    mut beat: Local<VerifyHeartbeat>,
) {
    use std::sync::atomic::Ordering::Relaxed;
    let Some(frame) = frame else { return; };
    beat.updates += 1;
    let start = *beat.started.get_or_insert_with(std::time::Instant::now);
    let ms = start.elapsed().as_millis();
    let hidden = !activity.should_render();
    if beat.state != Some(hidden) || ms.saturating_sub(beat.last_ms) >= 1000 {
        eprintln!("HIDDEN_RENDER_VERIFY {}", serde_json::json!({
            "elapsed_ms":ms,"unix_ms":std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis(),
            "hidden":hidden,"raw_occluded":activity.occluded,"force_render":activity.force_render,
            "host_updates":beat.updates,"host_elapsed_ms":frame.plan.elapsed_ms,
            "host_remainder_ms":frame.plan.simulation_remainder_ms,
            "render_calls":VERIFY_RENDER_CALLS.load(Relaxed),"hidden_calls":VERIFY_HIDDEN_CALLS.load(Relaxed),
            "compute_dispatches":VERIFY_DISPATCHES.load(Relaxed)}));
        beat.state = Some(hidden); beat.last_ms = ms;
    }
}
'''
r.write_text(s);policy.write_text(q);args_path.write_text(args_patched)
(root/'hidden-verification-source.json').write_text(json.dumps({'scope':'scratch-only compile-time hidden verification; live production automation override preserved','before_sha256':before,'after_sha256':{str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [r,policy,args_path]}},indent=2)+'\n')
print('Instrumented scratch copy only:',root)
