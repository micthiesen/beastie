# Native CPU energy and hidden-render validation utilities

These read-only macOS utilities sample kernel-accounted task CPU energy and record native profiling/occlusion evidence. No game binaries, copied repository tree, full source archive, or Instruments trace bundle is included. Existing raw baseline/integrated reports are copied into `reports/`; later final reports can be added with regenerated artifact hashes.

## Requirements and scope

Python3, macOS libproc, Xcode SDK headers (`xcrun --show-sdk-path`), and the system `sample` profiler. Keep the scripts together because phase/profiling collectors import sample_process. Sampling attaches to an already-running process and does not launch or control a game. Scripts containing original scratch/repository paths preserve the actual measured command recipe; adjust those paths when reproducing on another checkout.

`proc_pid_rusage` RUSAGE_INFO_V6 exposes task CPU energy (`ri_energy_nj`, nanojoules) and P-core CPU energy (`ri_penergy_nj`). Apple XNU documents Recount's task accounting here: https://github.com/apple-oss-distributions/xnu/blob/main/doc/observability/recount.md . This is not GPU energy, whole-machine energy, battery consumption or a promise of battery life. Child AI workers are separate tasks. Zero/unsupported counters must not be interpreted as free computation.

CPU user/system time fields are Mach absolute ticks, not nanoseconds. The collector records mach_timebase_info numer/denom. This Mac returned125/3. A bounded calibration measured0.050030seconds using Python process_time versus0.0500085seconds from the converted libproc delta (1,200,204ticks), with264,856,395nJ accounted CPU energy. The conversion is delta ticks*numer/denom/1e9seconds. Energy delta/1e9 is CPU joules; divide by monotonic elapsed seconds for average accounted CPU watts.

Availability investigation: powermetrics failed without root; no sudo was attempted. Xcode lists Power Profiler but an explicit no-prompt recording failed because that instrument is unsupported on macOS. AppleSmartBattery's accessible raw power records remained identical across10seconds on AC power and were not used as a power measurement. IOAccelerator exposed whole-device utilization, not attributable game GPU counters. Detailed limitations and the future privileged powermetrics command are in notes/.

## Phase sampling

Verify the exact copied executable and PID, then set a plain-text phase marker file to `warmup`, `visible`, `hidden`, or `restored` using the controlling workflow. The sampler validates proc_pidpath, records binary SHA256 and process start identity, and reads that file each sample.

```sh
python3 scripts/sample_phases.py --pid PID --binary /exact/game-binary --phase-file /tmp/beastie-phase --output /tmp/run.jsonl --duration 120 --interval 1.0
python3 scripts/summarize_phases.py /tmp/run.jsonl --output /tmp/run-summary.json
```

Use interval0.1 for100ms samples or1.0 for lower-overhead1s sampling. Summary excludes the first2seconds of each phase segment, rejects counter decreases, and never joins different phases. Preserve raw JSONL. Collect baseline/candidate/baseline serially with the same power source, resolution, refresh, brightness, camera/UI state and external workload. Compare rates over equal-duration settled windows, not total joules from unequal runs.

## Ordinary CPU comparison without report overhead

1. Use the ordinary baseline and integrated `dev-perf` binaries, not the hidden-instrumented verification binary. Record each executable hash. Launch one game at a time with `--fake-ai`, without `--script`, `--render-report`, `--render-uncapped`, feel or capture flags. Keep ordinary VSync and the same loaded creature/settings. Do not use `--new-game`, which resets the user's save.
2. Select the same visible state (title, quiet gameplay, then a particular settings panel) through native controls. Capture state/screenshots externally if needed. Allow at least10seconds startup settling, then sample30seconds using phase labels such as `visible-gameplay` and `visible-settings`. Repeat baseline/integrated/baseline. Ordinary simulation progresses, so this is a matched workload class, not bit-identical deterministic frames; record that limitation and inspect for spontaneous events.
3. Compare CPU core-equivalents and kernel-accounted CPU W, with no render report resource or GPU timestamp instrumentation active. This isolates the question whether the earlier approximately0.40CPU-core report runs were dominated by telemetry overhead. Do not infer CPU milliseconds/frame without a separately verified frame rate.
4. Separately attach the bounded diagnostic profiler to each already-running ordinary game:

```sh
python3 scripts/profile_native_cpu.py --pid PID --binary /exact/game-binary --output /tmp/ordinary-cpu.sample.txt
```

It executes `sample PID 5 1 -fullPaths -file ...`, validates identity and rejects report/script arguments. Its metadata captures task counters around profiling only for context. Sampling perturbs the workload; never combine those intervals with clean energy/p99 comparisons. macOS sample includes blocked-thread stacks, whose counts are not active CPU percentages. Inspect running work separately from dispatch waits, semaphore waits and presentation blocking.

## Hidden rendering validation

`instrument_hidden.py /tmp/plain-source-copy` adds scratch-only render-entry/hidden-return/compute-dispatch counters and a main-world Last heartbeat. The heartbeat continues to expose host elapsed time and RenderActivity even when no render ViewQuery runs. A compile-time scratch exception permits reporting while hidden; live automation override remains unchanged. This source patch is for native verification builds only. Its deliberate override changes the normal automation-policy test expectations; do not treat that verification binary as the ordinary production behavior or a clean CPU benchmark. The script checks anchors before writing and refuses destinations outside /tmp.

The root native controller should collect visible, minimized/fully-occluded, and restored phases, allowing2seconds in-flight work to drain. Assert compute-dispatch count stops during confirmed hidden state, host time continues, and fresh frames resume upon restore. Focus loss while still visible must not suppress rendering. Test ordinary scripted captures separately with the untouched production override. CUA/native screenshots plus counters establish behavior; counts are not GPU watts. Exact sequence and limitations are in notes/hidden-validation-plan.md.

## Provenance

`manifest.json` records every included artifact SHA256, measured Mach calibration, and source hashes of the prepared hidden-verification copy without including the copy itself. Existing report JSON includes measured binary hashes, commands, source state and raw samples where originally collected. Native hidden and10Hz results are documented in notes/hidden-native-inspection.md and notes/hidden10-inspection.md with raw logs and explicit limits. This package does not certify future measurements.
