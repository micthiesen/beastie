# Energy and pacing investigation

Read-only investigation against shipped renderer plus current shared changes. No builds, game launches, GPU benchmarks, sudo, service changes, or live-source edits.

## Measurement availability

- `powermetrics --samplers cpu_power,gpu_power,tasks -n 1 -i 100 --show-process-energy` failed immediately: `powermetrics must be invoked as the superuser`. Power estimates and process wakeup/energy-impact collection therefore are unavailable to this unprivileged process. No sudo was attempted.
- Xcode command-line Instruments is installed and lists Activity Monitor, CPU Profiler, Game Performance, Metal System Trace, System Trace, and Power Profiler. However `xctrace record --template 'Power Profiler' --all-processes --time-limit 2s --no-prompt --output /tmp/beastie-energy-20260909/availability.trace` failed: Power Profiler is not supported on macOS (iOS/iPadOS only), plus its location model cannot target All Processes. A template name alone is not evidence that energy recording works here.
- `pmset -g batt`: AC power, 80%, not charging. Battery discharge is not a useful current measurement.
- `ioreg -r -c AppleSmartBattery -a` exposes PowerTelemetryData without privilege, but three samples five seconds apart yielded exactly one distinct power record and an unchanged device UpdateTime. Its private field units/refresh are not established. Do not convert this stale record into app watts or claim a saving. `sample_power.py` preserves selected raw fields without serial identifiers; `availability-power.json` records the freshness check.
- Current defensible comparison is a demand proxy: unchanged presentation rate, process CPU time per elapsed second, valid GPU pass occupancy/throughput, and count of rendered frames while occluded. It is not battery life or measured joules. Matched trials must keep brightness, refresh, power source, resolution, AI state, and desktop workload fixed and run baseline/candidate/baseline serially.

If a future operator supplies privileged measurement access, the installed powermetrics supports this command (not executed):

```sh
sudo powermetrics --samplers cpu_power,gpu_power,tasks --show-process-gpu --show-process-energy --show-usage-summary -i 1000 -n 60 -o /tmp/beastie-energy-20260909/power.txt
```

The tool itself calls these estimated subsystem powers, suitable for same-device optimization rather than cross-device comparisons. Its process energy-impact number is not joules. A future permission-available CPU/wakeup trace can use `xctrace record --template 'System Trace' --attach <game-pid> --time-limit 30s --no-prompt --output /tmp/beastie-energy-20260909/system.trace`; this path has not yet been validated here.

## Ranked opportunities

1. **Stop rendering only when the window is fully occluded/minimized.** No occlusion handler exists in host.rs; Bevy forwards `WindowOccluded` but does not update a stored occlusion field. Focus loss currently ends PTT and saves only (app.rs:2072). The default WinitSettings::game is already Continuous focused and reactive_low_power at60Hz unfocused. Thus changing all unfocused windows would silently degrade a still-visible window and is not recommended. Track confirmed occlusion separately, suppress camera/render work while hidden, and immediately resume/request redraw when exposed. Keep script/capture modes exempt so validation does not depend on desktop visibility. Initially retain host updates to avoid changing gameplay/audio semantics; measure hidden GPU/CPU demand before broadening this policy.
2. **Then reduce hidden host wakeups carefully.** A bounded hidden servicing interval such as100ms retains worker completion/error handling and ordinary simulation advancement while saving main-world/UI extraction work. Foreground and visible-unfocused modes stay unchanged. host.rs:258 clamps delta to250ms, so a naive1Hz setting would lose three quarters of elapsed simulation time; it must not be introduced without deliberate elapsed-time handling. Camera suppression alone also does not skip host publish: host.rs:303 unconditionally builds a complete ScenePlan. Hidden projection/extraction skipping needs a clean resume invalidation, not reused stale state.
3. **Measure expensive foreground work before changing pacing.** Foreground Continuous plus default VSync already preserves display refresh. Do not lower it silently. Add narrow CPU phase observation for host update/publish if needed to separate simulation/view-plan cost from UI mesh and extraction timings already available. Optimize measured allocation or computation hot spots while preserving native p99 and presentation frequency.
4. **Worker cancellation wakeups are secondary.** process.rs:12/188 wakes every10ms only during an active worker exchange to poll cancellation; idle dialogue/recognition worker loops block on command channels. This is not a100Hz always-idle leak. A blocking cancellation notification could remove active-wait wakeups but touches cancellation/timeout correctness and should follow actual evidence, not precede the visible/hidden rendering fix.

## Proposed narrow ownership

Host pacing worker: host.rs and small main.rs WinitSettings initialization, plus a visibility policy resource and focused unit tests (visible unfocused unchanged, hidden/exposed transitions, script exemption, no elapsed-time loss). Renderer worker: consume that resource in camera/render activation only, preserving caches and forcing fresh state on expose. Initially do not change simulation logic, worker cancellation, audio behavior, or foreground frame pacing. This investigation agent can own scratch measurement collection and comparative reports after the root coordinates native runs.

## Follow-up: CPU energy is accessible

A subsequent libproc investigation found a working unprivileged CPU-energy path. `proc_pid_rusage(..., RUSAGE_INFO_V6, ...)` returns live `ri_energy_nj` values. Apple XNU Recount documentation identifies the task accounting as CPU energy in nanojoules: https://github.com/apple-oss-distributions/xnu/blob/main/doc/observability/recount.md . This supersedes the earlier CPU-proxy-only limitation for task CPU energy; GPU and whole-device/battery energy remain unavailable. See `hidden-validation-plan.md`, `sample_phases.py`, and `summarize_phases.py` for scope, conversion calibration, stable PID/binary identification and phase handling.
