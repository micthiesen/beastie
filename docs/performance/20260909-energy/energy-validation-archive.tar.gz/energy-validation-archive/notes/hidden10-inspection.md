# Native 10 Hz hidden pacing validation

The scratch `hidden10-src` build passed all six render_activity tests and built under dev-perf. Process95714 ran the same nonpersistent familiar-ball fixture and fake AI as the earlier hidden run. No script, render report, uncapped presentation or capture flags were used. Binary/bundle identity and SHA256 are recorded in hidden10-binary.json and the sampler metadata. Window heartbeat established1920×1080 physical and logical pixels, scale factor1.0, and Fifo presentation.

Clean windows use actual occlusion heartbeat boundaries rather than delayed phase labels. Two seconds at hidden boundaries and five seconds after the final hidden heartbeat were excluded. Raw samples remain unchanged in hidden10-energy.jsonl; analyze_hidden10.py reproduces hidden10-summary.json.

| State | Duration | Task CPU W | CPU core equivalents |
| --- | ---: | ---: | ---: |
| Visible |35.14s|0.55583|0.51605|
| Minimized |33.10s|0.02113|0.05298|
| Restored |47.19s|0.55370|0.51645|

The previous same-fixture scratch60Hz hidden measurement was0.13595W and0.32317core. This single matched workload comparison indicates about84.5% less kernel-accounted CPU energy while hidden. It is not a whole-device or GPU watt measurement, and has not been repeated as an alternating series.

During34.801seconds of confirmed occlusion, host updates averaged9.9997Hz and the authoritative projected scene clock progressed995.40ms per wall second. Render-entry, compute-dispatch and hidden-early-return deltas were all zero, confirming the framework omitted the custom view before the node. Thus the new measured saving is lower CPU update demand, not newly eliminated GPU work. The existing per-update integer millisecond truncation remains;100ms pacing does not trigger the250ms host delta clamp in these measured intervals.

Native activation restored focus and cleared occlusion. Rendering resumed near120Hz with the original Fifo policy. A CUA screenshot inspected immediately after restoration showed the creature at a new position with changed animation, fresh caustics, and intact controls; it was not a stale pre-minimize image. This screenshot exists in conversation evidence, not as an archived PNG. CUA's screenshot representation was960×576 including titlebar, whereas actual window dimensions above come from the app's Window resource.

Visible-unfocused runtime behavior remains covered by unit policy tests rather than a proven native phase. Focus false was verified while minimized; this does not establish visible-unfocused state. No production instrumentation, fixture CLI relaxation, or automation exception was integrated. Production automation is not suppressed or throttled by this policy, although Bevy/OS may still withhold minimized render views.

The app closed normally with exit0 and no remaining scratch process. Build/GPU/CUA slot was released before live policy integration. Root owns the final live verification gate.
