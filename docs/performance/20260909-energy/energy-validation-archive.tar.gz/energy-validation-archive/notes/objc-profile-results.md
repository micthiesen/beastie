# Objective-C development-profile experiment

The candidate repeatedly reduced kernel-accounted CPU energy in this native workload. It increased CPU time, so the result must not be described as a percentage reduction in executed CPU work. Thread placement/frequency effects were not measured directly. Root still owns final scripted tail checks.

|Run order|Task CPU W|CPU core equivalents|
|---|---:|---:|
|Final renderer control1|0.533664|0.525316|
|objc2 candidate1|0.293090|0.605208|
|Final renderer control2|0.510797|0.551134|
|41c7006 baseline repeat|0.781984|0.570850|
|objc2 candidate2|0.272075|0.616539|

Each run collected45seconds and excluded the first10seconds, leaving approximately34.13seconds between endpoint samples. No compilation, other game/GPU experiment, or stack profiler overlapped clean sampling. Both renderer snapshots had identical source hashes except the Cargo profile override; both relaxed only the fixture CLI requirement. Actual scene evolution was ordinary, so this is a matched workload class rather than bit-identical frames. Fixture, window settings and presentation flags were fixed: familiar-ball,1920×1080, scale override1.0, Fifo, fake AI, no script/report/capture/uncapped options. Dimensions are supported by settings/source and native window framing; no cadence instrumentation was added.

Candidate mean CPU energy was approximately46% below final-renderer controls. Relative to the matched41c7006 repeat, final controls were approximately33% lower and candidates approximately64% lower. These are task CPU estimates only, not GPU/whole-device/battery power. The objc2 override affects the development profiling build, whose dependency checks were otherwise enabled. Ordinary release builds already disable those debug checks, so do not attribute this profile saving to new shipped renderer work.

The candidate changes only `[profile.dev-perf.package."objc2@0.6.4"] debug-assertions=false`. This disables all objc2 debug checks in this profile, including signature/nil/class-related checks, not only signature parsing. Application assertions and workspace overflow checks remain enabled; dev/test/fullverify profiles are untouched. Verbose compiler trace confirms objc2 has optimized default assertions off with explicit overflow checks on, while beastie_game retains explicit debug assertions on (and Cargo's inherited overflow checks). Both build successfully; root final gate remains responsible for live integration checks.

A separate5second candidate stack sample after candidate1 clean energy collection no longer contained the prior wgpu Metal signature-parsing path. A few checks from other Objective-C dependency paths remained. Stack samples include waiting threads and are not CPU utilization percentages. No further tracing or optimization was performed.

Both native candidates and controls opened the expected fixture, entered gameplay, and closed normally. The test binary wrapper identity and exact hashes are recorded per launch. Root will perform final p99/capture validation; no tail equivalence is claimed here.

Reproduction: prepare_objc_profile.py captures current source into identical control/candidate scratch copies; build each with `cargo build -p beastie-game --profile dev-perf`, preserve separate binaries, and use launch_objc_run.py plus sample_phases.py45s and summarize_phases.py --settle10. The source hash manifest anchors this historical measurement even though live code can change later. The recorded compiler log preserves actual commands.
