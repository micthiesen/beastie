# Report-mode diagnostic pool review

## Proven observations

`final-sizes-capture.log` records Metal's `Cannot allocate sample buffer`, followed by wgpu DeviceLost and application exit after seven size captures during the fullscreen transition. The log does not identify the particular query-set allocation or report the number of retained counter buffers. Subsequent ordinary world reporting passed.

Root's no-report size/fullscreen isolation passed nine captures, including640 through3840pixel widths, fullscreen3024×1898 and restoration to1920×1080. Other no-report gold/UI/motion captures passed. This points toward optional measurement pressure rather than proving a product fullscreen-rendering failure. Corrected report-mode repeats remain pending at this review's writing.

## Pinned implementation facts

Registry root: `/Users/michael/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/`.

- `bevy_render-0.19.1/src/diagnostic/internal.rs:24` sets256 timestamp queries per FrameData. Lines244–250 allocate that query set whenever TIMESTAMP_QUERY is enabled, including this Metal adapter despite the plugin's older platform documentation.
- The same file's `finish_frame`, lines129–143, reuses a finished frame or allocates another FrameData if none is ready, then pushes the prior frame into submitted_frames. There is no pending-frame allocation cap. `begin_frame` only recycles frames whose mapped callbacks have completed.
- Lines559–564 return on a failed map without setting is_mapped; lines569–578 keep such frames pending. No map failure was observed in this specific log, so that path is an additional source limitation, not an asserted cause here.
- `wgpu-hal-29.0.4/src/metal/device.rs:1792–1825` allocates a Metal counter sample buffer for each timestamp query set with sampleCount equal to the requested count. A failed `newCounterSampleBufferWithDescriptor_error` logs the observed error text and returns DeviceError::Unexpected.
- Our `ComputeGpuTiming::begin_named` in live ray_stats.rs caps the custom pool at12 total slots and four per named pass, each containing only two timestamp queries. It declines another sample when exhausted instead of growing the pool. It is independent of Bevy's recorder.

## Mechanism and bounded change

The plausible mechanism is delayed fullscreen/capture readbacks exhausting the redundant Bevy pool's available counter-buffer capacity as queued diagnostic frames accumulate. Source inspection proves that pool can grow without bound and that its allocation failure matches the logged fatal path. It does not prove that this pool was the exact failing allocation in the native run; allocation labels/pool counts were not captured.

RayStatsPlugin no longer enables RenderDiagnosticsPlugin. Legacy DiagnosticsStore collection and its deduplication state were removed. JSON compatibility is retained with `ray_passes: {}` and an explicit disabled/unavailable explanation. Independent bounded named GPU passes, compute alias, CPU phase guards and wall reporting remain unchanged. Optional RecordDiagnostics spans become no-ops without a recorder.

A headless regression test now asserts that report mode installs the custom collector without installing Bevy's query pool. Existing warmup/invalid-value coverage was adapted after removing legacy samples. Root owns compilation, full verification and corrected report-mode native repetitions. This change eliminates redundant unbounded measurement allocation without changing normal renderer quality, gameplay, presentation policy or required GPU features.
