# Hidden-render validation plan

## Working unprivileged process sampler

`sample_process.py` reads libproc `proc_pid_rusage` flavor6 with the exact struct layout from the installed macOS SDK. The API succeeds for our user process and provides CPU user/system time, package/interrupt wakeups, instructions, cycles, footprint, and CPU energy (`ri_energy_nj`, `ri_penergy_nj`). No subprocess is spawned during the sampling loop. CPU times are Mach absolute ticks, not nanoseconds; the recorded timebase here is125/3. A bounded50ms self-CPU calibration produced0.050030s Python process time and0.0500085s from converted libproc counters, with264,856,395nJ CPU energy delta. This verifies conversion and a live energy counter, not game energy or GPU power.

Apple XNU primary source describes Recount as backing proc_pid_rusage task counters and CPU energy in nanojoules: https://github.com/apple-oss-distributions/xnu/blob/main/doc/observability/recount.md . The installed `sys/resource.h` defines RUSAGE_INFO_V6 and its `ri_energy_nj` field. This is kernel-accounted task CPU energy, not total device, GPU, display, AI-worker, or battery energy. Measure AI workers separately if included. `ri_proc_start_abstime` lets the analysis reject PID reuse.

```sh
python3 /tmp/beastie-energy-20260909/sample_process.py --pid GAME_PID --samples 31 --interval 1 --output /tmp/beastie-energy-20260909/visible-before.json
```

For an interval, CPU energy joules = delta ri_energy_nj /1e9; average accounted CPU watts = that divided by monotonic elapsed seconds. CPU seconds = delta(user_time+system_time)*numer/denom/1e9. Retain raw samples and reject counter decreases or changed process-start identifiers. Sample identical31s windows, exclude2s after every transition, and compare visible-before, hidden, visible-after. Control the same window/scene/refresh and external workload; this measures background demand reduction without claiming a battery runtime percentage.

## GPU evidence

IOAccelerator registry access works but only identified whole-device `PerformanceStatistics` utilization and last-submitting PID. These cannot prove a particular game's GPU inactivity amid WindowServer/other apps. No attributable per-process GPU-time field was found in public libproc or inspected registry output. Avoid calling whole-device utilization per-game energy.

Preferred bounded verification build: copy final source to scratch and add counters solely there around the production render path. Record render-entry count, occlusion-early-return count, completed game render/dispatch count, and current RenderActivity state at transitions and at1Hz. A frame reaching the hidden return must not reach any depth/raster/compute pass. Include host simulation elapsed time and water phase in those records so hidden servicing and restored freshness are observable. Production automation/report overrides remain unchanged; launch this verification game unscripted with a scratch save path using existing native options. Do not add a production debug override.

The direct code-boundary counters plus a successful native occlusion event establish that the game submits no rendering work after in-flight work drains. They are dispatch evidence, not GPU watts. If stronger independent confirmation is needed, a permission-available Metal/System Trace can inspect process submissions, but recording permissions and overhead have not yet been validated. No trace or game was started for this plan.

## Native sequence, coordinated by root

1. Launch one normal fake-AI game using isolated save state; use no script/report/capture flags. Keep normal VSync. Collect30s visible process counters and a native screenshot.
2. Minimize through the app's Accessibility window action using the already initialized CUA session. Confirm the minimized state and the production WindowOccluded(true) transition in verification logs. After2s drain, collect30s hidden counters. Assert rendered/dispatch count remains constant while host time advances. Focus loss alone is a separate test: a still-visible unfocused window must continue rendering.
3. Restore through Accessibility, confirm WindowOccluded(false) or focus recovery and resumed dispatches immediately on subsequent updates. Take a screenshot after restoration and a second shortly afterward; inspect creature pose/water to ensure current animation, no blank/stale frame, and intact UI. Do not interpret an arbitrary pixel change alone as fresh simulation; pair images with host elapsed/water records.
4. Collect30s restored-visible counters. Repeat hidden/restore once to rule out one-time behavior. Compare against baseline unsuppressed game only in a separately coordinated identical run if a quantified pre-change improvement is required.
5. Run a separate normal scripted capture/report while minimized to confirm automation still renders. Existing override is the feature under test, never disabled for this case.

This plan does not change foreground cadence or physics deltas. Root owns CUA and GPU scheduling. All scripts and future verification patches remain under `/tmp/beastie-energy-20260909/`.
