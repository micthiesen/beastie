# Native hidden-state evidence, before 10 Hz pacing

A scratch copy of the integrated renderer ran unscripted with fake AI and the familiar-ball fixture, with save writing disabled. Only scratch code relaxed the fixture CLI requirement and added atomic render/dispatch counts plus a main-world Last heartbeat. No render report or GPU timestamp collection was active. The legitimate measured process was PID 91802, executable `Beastie Hidden Verification.app/Contents/MacOS/beastie-hidden`, and it exited normally after validation.

## Observations

Clean visible sampling over 56.20 s measured 0.5342 W of kernel-accounted task CPU energy and 0.5206 CPU-core equivalents. Clean minimized sampling over 48.19 s measured 0.1359 W and 0.3232 core equivalents. Restored sampling over 41.17 s measured 0.4976 W and 0.5451 core equivalents. These are CPU task counters, not GPU power, whole-device energy, or battery discharge. Phase summaries retain raw counter measurements and discard the first two seconds of each phase.

While minimized, main-world updates continued at approximately 60 Hz. The scene clock advanced approximately 2.911 seconds during one 3.000-second wall interval, consistent with existing per-update integer millisecond truncation. Custom render entries and compute dispatch counts stayed fixed at 19637 and 19636. The hidden early-return count stayed zero: Bevy/OS excluded the render view before the custom node ran. Application Hide similarly stopped custom render entries before the node. This establishes existing suppression under these native conditions, not a new GPU-saving benefit attributable to our early return.

After restoration, raw occlusion became false, dispatch counts resumed near 120 Hz, and native screenshots showed a fresh changed creature pose/caustics with intact UI. The screenshots were inspected through CUA and remain conversation evidence; no persistent screenshot file was saved. A fresh return screenshot is required for the 10 Hz prototype.

The attempted visible-unfocused interval lacked a focus-state heartbeat, so it cannot establish that the target actually lost focus. That label must not support a focus claim. The next scratch heartbeat includes Window.focused. Unit tests cover the policy that focus loss alone does not suppress or throttle.

## Measurement exclusions and automation limits

An initial short-lived Python launcher failed to keep its child alive. CUA subsequently relaunched the bundle without fixture arguments; those runs were discarded. `hidden-native-launch.json` described this discarded PID 91603 and is superseded by this note. The legitimate direct-shell launch was independently verified by executable path and PID before sampling.

Observing the minimized app immediately through CUA could restore it, so the first minimized phase is excluded. The clean phase had no CUA observations until its measurement window ended. After application Hide, a screenshot returned a cached window image while heartbeat still reported hidden; that image was not accepted as restoration proof. Actual restoration required subsequent activation and was confirmed by fresh heartbeat and resumed dispatches.

Production automation policy does not suppress or throttle automation. This is not a guarantee that the framework or OS supplies a render view while minimized.

Raw evidence: `hidden-native.log`, `hidden-native-energy.jsonl`, `hidden-native-energy-summary.json`, `hidden-menu-energy.jsonl`, `hidden-menu-energy-summary.json`. The 10 Hz pacing hypothesis remains unbuilt and unverified at the time of this note.
