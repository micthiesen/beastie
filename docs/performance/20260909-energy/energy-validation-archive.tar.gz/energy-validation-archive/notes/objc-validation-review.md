# Objective-C validation hypothesis, read-only

Current Cargo.toml dev-perf enables debug assertions for workspace and dependencies. Cargo.lock includes objc2 versions0.5.2 and0.6.4. wgpu-hal29 uses objc2~0.6.3, resolved0.6.4.

The baseline ordinary5s sample contains a concrete Metal draw path at lines4488–4491: wgpu-hal::metal::CommandEncoder::draw -> objc2::runtime::message_receiver::msg_send_check -> verify_method_signature -> method-encoding parser.34 of41 observations in that particular draw branch passed through validation. This establishes actual executed work, not its fraction of total active CPU or an improvement estimate. Other scattered Objective-C parser observations also occur in the capture.

Installed objc2-0.6.4/src/macros/mod.rs:1000 documents per-message argument/return encoding validation with debug assertions. runtime/message_receiver.rs:294–337 and424–428 compile the call and helper under cfg(debug_assertions). The supported disable-encoding-assertions feature skips the signature check, but setting it on an ordinary dependency would unify into dev/test too. Therefore that default feature change does not meet the unchanged-verify requirement.

Preferred single scratch experiment:

```toml
[profile.dev-perf.package."objc2@0.6.4"]
debug-assertions = false
```

This version-specific profile override leaves application/Bevy assertions, overflow checks, and ordinary dev/test verification intact. It disables all objc2 debug assertions in dev-perf, including nil-receiver and class/ivar checks, not just encoding checks. The change is development-profile overhead reduction; normal release builds already disable these debug checks. Do not attribute it to renderer architecture or shipped runtime improvement.

Pair one unchanged source build against that one override, same dev-perf normal fixture/Fifo viewport, clean CPU energy sampling and separate stack diagnostic. Verify compile flags and disappearance of signature-check stacks, then keep only if repeatable and material. No source modifications or builds were performed for this review.

Primary references: installed pinned crate source above; https://doc.rust-lang.org/cargo/reference/profiles.html#overrides and https://github.com/madsmtm/objc2 (crate repository). Cargo profiles support package-specific debug-assertions overrides; the project normal verify does not select dev-perf.
