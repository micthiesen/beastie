from pathlib import Path
base=Path('/tmp/beastie-energy-20260909')
s=(base/'split-only.wgsl').read_text()
start=s.index('@compute @workgroup_size(8,8)')
extra='''
@group(0) @binding(12) var<storage,read_write> transport_samples:array<vec4<f32>>;
const REUSE_X:u32=2u;
const REUSE_Y:u32=2u;
struct PrimarySample { origin:vec3<f32>, direction:vec3<f32>, hit:Hit }
fn primary_sample(pixel:vec2<u32>) -> PrimarySample {
    let uv=(vec2<f32>(pixel)+vec2(0.25))/vec2<f32>(params.size.xy);
    let clip=vec2(uv.x*2.0-1.0,1.0-uv.y*2.0);
    let near=params.world_from_clip*vec4(clip,1.0,1.0);
    let far=params.world_from_clip*vec4(clip,0.0,1.0);
    let origin=near.xyz/near.w; let direction=normalize(far.xyz/far.w-origin);
    return PrimarySample(origin,direction,primary_hit(origin,direction,pixel,0u));
}
fn transport_offset(pixel:vec2<u32>) -> u32 {
    return (pixel.y/REUSE_Y)*((params.size.x+REUSE_X-1u)/REUSE_X)+pixel.x/REUSE_X;
}
fn share_eligible(hit:Hit) -> bool {
    if(hit.instance==0xffffffffu) { return false; }
    let instance=instances[hit.instance];
    return instance.material.w<0.5 && instance.material.z<0.5 && instance.material.x>=0.3 && instance.material.y<=0.3;
}
@compute @workgroup_size(8,8)
fn transport_frame(@builtin(global_invocation_id) gid:vec3<u32>) {
    let pixel=gid.xy*vec2(REUSE_X,REUSE_Y);
    if(any(pixel>=params.size.xy)) { return; }
    let primary=primary_sample(pixel);
    var transport=vec4(0.0);
    if(share_eligible(primary.hit)) {
        let cache_index=select(0xffffffffu,(pixel.y*params.size.x+pixel.x)*params.shadow_roots.z,params.shadow_roots.z>0u);
        transport=light_transport(primary.origin,primary.direction,primary.hit,cache_index);
    }
    transport_samples[transport_offset(pixel)]=transport;
}
'''
s=s[:start]+extra+s[start:]
needle='    if(any(gid.xy>=params.size.xy)) { return; }'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    let primary=primary_sample(gid.xy);
    let anchor_pixel=gid.xy/vec2(REUSE_X,REUSE_Y)*vec2(REUSE_X,REUSE_Y);
    let anchor=primary_sample(anchor_pixel);
    var reuse=false;
    if(share_eligible(primary.hit) && primary.hit.instance==anchor.hit.instance) {
        let n=normal_at(primary.hit,primary.direction);
        let na=normal_at(anchor.hit,anchor.direction);
        let p=primary.origin+primary.direction*primary.hit.t;
        let pa=anchor.origin+anchor.direction*anchor.hit.t;
        let delta=p-pa;
        reuse=triangles[primary.hit.triangle].surface==triangles[anchor.hit.triangle].surface
            && dot(n,na)>=0.9995 && dot(delta,delta)<=0.0009 && abs(dot(delta,n))<0.001;
    }
    let reused_transport=transport_samples[transport_offset(gid.xy)];
''')
s=s.replace('light=lighting(origin,direction,hit,cache_index);','light=lighting_reused(origin,direction,hit,cache_index,reused_transport,sample==0u && reuse);')
for x,y in [(2,1),(2,2),(4,2)]:
    out=s.replace('const REUSE_X:u32=2u;',f'const REUSE_X:u32={x}u;').replace('const REUSE_Y:u32=2u;',f'const REUSE_Y:u32={y}u;')
    (base/f'two-pass{x}x{y}.wgsl').write_text(out)
# Extend only the scratch benchmark to dispatch the transport producer.
p=base/'lighting-src/crates/beastie-game/src/ray_benchmark.rs';s=p.read_text()
needle='    let bindings = [0, 1, 2, 3, 4, 6];'
assert s.count(needle)==1
s=s.replace(needle,'''    let transport_enabled = crate::raytrace::probe_shader_source(probe).contains("fn transport_frame(");
    let transport_size: [u32; 2] = std::env::var("BEASTIE_REUSE_SIZE").unwrap_or_else(|_| "2x2".into())
        .split('x').map(|v| v.parse().unwrap()).collect::<Vec<_>>().try_into().unwrap();
    let transport_buffer = device.create_buffer(&wgpu::BufferDescriptor { label:Some("experiment transport"), size:u64::from(WIDTH.div_ceil(transport_size[0]))*u64::from(HEIGHT.div_ceil(transport_size[1]))*16,usage:wgpu::BufferUsages::STORAGE,mapped_at_creation:false });
    let transport_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {label: None, bind_group_layouts:&[Some(&pipeline.get_bind_group_layout(0))],immediate_size:0});
    let transport_pipeline = transport_enabled.then(|| device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor { label:Some("experiment transport"),layout:Some(&transport_layout),module:&shader,entry_point:Some("transport_frame"),compilation_options:Default::default(),cache:None }));
'''+needle)
needle='    let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {'
assert s.count(needle)==1
s=s.replace(needle,'''    if transport_enabled { entries.push(wgpu::BindGroupEntry{binding:12,resource:transport_buffer.as_entire_binding()}); }
'''+needle)
needle='''        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("offscreen trace_frame"),'''
assert s.count(needle)==1
s=s.replace(needle,'''        if let Some(pipeline) = &transport_pipeline {
            let mut pass=encoder.begin_compute_pass(&Default::default());
            pass.set_pipeline(pipeline);pass.set_bind_group(0,&bind,&[]);
            pass.dispatch_workgroups(WIDTH.div_ceil(transport_size[0]).div_ceil(8),HEIGHT.div_ceil(transport_size[1]).div_ceil(8),1);
        }
'''+needle)
# Reference is diagnostic only but must regenerate current transport inputs.
needle='''    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor::default());'''
assert s.count(needle)==1
s=s.replace(needle,'''    if let Some(pipeline) = &transport_pipeline {
        let mut pass=encoder.begin_compute_pass(&Default::default());
        pass.set_pipeline(pipeline);pass.set_bind_group(0,&bind,&[]);
        pass.dispatch_workgroups(WIDTH.div_ceil(transport_size[0]).div_ceil(8),HEIGHT.div_ceil(transport_size[1]).div_ceil(8),1);
    }
'''+needle)
p.write_text(s)
print('two-pass shaders and benchmark prepared')
