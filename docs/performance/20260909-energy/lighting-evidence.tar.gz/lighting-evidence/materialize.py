from pathlib import Path
import argparse, hashlib, json, subprocess, tarfile, tempfile
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
here=Path(__file__).resolve().parent;m=json.loads((here/'manifest.json').read_text())
if a.output.exists(): raise SystemExit('Output must not exist')
a.output.mkdir(parents=True)
with tempfile.TemporaryFile() as f:
    subprocess.run(['git','archive',m['base_commit']],cwd=a.repo,stdout=f,check=True);f.seek(0)
    with tarfile.open(fileobj=f) as t:t.extractall(a.output,filter='data')
subprocess.run(['git','apply',str(here/'harness.patch')],cwd=a.output,check=True)
for name,digest in m['source_sha256'].items():
    assert hashlib.sha256((a.output/name).read_bytes()).hexdigest()==digest,name
print('Verified harness:',a.output)
