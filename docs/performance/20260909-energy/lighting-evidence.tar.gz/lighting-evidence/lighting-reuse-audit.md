# Lighting reuse audit

Source: live crates/beastie-game/src/raytrace.wgsl, read-only audit 2026-09-09. No external implementation or secondary research was used. The conclusions below follow from the current shader dependencies.

## Existing reuse and remaining work

trace_frame:503 already reuses complete Lighting between coverage samples when instance IDs match and normal dot >=0.995. World surfaces use two coverage samples; overlay uses four (:509-513). Coverage, albedo and water_optics remain local. The settings plate already shares its behind-world continuation within each pixel (:521). Further intra-pixel reductions therefore have limited headroom.

lighting:320-450 combines discontinuous shadow visibility, diffuse bounce/contact, view-dependent reflection/specular, water caustics, four positional practical lights, and spatial grain. Whole-Lighting reuse across pixels would coarsen grain and caustics even on a single large floor triangle. Split LightTransport {visibility,indirect} from local assembly. Keep normal, albedo, direct angular term, transmission, reflected direction/ray, specular, caustics, practical lights, grain and all water optics at the original sample positions. The leaf-color conditional indirect contribution (:443-445) should remain local as well.

## Preferred bounded experiment

Compare 2x1 workgroup-local diffuse indirect reuse against unchanged control, then 2x2 only if warranted. Use existing 8x8 groups and no image-sized auxiliary buffer. Eligibility: static instance (pad1!=0), same instance and surface or triangle, roughness>=0.9, metallic<=0.05, no overlay/unlit material, zero transmission, matching oriented geometric normals as well as tightly matching shading normals, finite hit positions and a strict absolute world-space span cap. Flat triangle vertex normals provide a stronger initial scope than approximate smooth-normal matching. A normal dot alone is not a coplanarity test.

Keep shadow visibility per pixel in the first variant. Sharing indirect is still approximate: matching the receiver surface does not establish matching bounce occlusion. A leader's miss does not prove neighbors miss thin contact geometry. Do not call this exact. A short-distance leader bounce should disqualify its tile to protect contact darkening; this is a useful visual guard, not proof against unseen neighboring blockers.

All lanes must reach workgroup barriers, including viewport-overflow lanes. Cache IDs and bounce bits24/25 stay per pixel/sample. Never copy a leader's complete cache record to a neighboring receiver. Leave skipped cache entries untouched and validate identity before any future use. Secondary coverage samples must retain the original fallback on instance/normal mismatch. Keep diagnostics and no-shadows probes behavior consistent.

## Exact shadow reuse control

For eligible static receivers, cached static occlusion bits must be known and identical for every used direction. For dynamic maps, require matching texel coordinates, then evaluate the single sampled depth against every receiver's projected depth. All distances in (0.0001,35) means uniformly blocked; all <=0.0001 means uniformly clear; empty sampled depth means clear. A receiver at distance>=35 needs original finite-limit traversal. Matching map texels alone is insufficient when receivers straddle caster depth.

Shared first-six bits and identical refine_shadow establish the same 6/12 sample decision. Additional directions require the same proof if refinement occurs. This is exact relative to the existing mapped renderer, including its existing sampling approximation. Whether it wins is uncertain: extra clip transforms, comparisons and barriers may cost more than hardware-cached texture loads. It is a useful correctness/performance control for a separately named approximate visibility+indirect variant.

## Ranked alternatives and stopping evidence

1. Static rough-surface indirect sharing: bounded scope, zero full-frame allocation, targets remaining dynamic bounce traversal and surface reconstruction. Measure an indirect-disabled upper bound on the current map renderer first; historical no-bounce figures cannot predict the new architecture precisely.
2. Shadow visibility sharing only with the proof above, or a separately labeled approximate variant with native shadow-motion acceptance. No claim that receiver IDs or normals alone preserve shadows.
3. Exact temporal reuse of evaluated static bounce attributes: current cached_bounce already retains stable target IDs while querying dynamic blockers. Storing final static contribution saves attribute loads/interpolation but adds per-pixel storage and traffic. Its upper bound is only the attribute work after existing traversal caching. Do not build without an ablation showing this work is material.
4. General previous-frame shading reuse is poorly matched: animated water and moving caster shadows change even stationary geometry. Reprojection/temporal validation adds bandwidth, history and disocclusion risks. Existing stable-ID static caches already preserve the directly reusable traversal work. No current evidence justifies a full temporal framework.

## Evidence needed before acceptance

Use identical source/control and serial paired measurements, including warmed workgroup occupancy, native p99 and sustained energy-related work at the same presentation cadence. Separate bounce-only and shadow+indirect variants. Preserve half-float images for error comparison. Review moving contact shadows under the creature, silhouettes, curved head/fins, camera changes, UI overlays and transitions, water caustics, thin glyphs and odd viewport sizes. Check tile-aligned temporal block patterns rather than only global mean error. Exact variant should match original RGB bit-for-bit; approximate variants need native visual acceptance, and motion outcomes can reject a favorable GPU timing result.
