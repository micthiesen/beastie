from pathlib import Path
import subprocess,json,os,shutil,sys
base=Path('/tmp/beastie-energy-20260909')
if not (base/'lighting-tests').exists():
    rows=[json.loads(line) for line in (base/'lighting-build.jsonl').read_text().splitlines() if line.startswith('{')]
    paths=[r['executable'] for r in rows if r.get('executable') and r.get('target',{}).get('name')=='beastie-game']
    shutil.copy2(paths[-1],base/'lighting-tests')
names=sys.argv[1:] or ['control','split-only','reuse2x1','reuse2x2','reuse2x2strict','reuse4x2','control']
for i,name in enumerate(names):
    key=f'lighting-{i:02d}-{name}'
    env=dict(os.environ,BEASTIE_EXPERIMENT_SHADER=str(base/f'{name}.wgsl'),BEASTIE_BENCH_SUBMISSION='batched',BEASTIE_BENCH_OUTPUT=str(base/f'{key}.json'),BEASTIE_BENCH_PNG=str(base/f'{key}.png'))
    if name.startswith('two-pass'): env['BEASTIE_REUSE_SIZE']=name.removeprefix('two-pass')
    if name.startswith('packed'): env['BEASTIE_PIXELS_PER_THREAD']=name.removeprefix('packed')
    for test,args in [('ray_validation::experiment_shader_translates',[]),('ray_benchmark::offscreen_renderer_benchmark',['--ignored'])]:
        with (base/f'{key}-{test.split("::")[0]}.log').open('w') as log:
            result=subprocess.run([str(base/'lighting-tests'),test,'--exact','--nocapture']+args,env=env,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode: print(key,test,'FAILED',flush=True); break
    else:
        r=json.loads((base/f'{key}.json').read_text())
        print(key,r['gpu_timing_summary']['batched_gpu_envelope_per_dispatched_frame_ms'],flush=True)
