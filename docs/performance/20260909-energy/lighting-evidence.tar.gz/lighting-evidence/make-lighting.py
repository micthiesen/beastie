from pathlib import Path
base=Path('/tmp/beastie-energy-20260909'); original=(base/'control.wgsl').read_text()
start=original.index('fn lighting('); end=original.index('\nfn primary_hit(',start)
old=original[start:end]
prefix=old[:old.index('    let can_cache=')]
body=old[old.index('    let can_cache='):old.index('    let rough=')]
body=body.replace('    let diffuse=max(dot(n,key),0.0)*visibility;\n','')
body+='    if(can_cache) { shadow_masks[record]=mask; }\n    return vec4(indirect,visibility);\n}\n'
prefix=prefix.replace('fn lighting(o:vec3<f32>,d:vec3<f32>,hit:Hit,cache_index:u32) -> Lighting {','fn light_transport(o:vec3<f32>,d:vec3<f32>,hit:Hit,cache_index:u32) -> vec4<f32> {')
prefix=prefix.replace('return Lighting(vec3(0.0),vec3(0.038,0.067,0.072));','return vec4(0.0);').replace('return Lighting(vec3(0.85+0.2*max(dot(n,light),0.0)),vec3(0.0));','return vec4(0.0);').replace('return Lighting(vec3(1.0),vec3(0.0));','return vec4(0.0);')
cheap=old[:old.index('    let can_cache=')].replace('fn lighting(', 'fn lighting_reused(').replace('cache_index:u32) -> Lighting','cache_index:u32, reused:vec4<f32>, reuse:bool) -> Lighting')
cheap+='''    var transport=reused;
    if(!reuse) { transport=light_transport(o,d,hit,cache_index); }
    let visibility=transport.w;
    var indirect=transport.xyz;
    let softness=instances[hit.instance].transmission;
    let diffuse=max(dot(n,key),0.0)*visibility;
'''+old[old.index('    let rough='):]
cheap=cheap.replace('    if(can_cache) { shadow_masks[record]=mask; }\n','')
wrapper='''
fn lighting(o:vec3<f32>,d:vec3<f32>,hit:Hit,cache_index:u32) -> Lighting {
    return lighting_reused(o,d,hit,cache_index,vec4(0.0),false);
}
'''
split=original[:start]+prefix+body+cheap+wrapper+original[end:]
(base/'split-only.wgsl').write_text(split)
prepass='''
var<workgroup> shared_transport:array<vec4<f32>,64>;
var<workgroup> shared_normal:array<vec3<f32>,64>;
var<workgroup> shared_position:array<vec3<f32>,64>;
var<workgroup> shared_ids:array<vec2<u32>,64>;
const REUSE_X:u32=2u;
const REUSE_Y:u32=2u;
const REUSE_DISTANCE:f32=0.03;
const REUSE_NORMAL:f32=0.9995;
fn share_eligible(hit:Hit) -> bool {
    if(hit.instance==0xffffffffu) { return false; }
    let instance=instances[hit.instance];
    return instance.material.w<0.5 && instance.material.z<0.5 && instance.material.x>=0.3 && instance.material.y<=0.3;
}
'''
shader=split.replace('@compute @workgroup_size(8,8)',prepass+'\n@compute @workgroup_size(8,8)')
shader=shader.replace('fn trace_frame(@builtin(global_invocation_id) gid:vec3<u32>) {\n    if(any(gid.xy>=params.size.xy)) { return; }','''fn trace_frame(@builtin(global_invocation_id) gid:vec3<u32>, @builtin(local_invocation_index) lane:u32) {
    let in_bounds=all(gid.xy<params.size.xy);
    let local=vec2(lane%8u,lane/8u);
    let anchor=(local.y/REUSE_Y*REUSE_Y)*8u+(local.x/REUSE_X*REUSE_X);
    let anchor_lane=lane==anchor;
    let uv0=(vec2<f32>(gid.xy)+vec2(0.25))/vec2<f32>(params.size.xy);
    let clip0=vec2(uv0.x*2.0-1.0,1.0-uv0.y*2.0);
    let near0=params.world_from_clip*vec4(clip0,1.0,1.0);
    let far0=params.world_from_clip*vec4(clip0,0.0,1.0);
    let origin0=near0.xyz/near0.w; let direction0=normalize(far0.xyz/far0.w-origin0);
    var hit0=Hit(1500.0,0.0,0.0,0u,0xffffffffu);
    if(in_bounds) { hit0=primary_hit(origin0,direction0,gid.xy,0u); }
    let eligible=share_eligible(hit0);
    var n0=vec3(0.0);
    if(eligible) { n0=normal_at(hit0,direction0); }
    let position0=origin0+direction0*hit0.t;
    if(anchor_lane) {
        shared_ids[lane]=vec2(hit0.instance,0xffffffffu);
        shared_normal[lane]=n0; shared_position[lane]=position0;
        if(eligible) {
            shared_ids[lane].y=triangles[hit0.triangle].surface;
            let cache_index=select(0xffffffffu,(gid.y*params.size.x+gid.x)*params.shadow_roots.z,params.shadow_roots.z>0u);
            shared_transport[lane]=light_transport(origin0,direction0,hit0,cache_index);
        }
    }
    workgroupBarrier();
    if(!in_bounds) { return; }
    var reuse=false;
    if(eligible && shared_ids[anchor].x==hit0.instance) {
        let delta=position0-shared_position[anchor];
        reuse=shared_ids[anchor].y==triangles[hit0.triangle].surface
            && dot(n0,shared_normal[anchor])>=REUSE_NORMAL
            && dot(delta,delta)<=REUSE_DISTANCE*REUSE_DISTANCE
            && abs(dot(delta,n0))<0.001;
    }
    let reused_transport=shared_transport[anchor];''')
shader=shader.replace('light=lighting(origin,direction,hit,cache_index);','light=lighting_reused(origin,direction,hit,cache_index,reused_transport,sample==0u && reuse);')
for name,x,y,dot,dist in [('reuse2x1',2,1,.9995,.03),('reuse2x2',2,2,.9995,.03),('reuse2x2strict',2,2,.9999,.02),('reuse4x2',4,2,.9995,.04)]:
    s=shader.replace('const REUSE_X:u32=2u;',f'const REUSE_X:u32={x}u;').replace('const REUSE_Y:u32=2u;',f'const REUSE_Y:u32={y}u;').replace('const REUSE_NORMAL:f32=0.9995;',f'const REUSE_NORMAL:f32={dot};').replace('const REUSE_DISTANCE:f32=0.03;',f'const REUSE_DISTANCE:f32={dist};')
    (base/f'{name}.wgsl').write_text(s)
print('made split-only and four reuse candidates')
