#!/usr/bin/env python3
"""Generate bounce-only sharing experiments; never touches live sources or builds."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('split',type=Path,nargs='?',default=Path(__file__).with_name('split-only.wgsl'));p.add_argument('reuse',type=Path,nargs='?',default=Path(__file__).with_name('reuse2x1.wgsl'));p.add_argument('--output',type=Path,default=Path(__file__).parent);args=p.parse_args()
split=args.split.read_text();reuse=args.reuse.read_text();args.output.mkdir(parents=True,exist_ok=True)
def replace(source,old,new):
 assert source.count(old)==1,(old,source.count(old));return source.replace(old,new,1)
def transport(source):
 source=replace(source,'fn light_transport(o:vec3<f32>,d:vec3<f32>,hit:Hit,cache_index:u32) -> vec4<f32> {','fn light_transport(o:vec3<f32>,d:vec3<f32>,hit:Hit,cache_index:u32, reused_indirect:vec3<f32>, bounce_reuse:bool, bounce_only:bool) -> vec4<f32> {')
 source=replace(source,'    if(RENDER_PROBE!=2u) {','    if(!bounce_only && RENDER_PROBE!=2u) {')
 source=replace(source,'    var indirect=environment(n)*0.30;','    var indirect=environment(n)*0.30;\n    var bounce_distance=2.5;\n    if(bounce_reuse) { indirect=reused_indirect; }')
 source=replace(source,'    if(RENDER_PROBE!=3u) {','    if(!bounce_reuse && RENDER_PROBE!=3u) {')
 source=replace(source,'        if(bounce.instance!=0xffffffffu) {\n            let bounce_base=', '        bounce_distance=bounce.t;\n        if(bounce.instance!=0xffffffffu) {\n            let bounce_base=')
 source=replace(source,'    return vec4(indirect,visibility);','    return vec4(indirect,select(visibility,bounce_distance,bounce_only));')
 source=replace(source,'    var transport=reused;\n    if(!reuse) { transport=light_transport(o,d,hit,cache_index); }','    // Visibility always evaluates at this receiver. Only indirect may be shared.\n    let transport=light_transport(o,d,hit,cache_index,reused.xyz,reuse,false);')
 return source
control=transport(split)
candidate=transport(reuse)
candidate=replace(candidate,'var<workgroup> shared_normal:array<vec3<f32>,64>;','var<workgroup> shared_normal:array<vec3<f32>,64>;\nvar<workgroup> shared_geometric:array<vec3<f32>,64>;')
candidate=replace(candidate,'const REUSE_NORMAL:f32=0.9995;','const REUSE_NORMAL:f32=0.99999;')
candidate=replace(candidate,'    return instance.material.w<0.5 && instance.material.z<0.5 && instance.material.x>=0.3 && instance.material.y<=0.3;','''    let surface=surfaces[triangles[hit.triangle].surface];
    return instance.pad1!=0u && instance.material.w<0.5 && instance.material.z<0.5
        && instance.material.x>=0.9 && instance.material.y<=0.05 && instance.transmission==0.0
        && all(surface.n0.xyz==surface.n1.xyz) && all(surface.n0.xyz==surface.n2.xyz);''')
candidate=replace(candidate,'@compute @workgroup_size(8,8)','''fn reuse_geometric(hit:Hit,direction:vec3<f32>) -> vec3<f32> {
    let triangle=triangles[hit.triangle];
    var normal=normalize((transpose(instances[hit.instance].inverse)*vec4(cross(triangle.e1.xyz,triangle.e2.xyz),0.0)).xyz);
    if(dot(normal,direction)>0.0) {normal=-normal;}
    return normal;
}
@compute @workgroup_size(8,8)''')
candidate=replace(candidate,'    if(eligible) { n0=normal_at(hit0,direction0); }','    var geometric0=vec3(0.0);\n    if(eligible) { n0=normal_at(hit0,direction0); geometric0=reuse_geometric(hit0,direction0); }')
candidate=replace(candidate,'        shared_normal[lane]=n0; shared_position[lane]=position0;','        shared_normal[lane]=n0; shared_position[lane]=position0; shared_geometric[lane]=geometric0;\n        shared_transport[lane]=vec4(0.0);')
candidate=replace(candidate,'            shared_transport[lane]=light_transport(origin0,direction0,hit0,cache_index);','''            // Leader computes bounce only here. Its shadow loop runs once below.
            // Its own cache keeps its own shadow bits and bounce ambiguity state.
            shared_transport[lane]=light_transport(origin0,direction0,hit0,cache_index,vec3(0.0),false,true);''')
candidate=replace(candidate,'            && dot(n0,shared_normal[anchor])>=REUSE_NORMAL','            && dot(n0,shared_normal[anchor])>=REUSE_NORMAL\n            && dot(geometric0,shared_geometric[anchor])>=REUSE_NORMAL\n            && (anchor_lane || shared_transport[anchor].w>=0.85)')
# The leader always consumes its already computed bounce, even at contact distances.
# Followers reject close leader contacts. Their unseen thin contacts remain an
# approximation requiring motion acceptance; no identity/normal guard proves them absent.
candidate=replace(candidate,'    let reused_transport=shared_transport[anchor];','    reuse=reuse || (anchor_lane && eligible);\n    let reused_transport=shared_transport[anchor];')
outputs={'bounce-split-control.wgsl':control,'bounce-only2x1.wgsl':candidate,'bounce-only2x2.wgsl':replace(candidate,'const REUSE_Y:u32=1u;','const REUSE_Y:u32=2u;')}
for name,data in outputs.items():(args.output/name).write_text(data)
(args.output/'bounce-variant-manifest.json').write_text(json.dumps({'inputs':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [args.split,args.reuse]},'outputs':{name:hashlib.sha256(data.encode()).hexdigest() for name,data in outputs.items()}},indent=2)+'\n')
print('\n'.join(str(args.output/name) for name in outputs))
