from pathlib import Path
b=Path('/tmp/beastie-energy-20260909');s=(b/'control.wgsl').read_text()
old='''    let material=instances[hit.instance].material; let base=albedo_at(hit);
    let n=normal_at(hit,d); let p=o+d*hit.t;'''
new='''    let material=instances[hit.instance].material;
    if(material.z>0.5 && material.w<=0.5) { return Lighting(vec3(1.0),vec3(0.0)); }
    let base=albedo_at(hit);
    let n=normal_at(hit,d); let p=o+d*hit.t;'''
assert s.count(old)==1;s=s.replace(old,new)
(b/'unlit-early.wgsl').write_text(s)
old='        if(hit.instance!=0xffffffffu) { base=albedo_at(hit); n=normal_at(hit,direction); }'
new='''        if(hit.instance!=0xffffffffu) {
            base=albedo_at(hit);
            let material=instances[hit.instance].material;
            if(material.z>0.5 && material.w<=0.5) { n=vec3(0.0,0.0,1.0); }
            else { n=normal_at(hit,direction); }
        }'''
assert s.count(old)==1;s=s.replace(old,new)
(b/'unlit-normal.wgsl').write_text(s)
