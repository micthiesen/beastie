from pathlib import Path
import json,shutil,subprocess,os
b=Path('/tmp/beastie-energy-20260909')
rows=[json.loads(s) for s in (b/'packed-build.jsonl').read_text().splitlines() if s.startswith('{')]
paths=[r['executable'] for r in rows if r.get('executable') and r.get('target',{}).get('name')=='beastie-game']
shutil.copy2(paths[-1],b/'lighting-tests')
subprocess.run(['python3',str(b/'run-lighting.py'),'control','packed2x1','packed1x2','packed2x2','packed4x1','water-split-control','water-reuse','control'],check=True)
