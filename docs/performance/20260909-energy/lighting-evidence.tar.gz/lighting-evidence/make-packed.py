from pathlib import Path
base=Path('/tmp/beastie-energy-20260909');s=(base/'split-only.wgsl').read_text()
extra='''
const PIXELS_X:u32=2u;
const PIXELS_Y:u32=1u;
fn share_eligible(hit:Hit) -> bool {
    if(hit.instance==0xffffffffu) { return false; }
    let instance=instances[hit.instance];
    return instance.material.w<0.5 && instance.material.z<0.5 && instance.material.x>=0.3 && instance.material.y<=0.3;
}
'''
s=s.replace('@compute @workgroup_size(8,8)',extra+'\n@compute @workgroup_size(8,8)')
s=s.replace('''fn trace_frame(@builtin(global_invocation_id) gid:vec3<u32>) {
    if(any(gid.xy>=params.size.xy)) { return; }''','''fn trace_frame(@builtin(global_invocation_id) dispatch_id:vec3<u32>) {
    var anchor_transport=vec4(0.0);
    var anchor_normal=vec3(0.0); var anchor_position=vec3(0.0);
    var anchor_instance=0xffffffffu; var anchor_surface=0xffffffffu;
    for(var pixel_index=0u;pixel_index<PIXELS_X*PIXELS_Y;pixel_index++) {
    let gid=vec3(dispatch_id.xy*vec2(PIXELS_X,PIXELS_Y)+vec2(pixel_index%PIXELS_X,pixel_index/PIXELS_X),0u);
    if(any(gid.xy>=params.size.xy)) { continue; }''')
needle='            light=lighting(origin,direction,hit,cache_index);';assert s.count(needle)==1
s=s.replace(needle,'''            var reuse=false;
            if(sample==0u && share_eligible(hit)) {
                let p=origin+direction*hit.t;
                let surface=triangles[hit.triangle].surface;
                if(pixel_index==0u) {
                    anchor_transport=light_transport(origin,direction,hit,cache_index);
                    anchor_normal=n; anchor_position=p; anchor_instance=hit.instance; anchor_surface=surface;
                    reuse=true;
                } else {
                    let delta=p-anchor_position;
                    reuse=hit.instance==anchor_instance && surface==anchor_surface
                        && dot(n,anchor_normal)>=0.9995 && dot(delta,delta)<=0.0009 && abs(dot(delta,n))<0.001;
                }
            }
            light=lighting_reused(origin,direction,hit,cache_index,anchor_transport,reuse);''')
s+='\n}\n'
for x,y in [(2,1),(1,2),(2,2),(4,1)]:
    out=s.replace('const PIXELS_X:u32=2u;',f'const PIXELS_X:u32={x}u;').replace('const PIXELS_Y:u32=1u;',f'const PIXELS_Y:u32={y}u;')
    (base/f'packed{x}x{y}.wgsl').write_text(out)
p=base/'lighting-src/crates/beastie-game/src/ray_benchmark.rs';s=p.read_text()
needle='    let transport_enabled =';assert s.count(needle)==1
s=s.replace(needle,'''    let pixel_span: [u32;2] = std::env::var("BEASTIE_PIXELS_PER_THREAD").unwrap_or_else(|_| "1x1".into()).split('x').map(|v| v.parse().unwrap()).collect::<Vec<_>>().try_into().unwrap();
'''+needle)
needle='pass.dispatch_workgroups(WIDTH.div_ceil(8), HEIGHT.div_ceil(8), 1);';assert s.count(needle)==2
s=s.replace(needle,'pass.dispatch_workgroups(WIDTH.div_ceil(pixel_span[0]).div_ceil(8), HEIGHT.div_ceil(pixel_span[1]).div_ceil(8), 1);')
p.write_text(s)
