#!/usr/bin/env python3
"""Generate affine water control and guarded intra-pixel reuse; scratch only."""
from pathlib import Path
import argparse,json,hashlib
parser=argparse.ArgumentParser();parser.add_argument('source',type=Path,nargs='?',default=Path(__file__).with_name('control.wgsl'));parser.add_argument('--output',type=Path,default=Path(__file__).parent);args=parser.parse_args();original=args.source.read_text()
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
a=original.index('fn water_optics(');b=original.index('\nfn environment(',a);water=original[a:b]
# Keep original detailed surface arithmetic, including ripple/noise/mix, intact.
old=replace(water,'fn water_optics(', 'fn water_optics_original(')
start=water.index('    let time=params.water.x;');stop=water.index('    // Analytic thin surface:')
body=water[start:stop]
body=replace(body,'    var result=color*transmission+ambient*(vec3(1.0)-transmission)*0.65;','    var scale=transmission;\n    var additive=ambient*(vec3(1.0)-transmission)*0.65;')
body=replace(body,'    result+=vec3(0.12,0.30,0.29)*shafts*0.74*clamp(depth/3.0,0.0,1.0);','    additive+=vec3(0.12,0.30,0.29)*shafts*0.74*clamp(depth/3.0,0.0,1.0);')
body=replace(body,'        result*=1.0-(1.0-high)*center*0.32;','        let backdrop_scale=1.0-(1.0-high)*center*0.32;\n        scale*=backdrop_scale; additive*=backdrop_scale;')
body=replace(body,'        result+=vec3(0.005,0.052,0.063)*high*high*center;','        additive+=vec3(0.005,0.052,0.063)*high*high*center;')
helpers='''
struct WaterTransfer { scale:vec3<f32>, additive:vec3<f32>, detailed:bool }
const REUSE_WATER_TRANSFER:bool=false;
// Only smooth volume attenuation/shafts may share. Each coverage ray separately
// checks the original volume bounds and analytic-surface intersection conditions.
fn smooth_water_transfer(o:vec3<f32>,d:vec3<f32>,hit:Hit) -> bool {
    if(hit.instance==0xffffffffu || instances[hit.instance].material.w>0.5) { return false; }
    let p=o+d*hit.t;
    if(abs(p.x)>7.75 || p.y < -2.13 || p.y>4.60 || p.z>2.15) { return false; }
    if(abs(d.y)>0.0001) {
        let surface_t=(4.02-o.y)/d.y;
        let surface=o+d*surface_t;
        if(surface_t>0.0 && surface_t<hit.t && abs(surface.x)<7.74 && surface.z > -0.6 && surface.z<2.10) { return false; }
    }
    return true;
}
fn water_transfer(o:vec3<f32>,d:vec3<f32>,hit:Hit) -> WaterTransfer {
    if(!smooth_water_transfer(o,d,hit)) { return WaterTransfer(vec3(1.0),vec3(0.0),true); }
    let p=o+d*hit.t;
'''+body+'''    return WaterTransfer(scale,additive,false);
}
fn apply_water_transfer(color:vec3<f32>,o:vec3<f32>,d:vec3<f32>,hit:Hit,transfer:WaterTransfer) -> vec3<f32> {
    if(transfer.detailed) { return water_optics_original(color,o,d,hit); }
    return color*transfer.scale+transfer.additive;
}
fn water_optics(color:vec3<f32>,o:vec3<f32>,d:vec3<f32>,hit:Hit) -> vec3<f32> {
    return apply_water_transfer(color,o,d,hit,water_transfer(o,d,hit));
}
'''
s=original[:a]+old+helpers+original[b:]
s=replace(s,'    var behind=vec3(0.0); var behind_ready=false;','    var behind=vec3(0.0); var behind_ready=false;\n    var first_water=WaterTransfer(vec3(1.0),vec3(0.0),true);\n    var first_water_position=vec3(0.0);')
s=replace(s,'        if(RENDER_PROBE!=5u) { sample_color=water_optics(sample_color,origin,direction,hit); }','''        if(RENDER_PROBE!=5u) {
            let water_position=origin+direction*hit.t;
            let delta=water_position-first_water_position;
            var transfer=first_water;
            let water_reuse=REUSE_WATER_TRANSFER && sample>0u && !first_water.detailed
                && hit.instance==first.instance && dot(n,first_normal)>=0.9999
                && (water_position.z < -2.0)==(first_water_position.z < -2.0)
                && dot(delta,delta)<=0.03*0.03 && abs(dot(delta,n))<0.0005
                && smooth_water_transfer(origin,direction,hit);
            if(!water_reuse) { transfer=water_transfer(origin,direction,hit); }
            sample_color=apply_water_transfer(sample_color,origin,direction,hit,transfer);
            if(sample==0u) { first_water=transfer; first_water_position=water_position; }
        }''')
outputs={'water-split-control.wgsl':s,'water-reuse.wgsl':replace(s,'const REUSE_WATER_TRANSFER:bool=false;','const REUSE_WATER_TRANSFER:bool=true;')}
args.output.mkdir(parents=True,exist_ok=True)
for name,source in outputs.items():(args.output/name).write_text(source)
(args.output/'water-variant-manifest.json').write_text(json.dumps({'input':{str(args.source):hashlib.sha256(original.encode()).hexdigest()},'outputs':{name:hashlib.sha256(source.encode()).hexdigest() for name,source in outputs.items()}},indent=2)+'\n')
print('\n'.join(str(args.output/name) for name in outputs))
