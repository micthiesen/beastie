from pathlib import Path
p=Path('/tmp/beastie-energy-20260909/lighting-src/crates/beastie-game/src/ray_benchmark.rs');s=p.read_text()
line='    let transport_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {label: None, bind_group_layouts:&[Some(&pipeline.get_bind_group_layout(0))],immediate_size:0});\n'
assert s.count(line)==1;s=s.replace(line,'').replace('layout:Some(&transport_layout)','layout:None')
needle='    let measurements = measure_frames(&device, &queue, |encoder, queries, query_index| {'
assert s.count(needle)==1
s=s.replace(needle,'''    let transport_entries: Vec<_> = entries.iter().filter(|entry| entry.binding != 5).cloned().collect();
    let transport_bind=transport_pipeline.as_ref().map(|pipeline| device.create_bind_group(&wgpu::BindGroupDescriptor {label:None,layout:&pipeline.get_bind_group_layout(0),entries:&transport_entries}));
'''+needle)
assert s.count('pass.set_pipeline(pipeline);pass.set_bind_group(0,&bind,&[]);')==2
s=s.replace('pass.set_pipeline(pipeline);pass.set_bind_group(0,&bind,&[]);','pass.set_pipeline(pipeline);pass.set_bind_group(0,transport_bind.as_ref().unwrap(),&[]);')
p.write_text(s)
