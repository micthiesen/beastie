# Shadow geometry LOD and asynchronous preparation, 2026-09-09

Accepted: simplify only dynamic shadow geometry with meshoptimizer 0.6.2, fixed absolute world metric budget 0.002, retaining all primary geometry and exact original shadow indices. Reconstruct original positions without quantization. A Frobenius norm cap of 4 covers rotation, nonuniform scaling and shear; instances above it draw original indices. The meshoptimizer error estimate is not a Hausdorff certificate. Native still and consecutive-frame review provides the visual acceptance evidence.

A single Bevy AsyncComputeTaskPool job prepares welded/simplified geometry and encoded upload payloads. Until its scene key matches the current scene, render current original triangles through the existing Depth16 pipeline. Old GPU indices are never drawn under a mismatched key. Stale/disabled results retain the CPU cache but do not upload. The cache owns source triangle Arcs, survives arena relocation, and counts all Vec capacities. Inactive LRU retention is limited to 32 MiB and 128 entries; the active working set, in-flight encoded payload and retained old GPU buffers are additional peak memory. Source references can share allocations with RayScene.

## Results

Frozen 1080p dynamic geometry: 197,364 triangles and 100,118 positions. LOD 0.002 uses 88,120 triangles, 55.4% fewer. GPU index/position storage increases from 3,970,256 to 5,027,696 bytes because original indices remain available. Actual scene maximum Frobenius norm 2.2891; corresponding global estimated world metric bound 0.001144.

Same-binary frozen sweep, total within-batch GPU envelope divided by 210 frames: controls 1.59454/1.59820 ms; LOD 0.0005=1.49987,0.001=1.49042,0.002=1.43673 ms. Warm completion medians: controls 1.41883/1.41671 ms, LOD 0.002=1.28925 ms. The harness uses 21 batches of 10 frames, 30 warmup frames; 162 warmed within-batch completion intervals exclude boundaries. This is the earlier 1080p renderer snapshot, before the later density policy integration.

Native churn uses the optimized development profile, uncapped rendering, the attached 17.4-second scenario and the same copied binary per pair. p99.9 uses nearest rank. All accepted runs have 2105 measured frames.

| Variant | p99.9 ms | Maximum ms | Frames above16 ms | Shadow preparation max ms |
| --- | ---: | ---: | ---: | ---: |
| Synchronous Arc cache control |10.088|12.055|0|3.801|
| Synchronous Arc cache LOD |11.094|18.342|1|9.874|
| Async control1 |9.045|9.553|0|0.598|
| Async LOD1 |8.994|9.787|0|0.664|
| Async LOD2 |8.987|9.146|0|0.668|
| Async control2 |8.927|9.574|0|0.645|

Diagnostic title entry: a previously hidden 41,652-triangle logo required 8.149 ms to weld/simplify. It was later evicted on return because retained capacities reached 45,999,152 bytes. Arc relocation caching alone did not solve a truly cold mesh. Background preparation removed the stall, including completion upload/pruning frames.

GPU oracle compared actual indexed LOD with retained original indices over 15 mutations plus 48 consecutive 17-ms poses. Maximum changed half-float RGB pixels 64/2,073,600; worst isolated linear-channel difference 0.15750122; worst per-frame mean absolute error 5.128723e-7. The 48 consecutive frames alone have worst mean 3.015492e-7. This is approximate, not pixel-equivalent. Included native-pixel filmstrips show frames 19–28 around the largest isolated error: original left, LOD right. Root inspected both face strips and first floor strip and accepted facial expression, bevels and contact appearance. Final combined density + LOD 4K oracle/native checks are separate integration obligations, not claimed by this package.

Tests: scratch `cargo test -p beastie-game ray_shadow_index -- --nocapture` passed 7 tests, including one-job scheduling, stale/disabled completion, Arc relocation and mesh-edit invalidation, eviction, exact position reconstruction and scale/shear fallback. The diagnostic CPU-report test is omitted from production; six behavioral tests remain. The 63-frame GPU oracle passed before the CPU-only asynchronous change. Four native async churn runs validate original-depth fallback and readiness transitions. Production compilation and final combined visual gate are owned by root.

## Reconstructing source

No executables, game assets or vendored dependencies are included. Base commit is 41c700631f090c1f4ffd57aee8d9000c03c6dc69. In a separate checkout/copy of that commit, apply `measured-async.patch` to reconstruct the stable scratch source used for the accepted async binary. It also includes the inherited renderer changes required by that scratch snapshot. Apply `production-delta.patch` afterwards to reconstruct the live combined density/LOD source snapshot taken when this package was created. Every selected Rust/WGSL/Cargo source hash is in `source-manifest.json`. Both patch applications were checked in independent source copies and every resulting source compared exactly. The archive does not require or alter the shared checkout.

The measured source retains scratch environment controls and optional cache diagnostics. Production delta fixes 0.002 and removes those runtime controls. Historical synchronous reports are retained, but their exact older source blobs were not frozen before the async refactor. The diagnostic log proves the cold-mesh mechanism; do not represent this archive as byte-identical reconstruction of those older binaries. Binary hashes identify the actual retained local executables used for the measurements.

Build from the reconstructed measured copy:

```sh
CARGO_HTTP_USER_AGENT='OpenAI File Downloader, XaiImageApiFetch/1.0' cargo test -p beastie-game ray_shadow_index -- --nocapture
CARGO_HTTP_USER_AGENT='OpenAI File Downloader, XaiImageApiFetch/1.0' cargo build --profile dev-perf -p beastie-game
```

Run the same copied optimized binary serially for control/LOD/LOD/control. Set `BEASTIE_SHADOW_LOD_ERROR=0` or `0.002`; no diagnostics for timing. Invoke:

```sh
beastie-game --fake-ai --script /absolute/path/renderer-perf-churn.jsonl --render-report /absolute/path/result.json --render-uncapped
```

The archived command scripts record original absolute paths and output names; adapt paths to your separate copy. For the frozen GPU harness, the script `commands/run-lod.py` records the ignored test and benchmark environment. For 63-frame image comparison use the test binary with `BEASTIE_SHADOW_LOD_ERROR=0.002 BEASTIE_LOD_CONSECUTIVE=1 BEASTIE_MAP_ORACLE_CAPTURE_DIR=/absolute/captures BEASTIE_CACHE_ORACLE_OUTPUT=/absolute/report.json` and test filter `moving_shadow_maps_preserve_bounded_image_error --ignored --nocapture`. Run only one GPU/native process at a time.

Primary implementation references: https://github.com/zeux/meshoptimizer/blob/master/src/meshoptimizer.h and https://github.com/zeux/meshoptimizer/blob/master/README.md . `LockBorder | ErrorAbsolute` simplification preserves border restrictions; target count 0 lets the error metric bound terminate simplification. No permissive/sloppy simplification or component pruning is used.
