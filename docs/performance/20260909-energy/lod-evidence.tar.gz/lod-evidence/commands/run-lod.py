import os,subprocess,json
from pathlib import Path
root=Path('/tmp/beastie-energy-20260909')
for name,error in [('control-1',None),('0005','0.0005'),('001','0.001'),('002','0.002'),('control-2',None)]:
 env=os.environ.copy();env.pop('BEASTIE_SHADOW_LOD_ERROR',None)
 if error:env['BEASTIE_SHADOW_LOD_ERROR']=error
 env.update(BEASTIE_BENCH_SUBMISSION='batched',BEASTIE_BENCH_OUTPUT=str(root/('lod-'+name+'.json')),BEASTIE_BENCH_PNG=str(root/('lod-'+name+'.png')))
 subprocess.run([str(root/'shadow-lod-tests'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,cwd=root/'shadow-lod-src',check=True)
 d=json.loads((root/('lod-'+name+'.json')).read_text());print(name,json.dumps(d['gpu_timing_summary']),flush=True)
