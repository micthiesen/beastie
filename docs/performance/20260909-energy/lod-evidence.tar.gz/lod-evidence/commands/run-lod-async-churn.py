from pathlib import Path
import subprocess,os
root=Path('/tmp/beastie-energy-20260909')
for name,error in [('async-control-1','0'),('async-002-1','0.002'),('async-002-2','0.002'),('async-control-2','0')]:
 env=os.environ.copy();env['BEASTIE_SHADOW_LOD_ERROR']=error
 with (root/('lod-'+name+'-churn.log')).open('w') as log:
  subprocess.run([str(root/'beastie-shadow-lod-async'),'--fake-ai','--script','/Users/michael/Code/beastie/fixtures/scenarios/renderer-perf-churn.jsonl','--render-report',str(root/('lod-'+name+'-churn.json')),'--render-uncapped'],cwd='/Users/michael/Code/beastie',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
