from pathlib import Path
import subprocess,os
root=Path('/tmp/beastie-energy-20260909')
for name,error in [('diagnostic-002','0.002')]:
 env=os.environ.copy();env['BEASTIE_SHADOW_LOD_ERROR']=error;env['BEASTIE_LOD_CACHE_DIAGNOSTIC']='1'
 with (root/('lod-'+name+'-churn.log')).open('w') as log:
  subprocess.run([str(root/'beastie-shadow-lod-diagnostic'),'--fake-ai','--script','/Users/michael/Code/beastie/fixtures/scenarios/renderer-perf-churn.jsonl','--render-report',str(root/('lod-'+name+'-churn.json')),'--render-uncapped'],cwd='/Users/michael/Code/beastie',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
