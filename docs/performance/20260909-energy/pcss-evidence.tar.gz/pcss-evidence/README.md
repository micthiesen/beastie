# Central-map PCSS experiment

Scratch base: git archive 41c7006. No live overlays. Only ray_shadow_maps.rs, raytrace.wgsl and ray_benchmark.rs are changed. The native render path is not adapted to fewer passes: use only the offscreen harness for this experiment.

## Primary sources and adaptation

Fernando, NVIDIA, Percentage-Closer Soft Shadows (2005): https://developer.download.nvidia.com/shaderlibrary/docs/shadow_PCSS.pdf

NVIDIA GPU Gems 3, section8.6: https://developer.nvidia.com/gpugems/gpugems3/part-ii-light-and-shadows/chapter-8-summed-area-variance-shadow-maps

PCSS first estimates average blocker depth, then uses a parallel-plane approximation to determine the filter footprint. This prototype adapts that mechanism to the game's directional disk: the original twelve direction vectors intersect the estimated central blocker plane. Thus the existing six-sample/refinement ordering and OR with exact static occlusion remain intact. It does not substitute a generic blur or unrelated light radius. No source code was copied.

## Controls and actual work

With BEASTIE_PCSS absent, the binary renders twelve original dynamic depth maps. With BEASTIE_PCSS=1, it renders one1024x1024 central orthographic depth map using the normalized key direction (0,.85,.65). The fit encloses all eight transformed corners of each dynamic-caster bound. map_count drives texture layers, camera buffers, render passes and reported allocation. Depth texture payload falls from48MiB to4MiB; uniform ABI remains unchanged for the comparison.

The blocker search is lazy, once per shaded receiver only if a dynamic query is needed. It reads the center plus two rings of the original twelve disk directions across the ray cone. Positive blockers contribute to average projected depth. Each final directional query intersects that estimated plane, reads central-map depth and preserves the original .0001 near threshold. Detected blocker distances at or beyond35 use the original dynamic ray query. Original static queries and their caches are unchanged. Cold/ambiguous bounce behavior is unchanged.

This is a bounded area-light approximation, not an exact traversal acceleration. Sparse blocker search may miss thin objects. The central map hides surfaces visible from another light direction. Averaging several blocker depths can misestimate contact softness. Depth texel discretization still affects self-shadowing. Empty sampled search regions are treated as clear, so finite-limit fallback does not prove correctness for unseen blockers. These are visual rejection conditions, not claims of equivalence.

## Ranking

1. Test this single-map directional-PCSS prototype first: maximum pass/memory reduction and a small implementation.
2. If it wins materially but fails due to central-view disocclusion, three directional maps could shorten angular distance from each query to its source map. That is a distinct follow-up requiring evidence; it is not implemented.
3. If search cost erases savings or contact artifacts remain visible, keep the twelve directional maps. A general temporal denoiser or deep shadow-map framework is outside this bounded experiment.

## Verification and measurement pending

No builds or GPU runs have been performed yet. Added CPU fixture checks central projection enclosure of actual scene vertices and projected finite-ray distance conversion for all twelve directions. Existing ray_validation tests translate the shared production shader to portable backends.

After the root grants the build/GPU slot:

```
cargo test -p beastie-game ray_shadow_maps -- --nocapture
cargo test -p beastie-game ray_validation -- --nocapture
```

Copy the resulting test binary before root/other agents reuse the shared target. Run original/candidate/original/candidate serially with BEASTIE_BENCH_SUBMISSION=batched, unique BEASTIE_BENCH_OUTPUT and BEASTIE_BENCH_PNG paths. Do not set BEASTIE_SHADOW_MAP_CONTROL=trace, since that disables the maps being compared. Candidate adds BEASTIE_PCSS=1; controls omit it entirely.

Use within-batch GPU envelopes and warmed completion intervals with batch boundaries removed, following the current harness implementation. Compare candidate images both to the paired twelve-map control and the original-ray reference produced by the harness. If promising, adapt the moving oracle separately before native visual acceptance. A still image alone cannot approve contact/disocclusion behavior.

## Completed result: rejected

Build and tests completed from `/private/tmp/beastie-energy-20260909/pcss-src`. Three projection/policy tests and six portable shader validation tests passed. The unrelated native traversal oracle was intentionally ignored. One copied test binary ran control/candidate/candidate/control serially.

| Run | All-batch envelopes /210, ms | Warm-batch envelopes/frame, ms | Warm within-batch p50, ms |
| --- | ---: | ---: | ---: |
| Control1 | 2.118567 | 2.034130 | 1.906041 |
| Candidate1 | 1.851190 | 1.805838 | 1.698041 |
| Candidate2 | 1.857435 | 1.812468 | 1.700500 |
| Control2 | 2.131212 | 2.058512 | 1.914166 |

Each run dispatched210 frames,30 warmup, and retained162 warmed within-batch intervals. The current harness excludes CPU gaps between ten-frame batches. These are throughput/cadence measurements, not overlapping individual pass durations.

Despite roughly12% lower GPU cost, the candidate visibly removes the ball's broad floor shadow and weakens the bell's contact shadow. Native-scale crops are retained. Compared to the paired twelve-map image,18,457 pixels differ, maximum97/255 sRGB;7,543 differ by more than8. Against original rays,18,502 half-float RGB pixels differ with mean absolute linear error0.000230188. The control has1,629 differing pixels and mean0.0000161987. This is a visible rejection in the stationary frame, so the conditional15-pose/consecutive-frame tests and native integration were not run.

The result rejects this bounded sparse central-map PCSS variant. It does not establish that every PCSS implementation fails. More complete blocker search or multiple central views would add work and complexity, and still require separate evidence. The single-map approximation is not an acceptable replacement for the current directional visibility in this scene.

## Durable source reproduction

manifest.json records the exact full base commit, changed-source hashes and copied-binary hash. pcss.patch is11,405 bytes and has been applied in a separate git-archive copy; all three reconstructed source hashes match. To reconstruct, create a plain directory with `git archive <base_commit>`, apply pcss.patch there, then use the earlier test commands. No full source clone or executable is included. Raw reports are untouched; summary.json collects their timing summaries. No live files were changed.
