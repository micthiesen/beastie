# Shadow prototypes, 2026-09-09

Reconstruct a source variant from any Beastie checkout containing the manifest base commit:

```sh
python3 materialize.py /path/to/beastie native /tmp/beastie-native-reproduction
cargo test -p beastie-game --profile dev-perf --no-run --manifest-path /tmp/beastie-native-reproduction/Cargo.toml
```

Variants: shadows (persistent static maps), indexed (isolated indexed dynamic draws), atlas
(indexed plus single-pass atlas), native (combined native adapter and Depth16 experiment).
Source and measured binary SHA-256 hashes are in manifest.json. The package does not require
original /tmp sources or binaries; build tools and normal project dependencies are required.
Raw JSON, logs and launch scripts are in reports. Script paths document the original run;
replace their scratch root with your reconstructed directory. Refer to manifest report notes
before interpreting allocation fields. GPU pass latency may overlap. Use bounded batch
GPU envelopes and warm intra-batch cadence, not the global envelope containing CPU gaps.

Native native-src uses startup diagnostic flags preserved only in this archived prototype:
BEASTIE_STATIC_MAP_CONTROL=rays disables static maps; BEASTIE_SHADOW_INDEXED=0 disables
indexed draws; BEASTIE_SHADOW_ATLAS=0 disables the atlas; BEASTIE_STATIC_MAP_SIZE=512/1024
selects static density; BEASTIE_SHADOW_DEPTH=16 selects Depth16 (default32).
No RTX features, scene simplification, lower sample count or light direction changes.
