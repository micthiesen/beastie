import os, subprocess, pathlib
base=pathlib.Path('/tmp/beastie-energy-20260909')
for name,indexed in [('control-before',False),('indexed',True),('indexed-repeat',True),('control-after',False)]:
    env=dict(os.environ,BEASTIE_STATIC_MAP_CONTROL='rays',BEASTIE_BENCH_OUTPUT=str(base/f'indexed-{name}.json'),BEASTIE_BENCH_PNG=str(base/f'indexed-{name}.png'))
    if indexed: env['BEASTIE_SHADOW_INDEXED']='1'
    else: env.pop('BEASTIE_SHADOW_INDEXED',None)
    with (base/f'indexed-{name}.log').open('w') as out:
        subprocess.run([str(base/'beastie-indexed-test'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True,cwd=base/'indexed-src')
    print(name, 'done',flush=True)
