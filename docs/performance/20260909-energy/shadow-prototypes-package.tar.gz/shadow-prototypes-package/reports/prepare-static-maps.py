from pathlib import Path
r=Path('/tmp/beastie-energy-20260909/shadows-src/crates/beastie-game/src')
p=r/'ray_shadow_maps.rs';s=p.read_text();a=s.index('pub fn fit(scene:');b=s.index('    let mut params =',a);s=s[:a]+'''pub fn fit(scene: &RayScene, enabled: bool) -> (ShadowMapParams, Vec<usize>) {
    fit_casters(scene, enabled, dynamic_casters(scene), RESOLUTION)
}

pub fn fit_static(scene: &RayScene, enabled: bool, resolution: u32) -> (ShadowMapParams, Vec<usize>) {
    let casters=scene.instances.iter().enumerate().filter_map(|(id,instance)|
        (instance.pad1!=0 && instance.material.w<=0.5 && instance.material.z<=0.5).then_some(id)).collect();
    fit_casters(scene, enabled, casters, resolution)
}

fn fit_casters(scene: &RayScene, enabled: bool, casters: Vec<usize>, resolution: u32) -> (ShadowMapParams, Vec<usize>) {
'''+s[b:];s=s.replace('info: UVec4::new(u32::from(enabled), RESOLUTION, 12, casters.len() as u32)','info: UVec4::new(u32::from(enabled), resolution, 12, casters.len() as u32)');p.write_text(s)
p=r/'raytrace.wgsl';s=p.read_text();marker='@group(0) @binding(11) var<uniform> shadow_map_params:ShadowMapParams;';assert marker in s;s=s.replace(marker,marker+'\n@group(0) @binding(12) var static_shadow_maps:texture_depth_2d_array;\n@group(0) @binding(13) var<uniform> static_map_params:ShadowMapParams;');a=s.index('fn dynamic_shadow_blocked');b=s.index('fn lighting',a);helper=s[a:b].replace('dynamic_shadow_blocked(origin:vec3<f32>,light:vec3<f32>,sample:u32)','static_shadow_blocked(origin:vec3<f32>,light:vec3<f32>,sample:u32,receiver:u32)').replace('shadow_map_params','static_map_params').replace('dynamic_shadow_maps','static_shadow_maps').replace('params.shadow_roots.y','params.shadow_roots.x').replace('if(static_map_params.info.x==0u)', 'if(static_map_params.info.x==0u || (static_map_params.info.z==0u && instances[receiver].pad1!=0u))');s=s[:b]+helper+s[b:];s=s.replace('let fixed_hit=trace_root(origin,light,35.0,true,true,params.shadow_roots.x);','let fixed_blocked=static_shadow_blocked(origin,light,s,hit.instance);').replace('if(fixed_hit.instance!=0xffffffffu)','if(fixed_blocked)').replace('blocked=trace_root(origin,light,35.0,true,true,params.shadow_roots.x).instance!=0xffffffffu;','blocked=static_shadow_blocked(origin,light,s,hit.instance);');p.write_text(s)
# Keep native layout unchanged until offscreen evidence merits the adapter.
p=r/'raytrace.rs';s=p.read_text();s=s.replace('let source = include_str!("raytrace.wgsl");','let source = if cfg!(test) { include_str!("raytrace.wgsl") } else { include_str!("raytrace_shipped_reference.wgsl") };',1);p.write_text(s)
