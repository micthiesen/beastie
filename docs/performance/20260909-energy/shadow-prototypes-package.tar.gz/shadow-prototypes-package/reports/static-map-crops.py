from pathlib import Path
from PIL import Image,ImageChops,ImageDraw
import json
r=Path('/tmp/beastie-energy-20260909');o=r/'static-map-visual-review';o.mkdir(exist_ok=True);metrics=[]
for stem in ['00-cold','02-creature-left-low','03-creature-right-low','04-carried-ball','06-ball-right-plant-sway','08-title']:
 ims=[Image.open(r/f'staticmaps-motion{suffix}'/f'{stem}-maps.png').convert('RGB') for suffix in ['-control','512','1024']]
 row={'frame':stem}
 for n,im in zip(['512','1024'],ims[1:]):
  dif=ImageChops.difference(ims[0],im);p=list(dif.getdata());idx,val=max(enumerate(p),key=lambda v:max(v[1]));y,x=divmod(idx,im.width);row[n]={'changed_pixels':sum(any(v) for v in p),'max_code_difference':max(val),'worst_position':[x,y]}
 x,y=row['512']['worst_position'];bounds=(max(0,x-50),max(0,y-40),min(1920,x+50),min(1080,y+40))
 for scale in [1,4]:
  w=(bounds[2]-bounds[0])*scale;h=(bounds[3]-bounds[1])*scale;out=Image.new('RGB',(w*3,h+16));draw=ImageDraw.Draw(out)
  for i,(label,im) in enumerate(zip(['shipped','static512','static1024'],ims)):
   draw.text((i*w,0),label,fill='white');out.paste(im.crop(bounds).resize((w,h),Image.Resampling.NEAREST),(i*w,16))
  out.save(o/f'{stem}-{scale}x.png')
 metrics.append(row)
(o/'metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
