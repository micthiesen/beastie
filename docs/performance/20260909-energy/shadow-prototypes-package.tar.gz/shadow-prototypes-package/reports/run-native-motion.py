import os,subprocess,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909')
for name,variant in [('control',0),('512',512),('1024',1024)]:
 env=dict(os.environ)
 if not variant: env.update(BEASTIE_STATIC_MAP_CONTROL='rays',BEASTIE_SHADOW_INDEXED='0',BEASTIE_SHADOW_ATLAS='0')
 else: env['BEASTIE_STATIC_MAP_SIZE']=str(variant)
 with (r/f'native-motion-{name}.log').open('w') as out:
  subprocess.run([str(r/'beastie-native-shadows'),'--fake-ai','--script','/Users/michael/Code/beastie/fixtures/scenarios/gold-reference-motion.jsonl','--feel-dir',str(r/f'native-motion-{name}'),'--feel-script-only'],env=env,cwd='/Users/michael/Code/beastie',stdout=out,stderr=subprocess.STDOUT,check=True,timeout=100)
 print(name,'done',flush=True)
