import os,subprocess,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909')
for name,mode in [('control-before','control'),('combined32','32'),('combined16','16'),('combined16-repeat','16'),('combined32-repeat','32'),('control-after','control')]:
 env=dict(os.environ,BEASTIE_BENCH_OUTPUT=str(r/f'combined-{name}.json'),BEASTIE_BENCH_PNG=str(r/f'combined-{name}.png'))
 if mode=='control': env.update(BEASTIE_STATIC_MAP_CONTROL='rays',BEASTIE_SHADOW_INDEXED='0',BEASTIE_SHADOW_ATLAS='0')
 else: env.update(BEASTIE_STATIC_MAP_SIZE='512',BEASTIE_SHADOW_INDEXED='1',BEASTIE_SHADOW_ATLAS='1',BEASTIE_SHADOW_DEPTH=mode)
 with (r/f'combined-{name}.log').open('w') as out:
  subprocess.run([str(r/'beastie-native-combined-test'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,cwd=r/'native-src',stdout=out,stderr=subprocess.STDOUT,check=True)
 print(name,'done',flush=True)
