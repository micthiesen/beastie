import os,subprocess,pathlib
r=pathlib.Path('/tmp/beastie-energy-20260909')
for name,candidate in [('512',True),('control',False)]:
 env=dict(os.environ)
 if not candidate: env.update(BEASTIE_STATIC_MAP_CONTROL='rays',BEASTIE_SHADOW_INDEXED='0',BEASTIE_SHADOW_ATLAS='0')
 with (r/f'native-world-{name}.log').open('w') as out:
  subprocess.run([str(r/'beastie-native-shadows'),'--fake-ai','--script','/Users/michael/Code/beastie/fixtures/scenarios/renderer-perf-world.jsonl','--render-report',str(r/f'native-world-{name}.json'),'--render-uncapped'],env=env,cwd='/Users/michael/Code/beastie',stdout=out,stderr=subprocess.STDOUT,check=True,timeout=100)
 print(name,'done',flush=True)
