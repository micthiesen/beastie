import os, subprocess, pathlib
base=pathlib.Path('/tmp/beastie-energy-20260909')
for name,atlas in [('control-before',False),('atlas',True),('atlas-repeat',True),('control-after',False)]:
    env=dict(os.environ,BEASTIE_STATIC_MAP_CONTROL='rays',BEASTIE_BENCH_OUTPUT=str(base/f'atlas-{name}.json'),BEASTIE_BENCH_PNG=str(base/f'atlas-{name}.png'))
    env['BEASTIE_SHADOW_INDEXED']='1'
    if atlas: env['BEASTIE_SHADOW_ATLAS']='1'
    else: env.pop('BEASTIE_SHADOW_ATLAS',None)
    with (base/f'atlas-{name}.log').open('w') as out:
        subprocess.run([str(base/'beastie-atlas-test'),'offscreen_renderer_benchmark','--ignored','--nocapture'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True,cwd=base/'atlas-src')
    print(name, 'done',flush=True)
