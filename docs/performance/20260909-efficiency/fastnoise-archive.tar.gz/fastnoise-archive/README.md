# Rejected integer water-hash experiment

This compact archive preserves a measured rejection, not an accepted renderer change. It
contains two source patches, source/artifact hashes, seven raw reports, a visual summary and
full images. It does not contain a copied repository, dependencies or compiled executable.

## Reconstruct

Use a repository containing baseline commit `a19edc90450ed0b6beae6541270730693607ee8c`:

```sh
python3 materialize.py /Users/michael/Code/beastie /tmp/reproduce-fastnoise
```

The destination must not exist. The script archives the Git commit into a plain directory,
checks and applies `base.patch`, verifies every captured source hash, applies `fastnoise.patch`,
and verifies the candidate hashes. It never edits the shared repository or builds anything.
`base.patch` is byte-identical to the experiment archive's captured exact-cache base, before
shadow-map integration. Every unchanged scoped file matches that base; only four source files
change for this experiment. Untouched workspace files come from the recorded Git commit.

`manifest.json` identifies the original measured executable by SHA-256. Source hashes were
recorded after the experiment; the scratch source remained unchanged during all seven runs.
The compiler output identified `/private/tmp/beastie-perf-v2-20260909/fastnoise-src` explicitly.
Reconstruction was tested by applying both patches and comparing every scoped source byte.

## Build and compare

From the reconstructed directory, with other benchmarks stopped and a GPU slot available:

```sh
cargo test -p beastie-game ray_validation
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_NOISE=original BEASTIE_BENCH_OUTPUT=/tmp/noise-control-before.json BEASTIE_BENCH_PNG=/tmp/noise-original.png cargo test -p beastie-game ray_benchmark::offscreen_renderer_benchmark -- --ignored --exact --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_NOISE=avalanche BEASTIE_BENCH_OUTPUT=/tmp/noise-avalanche.json BEASTIE_BENCH_PNG=/tmp/noise-avalanche.png cargo test -p beastie-game ray_benchmark::offscreen_renderer_benchmark -- --ignored --exact --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_NOISE=original BEASTIE_BENCH_OUTPUT=/tmp/noise-control-after.json cargo test -p beastie-game ray_benchmark::offscreen_renderer_benchmark -- --ignored --exact --nocapture
```

Both choices use the same compiled executable with startup shader specialization. Use normal
dev tests, not a release bundle. For the other captured times, repeat original/avalanche with
`BEASTIE_BENCH_WATER_SECONDS=12` and `47`, and distinct output paths. GPU timing requires a GPU,
but no window or display. Read schema 3 batch envelope/frame and completion cadence; the
long overlapping pass latencies are not throughput or frame cadence. If deliberately sharing
a target directory across snapshots, force the intended source to rebuild and confirm its
compiler path before copying/running a test executable.

## Result and visual qualification

Apple M5 Max/Metal, 1920×1080, 210 dispatched frames including 30 warmups:

| Water time | Original envelope/frame, ms | Avalanche envelope/frame, ms |
| --- | ---: | ---: |
| 0 s | 2.610582 before; 2.540447 after | 2.618670 |
| 12 s | 2.562803 | 2.535559 |
| 47 s | 2.564335 | 2.609329 |

No repeatable material gain. All seven batches had 210 valid timestamp pairs and 179 eligible
post-warmup completion intervals. Seven headless shader checks passed; the separate native
traversal test was ignored. Cached/uncached comparisons under each selected hash differed in
zero RGB pixels.

The integer variant visibly relocates water highlights while retaining irregular caustic
loops, broken highlights, broad shafts and colors in the inspected stills. Full-image MAE at
0/12/47 seconds was 2.446/2.464/2.521 on 0..255 channels. This does not prove motion quality or
absence of shimmer. Since performance did not justify adoption, native/motion acceptance was
not pursued. Keep the original sine hash.

`reports/noise-summary.json` collects metrics; `images/noise-character-comparison.png` shows
substrate/surface comparisons at all three times. Full original/candidate PNGs are included.
The shader retains interpolation, caustic distance rules, ripple/warp frequencies, colors and
animation rates. All hash callers pass integer-valued cells. The avalanche finalizer derives
from Austin Appleby's public-domain [MurmurHash3 source](https://github.com/aappleby/smhasher/blob/master/src/MurmurHash3.cpp).
See `EXPERIMENT.md` for the recorded original procedure and domain qualification.
