#!/usr/bin/env python3
"""Reconstruct verified fastnoise sources into a new plain directory; no builds."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('repository', type=Path)
parser.add_argument('destination', type=Path)
args = parser.parse_args()
package = Path(__file__).resolve().parent
manifest = json.loads((package / 'manifest.json').read_text())
assert not args.destination.exists(), 'Destination must not exist; never modify a current checkout'
for path, digest in manifest['artifact_sha256'].items():
    assert hashlib.sha256((package / path).read_bytes()).hexdigest() == digest, path
args.destination.mkdir(parents=True)
source = subprocess.check_output(['git', 'archive', manifest['base_commit']], cwd=args.repository)
with tarfile.open(fileobj=io.BytesIO(source)) as archive:
    archive.extractall(args.destination, filter='data')
for name, hashes in [('base', 'base_files_sha256'), ('fastnoise', 'candidate_files_sha256')]:
    patch = package / 'patches' / (name + '.patch')
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=args.destination, check=True)
    subprocess.run(['git', 'apply', str(patch)], cwd=args.destination, check=True)
    for path, digest in manifest[hashes].items():
        assert hashlib.sha256((args.destination / path).read_bytes()).hexdigest() == digest, path
print('Verified reconstructed source:', args.destination.resolve())
print('No compilation or GPU work was performed. Follow README.md when a GPU slot is available.')
