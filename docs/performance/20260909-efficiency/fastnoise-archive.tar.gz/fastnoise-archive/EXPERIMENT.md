# Bounded integer water-hash experiment

Scratch only. No build or GPU run has been performed yet.

`BEASTIE_BENCH_NOISE=original` is the default and retains the original sine hash.
`BEASTIE_BENCH_NOISE=avalanche` specializes the same binary's WGSL constant to a
32-bit avalanche hash. The environment switch also works for native startup.
`BEASTIE_BENCH_WATER_SECONDS` optionally freezes the offscreen water clock for
matched visual samples; the default clock remains the production snapshot value.

All existing water_hash callers receive integer-valued cells: floor(p) plus integer
neighbors in water_noise, floor(warped) plus integer neighbors in caustic, or
floor(p.xz*65) for substrate grain. Signed integer conversion followed by bitcast
preserves negative cells. The candidate mixes a 2D cell key with two fixed salts,
then converts the upper 24 bits to exactly representable [0,1) values. Coordinates
must fit i32; the current bounded aquarium and ordinary elapsed-time range do.

The avalanche finalizer follows Austin Appleby's fmix32 implementation in
https://github.com/aappleby/smhasher/blob/master/src/MurmurHash3.cpp . Its source
header explicitly places MurmurHash3 in the public domain and disclaims copyright.
Primary raw source inspected 2026-09-09:
https://raw.githubusercontent.com/aappleby/smhasher/master/src/MurmurHash3.cpp .
The 2D key/salts and 24-bit conversion are this experiment's adaptation.

Only random cell values change. Interpolation, caustic distance rules, site motion,
warp/ripple frequencies, color, optical transport and animation rates remain the
same. This is intentionally not pixel-exact; visual character and motion require
acceptance if repeatable gains are material. No quality/sample reductions are added.

After the root grants build and GPU slots:

```sh
cd /tmp/beastie-perf-v2-20260909/fastnoise-src
touch crates/beastie-game/src/main.rs
cargo test -p beastie-game ray_validation --target-dir /Users/michael/Code/beastie/target
cp /Users/michael/Code/beastie/target/debug/deps/beastie_game-0c39c33bfa89ddc9 /tmp/beastie-perf-v2-20260909/beastie-fastnoise-tests
BEASTIE_BENCH_NOISE=original BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/beastie-perf-v2-20260909/noise-control-before.json BEASTIE_BENCH_PNG=/tmp/beastie-perf-v2-20260909/noise-original.png /tmp/beastie-perf-v2-20260909/beastie-fastnoise-tests ray_benchmark::offscreen_renderer_benchmark --ignored --exact --nocapture
BEASTIE_BENCH_NOISE=avalanche BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/beastie-perf-v2-20260909/noise-avalanche.json BEASTIE_BENCH_PNG=/tmp/beastie-perf-v2-20260909/noise-avalanche.png /tmp/beastie-perf-v2-20260909/beastie-fastnoise-tests ray_benchmark::offscreen_renderer_benchmark --ignored --exact --nocapture
```

Repeat the candidate and original control after those runs. Compare schema 3 batch
envelope/frame and post-warmup completion cadence, never overlapping pass latency.
Retain full PNGs for character review; then compare positive clock offsets and
motion if speed gains justify continuing. The existing same-pipeline cache oracle
still compares cached versus uncached lighting under the selected hash; it does
not compare the candidate random pattern to the original pattern.

## Result: rejected

Seven shader translation checks passed; native traversal test remained ignored.
All seven GPU batches had 210 valid timestamp pairs and 179 warmed completion intervals.
At t=0, controls measured 2.610582 and 2.540447 ms/frame; avalanche measured 2.618670.
At t=12, original/avalanche measured 2.562803/2.535559; at t=47, 2.564335/2.609329.
These corrected whole-batch envelope means show no repeatable material improvement.

Three frozen-time still comparisons preserve the irregular caustic character but visibly
change random highlight placement. Full-image MAE was 2.446, 2.464 and 2.521/255;
substrate-region MAE was 5.963, 6.168 and 6.744/255. No claim of motion quality is made.
Because performance does not justify adoption, no native build or motion validation follows.
Keep the original sine hash. Reports, full PNGs and noise-character-comparison.png live
beside this scratch directory; noise-summary.json collects results.
