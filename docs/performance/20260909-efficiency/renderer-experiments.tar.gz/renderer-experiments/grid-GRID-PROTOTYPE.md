# Object-local triangle grid experiment

Prepared scratch only from bounce-src. No builds or GPU runs performed during preparation. This is not an accepted renderer change.

## Scope and layout

`crates/beastie-game/src/ray_grid.rs` builds one dense grid per geometry chunk, shared across instances. Triangles, shading attributes, transforms, primary raster visibility, TLAS and static shadow/bounce caches remain unchanged. Only benchmark GPU instance roots are remapped from BLAS roots to grid headers. The original scene instance roots still drive raster draw ranges correctly.

Binding1 changes from BVH nodes to packed u32 words. Each grid has a64-byte header,8-byte cell records(first reference,count), then4-byte original triangle indices. Exact total size is64*grid_count+8*cell_count+4*reference_count. Builder reports actual cells,empty cells,triangle references,max cell occupancy,coarsened meshes andbytes under `grid` in the benchmark JSON. Device storage-binding limits are checked before upload.

`BEASTIE_GRID_RATIO` controls target cells relative to triangle count, default1; requested trials0.5,1,2. Anisotropic dimensions use the mesh bounds and are capped at64 peraxis (262144 cells/grid). Conservative padded triangle AABBs include the existing intersection routine's barycentric tolerance. If overlap exceeds min(32*triangles,4million) references permesh, dimensions halve until within budget. No triangle is discarded. A one-cell grid is the bounded brute-force fallback.

The WGSL local traversal keeps original `triangle_hit`, near-first TLAS and world-t parameterization. It replaces the local24-entry stack with DDA. An intersection found through an early cell is retained but does not stop traversal unless nearer than the next cell boundary. Parallel axes do not step. Each step advances one axis monotonically; at most nx+ny+nz+3 steps suffice. Boundary padding covers edge/corner ties conservatively.

## Verification prepared

Two CPU tests cover planar/shared-boundary conservative references and overlap-budget coarsening without losing triangles. Existing headless shader translation tests exercise grid WGSL. The offscreen full-frame reference uses the original BVH shader, original nodes and original instance roots with both lighting caches disabled. Raster visibility and snapshot remain identical. Report includes differing RGB pixels and maximum/mean linear channel error.

The inherited explicit GPU traversal oracle and moving-cache oracle still upload BVH data and MUST NOT run against this grid shader until adapted. They are ignored by ordinary tests. The ordinary native executable deliberately retains its original BVH shader because runtime grid upload is not implemented. Only the explicit offscreen benchmark measures the grid prototype.

## Commands, once the shared build/GPU slot is granted

Run from this directory. Touch main.rs before switching shared target source snapshots and verify compile output identifies grid-src.

    touch crates/beastie-game/src/main.rs
    cargo test -p beastie-game ray_grid::tests -- --nocapture
    cargo test -p beastie-game compute_tracer_translates_without_optional_gpu_capabilities -- --nocapture
    BEASTIE_GRID_RATIO=1 BEASTIE_BENCH_OUTPUT=/tmp/beastie-perf-v2-20260909/grid-1.json BEASTIE_BENCH_PNG=/tmp/beastie-perf-v2-20260909/grid-1.png BEASTIE_BENCH_REFERENCE_PNG=/tmp/beastie-perf-v2-20260909/grid-reference.png cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture

Repeat ratios0.5 and2 only after confirming correctness and reasonable allocation. `measure_frames` uses completed isolated submissions with post-completion timestamp resolution, inherited from bounce-src. Compare to the matching bounce-src full baseline using that same harness, not old batched timings. Data construction/upload is outside compute timing; record build time separately if the experiment advances.

## Expected tradeoff, not a performance claim

Removing per-ray BLAS stack state may improve occupancy, and voxel-derived mesh density can suit a grid. Empty-space stepping, repeated triangle references, sparse/disconnected glyphs and large flat triangles can erase that advantage. No mailbox deduplication is attempted, avoiding per-ray memory or atomics. This grid preserves beveled triangles and arbitrary instance transforms; it is not a replacement with occupied cubic cells.

References:
- Amanatides and Woo, A Fast Voxel Traversal Algorithm for Ray Tracing (1987): https://physique.cmaisonneuve.qc.ca/svezina/projet/ray_tracer/download/A_Fast_Voxel_Traversal_Algorythm_For_Ray_Tracing.pdf
- PBRT2 GridAccel and ray/voxel stepping: https://www.pbrt.org/chapters/pbrt-2ed-chap4.pdf
- PBRT3 discussion of grid accelerators and specialized structures: https://www.pbr-book.org/3ed-2018/Primitives_and_Intersection_Acceleration/Further_Reading

For a frozen matching control, set `BEASTIE_GRID_CONTROL=bvh` on the same offscreen benchmark command. This switches the timed dispatch to the captured original BVH shader and original instance/node buffers while preserving the same scene, raster pass, cache design and timestamp harness. The JSON marks `grid_bvh_control`. This is the correct comparator because new live cache layouts may evolve independently of this snapshot. Grid construction still runs for statistics but remains outside timed GPU work.

## Measured result: reject this prototype

CPU grid tests and WGSL translation to SPIR-V/HLSL/MSL passed. Compiler output identified grid-src. The copied binary `../beastie-grid-test` ran the same-binary sequence below on AppleM5Max/Metal at1920x1080,seed42,500904triangles,36mesh grids. Reports and logs are `../grid-bvh-before`, `../grid-05`, `../grid-1`, `../grid-2`, `../grid-bvh-after` with json/log suffixes. `analyze_grid.py` writes `../grid-summary.json` from raw timestamp pairs.

| Variant | GPU envelope/210 frames(ms) | Warm adjacent completion median(ms) | Warm adjacent completion p95(ms) | Traversal bytes |
| --- | ---: | ---: | ---: | ---: |
| BVH before | 2.596550 | 2.415292 | 3.028458 | 13,300,224 |
| Grid0.5 | 4.684524 | 4.360667 | 5.342959 | 6,594,956 |
| Grid1 | 4.880505 | 4.562708 | 5.603375 | 9,373,312 |
| Grid2 | 4.527650 | 4.220333 | 5.179500 | 12,852,648 |
| BVH after | 2.598623 | 2.423979 | 3.057625 | 13,300,224 |

All210timestamp pairs are valid in every run. All209adjacent pass intervals overlap; reported per-pass p50 durations are therefore not frame cost and are not used here. These figures measure batched throughput of the frozen hybrid-rendered scene, not native frame pacing or isolated latency. Warm completion intervals are end[i]-end[i-1] for i30..209. Submission wall/210 is3.275/5.359/5.572/5.213/3.290ms respectively, consistent with the ordering while including host/submission overhead.

Grid0.5 has252458cells,194247empty,1143247references,max637references/cell; Grid1 has456133cells,364414empty,1430486references,max454; Grid2 has790976cells,662768empty,1630634references,max406. Two meshes coarsened for ratios0.5/1; three for ratio2. The smallest grid roughly halves BLAS memory but takes80%longer throughput time. Even the fastest grid is about74%slower than the mean bracketed BVH control. Empty-space steps and duplicate triangle tests are plausible contributors; no traversal counters were collected to separate causes.

Each grid density differs from the BVH reference at exactly10of2073600linear half-float RGB pixels, maximum channel delta0.0007019043,mean absolute channel delta8.7322e-10. Both BVH controls compare exactly. After sRGB8-bit conversion only6pixels differ, each byone code in one or two channels, near two ground/plant contacts (x636..1581,y748..754). The64x amplified cropped difference was inspected; no broad silhouette/coverage error is visible. Traversal-order ties are a plausible explanation, not proven. Thus the prototype retains original geometry but is not bit-exact to original traversal on this fixture. No deeper error investigation is warranted for a substantially slower rejected approach.

The original shader and all scripts/reports remain available for reproducing this result. No grid implementation was integrated into live source.
