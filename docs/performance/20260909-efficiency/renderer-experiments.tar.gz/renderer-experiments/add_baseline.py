from pathlib import Path
import subprocess,tarfile,io,difflib,hashlib,json,tempfile
out=Path(__file__).resolve().parent;root=Path('/Users/michael/Code/beastie');src=out.parent/'baseline-perf-src';m=json.loads((out/'manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def files(p):
 names=['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/beastie-game/Cargo.toml']+[str(f.relative_to(p)) for f in (p/'crates/beastie-game/src').rglob('*') if f.is_file()]
 return {n:(p/n).read_bytes() for n in sorted(set(names)) if (p/n).is_file()}
new=files(src)
with tempfile.TemporaryDirectory(dir=out,prefix='baseline-validation-') as d:
 d=Path(d)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',m['base_commit']],cwd=root))) as t:t.extractall(d,filter='data')
 old=files(d);parts=[];changed=[]
 for p in sorted(set(old)|set(new)):
  if old.get(p)==new.get(p):continue
  changed.append(p);parts.extend(difflib.unified_diff(old.get(p,b'').decode().splitlines(True),new.get(p,b'').decode().splitlines(True),fromfile='a/'+p if p in old else '/dev/null',tofile='b/'+p if p in new else '/dev/null',n=3))
 pp=out/'patches/baseline-perf.patch';pp.write_text(''.join(parts))
 subprocess.run(['git','apply','--check',str(pp)],cwd=d,check=True);subprocess.run(['git','apply',str(pp)],cwd=d,check=True)
 assert files(d)==new
m['variants']['baseline-perf']={'patch_base':'base_commit directly; do not apply base.patch','files_sha256':{p:sha(b) for p,b in new.items()},'changed_files':changed,'patch_sha256':sha(pp.read_bytes()),'patch_bytes':pp.stat().st_size}
m['validation']['baseline-perf']='Patch checked and applied directly to archived Git base in independent temporary copy; all scoped files exactly match retained baseline-perf-src snapshot. No build/GPU operation during packaging.'
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('baseline bytes',pp.stat().st_size,'changed',changed)
