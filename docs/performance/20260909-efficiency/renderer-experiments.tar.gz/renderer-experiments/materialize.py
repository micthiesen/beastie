#!/usr/bin/env python3
"""Recreate one experiment in a new plain directory. Never edits the source repo."""
import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('repository',type=Path);parser.add_argument('destination',type=Path);parser.add_argument('variant',choices=['grid','compressed4','compressed8','splitshadow','baseline-perf']);args=parser.parse_args()
package=Path(__file__).resolve().parent;manifest=json.loads((package/'manifest.json').read_text())
assert not args.destination.exists(),'Destination must not exist; no current checkout will be overwritten'
args.destination.mkdir(parents=True)
data=subprocess.check_output(['git','archive',manifest['base_commit']],cwd=args.repository)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(args.destination,filter='data')
for name in ([args.variant] if args.variant=='baseline-perf' else ['base',args.variant]):
 patch=package/'patches'/(name+'.patch')
 subprocess.run(['git','apply','--check',str(patch)],cwd=args.destination,check=True)
 subprocess.run(['git','apply',str(patch)],cwd=args.destination,check=True)
for name,digest in manifest['variants'][args.variant]['files_sha256'].items():
 assert hashlib.sha256((args.destination/name).read_bytes()).hexdigest()==digest,name
print('Verified experiment source:',args.destination.resolve())
print('Use README.md commands from this directory. No build or GPU operation was run.')
