# Reproducible rejected renderer experiments

Packaged 2026-09-09 from Beastie source and actual Apple M5 Max / Metal measurements.
This package contains patches, hashes, raw reports and comparison images, not cloned source
trees or compiled executables. Production changes are not applied by any packaging step.

## Source reconstruction

`patches/base.patch` reconstructs the captured live renderer/build-file scope on Git commit
`a19edc90450ed0b6beae6541270730693607ee8c`. Each experiment patch applies to that captured base,
not to a moving checkout. `manifest.json` records the SHA-256 of every scoped source file,
patch, report, image and original measured executable. Untouched workspace files come from
that Git commit. All experiment patches were applied in separate temporary copies and all resulting
source bytes were verified. Packaging did not compile or run any GPU work.

For example, using a repository that contains that commit:

```sh
python3 materialize.py /Users/michael/Code/beastie /tmp/reproduce-compressed8 compressed8
```

The destination must not exist. This creates a plain copy, not a Git worktree. Repeat with
`grid`, `compressed4` or `splitshadow` and a different destination. Never apply these patches
to the shared development checkout. Run builds and GPU trials serially with other native
benchmarks stopped. Verify compilation identifies the intended copied source directory.

### Provenance qualification

Source hashes were recorded during packaging, not at measurement time. The BVH4 working
snapshot was accidentally overlaid later during a scratch-copy operation. Its retained
converter and the earlier BVH8 fork reconstruct the BVH4 runtime source by reversing only
BVH8 benchmark labels/metadata and restoring the original BVH4 converter. This is recorded
explicitly in the manifest. Raw measurements are untouched, and hashes identify the original
measured test executables, which are deliberately not included in this source package.

## Build and run

From the materialized experiment directory:

```sh
cargo test -p beastie-game ray_compressed -- --nocapture
```

That filter covers BVH4/BVH8 outward quantization, leaf retention and cross-backend Naga
translation. For the grid instead run:

```sh
cargo test -p beastie-game ray_grid::tests -- --nocapture
cargo test -p beastie-game compute_tracer_translates_without_optional_gpu_capabilities -- --nocapture
```

For split shadows:

```sh
cargo test -p beastie-game split_shadow_shader_translates -- --nocapture
```

All use ordinary debug test builds. No release bundle is needed. The explicit ignored test
below is the only benchmark. It needs a real GPU but no visible window. Create an output
directory and set `BEASTIE_BENCH_OUTPUT` to a distinct JSON path for every run. Every timing
run here used `BEASTIE_BENCH_SUBMISSION=batched` and the Full probe. Preserve the entire JSON.

BVH4/BVH8 control, then candidate:

```sh
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/control-1.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_COMPRESSED=1 BEASTIE_BENCH_OUTPUT=/tmp/candidate-1.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
```

Repeat control and candidate with new output names. `BEASTIE_BENCH_PNG=/tmp/output.png`
saves the rendered image. Compressed variants retain the original binary hierarchy in the
same executable for control comparisons; the recorded compressed payload is the alternate
hierarchy alone, not total simultaneously allocated benchmark memory.

Grid control and density trials use the same executable:

```sh
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_GRID_CONTROL=bvh BEASTIE_GRID_RATIO=0.5 BEASTIE_BENCH_OUTPUT=/tmp/grid-control-before.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_GRID_RATIO=0.5 BEASTIE_BENCH_OUTPUT=/tmp/grid-05.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_GRID_RATIO=1 BEASTIE_BENCH_OUTPUT=/tmp/grid-1.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_GRID_RATIO=2 BEASTIE_BENCH_OUTPUT=/tmp/grid-2.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
```

Finish with another control. The inherited grid traversal/moving-cache GPU oracles still
expect binary nodes and must not be run against the grid shader. Its benchmark instead
compares against the original BVH shader/data. See `grid-GRID-PROTOTYPE.md` for layout details;
its preparation-stage wording is historical, superseded by the raw completed reports here.

Split shadow control uses the ordinary command above. Candidate:

```sh
BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_SPLIT_SHADOW=1 BEASTIE_BENCH_OUTPUT=/tmp/split-1.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
```

Repeat control/candidate. `BEASTIE_BENCH_CACHE_RECORDS=1` and `=0` exercise reduced or disabled
static cache coverage; the independent two-sample result buffer remains unchanged. Candidate
runs assert exact half-float RGB equality with a separately compiled original single-pass
shader with caches disabled. Those extra coverage runs are correctness evidence, not matched
performance comparisons. Native runtime integration of this offscreen prototype was not done.

## Results and limits

Frozen seed-42 real scene, 1920x1080, 30 warmup plus 180 measured dispatches. All figures below
are the GPU envelope divided by all 210 dispatches, including fill/drain and warmup. They
are not overlapping GPU pass medians or native frame pacing. Post-warmup completion
percentiles remain in the raw JSON. Current schema has 179 eligible adjacent intervals;
the historical grid summary includes one interval spanning the warmup boundary.

| Experiment | Matched controls, ms | Candidate, ms | Decision |
| --- | ---: | ---: | --- |
| Object-local grid, densities .5 / 1 / 2 | 2.596550 / 2.598623 | 4.684524 / 4.880505 / 4.527650 | Fastest candidate about 74% slower |
| Sorted conservative BVH4 | 2.537697 / 2.615635 | 3.953284 / 3.946288 | About 53% slower |
| Fixed-octant conservative BVH8 | 2.546078 / 2.603623 | 3.461518 / 3.445634 | About 34% slower |
| Two-pass shadows | 2.619426 / 2.595442 | 2.553358 / 2.503142 | About 3% faster, only 0.079 ms, adds 16.59 MB buffer and another pass |

The extra `compressed-control-1.json` is an isolated diagnostic, not part of the paired
batched BVH4 sequence. Do not mix its latency with envelope/210 values.

BVH4 nodes plus lookup: 4,759,416 bytes; BVH8: 5,181,696 bytes, versus 9,506,880 live binary
node bytes. Grid payloads: 6,594,956 / 9,373,312 / 12,852,648 bytes; its binary arena including
capacity was 13,300,224 bytes. Arena capacity and live payload are distinct denominators.

- Grid reference comparison: ten differing RGB pixels; maximum linear-channel difference
  0.000701904296875. No exact-image claim.
- BVH4 PNG comparison: six of 2,073,600 pixels differ, maximum one 8-bit channel code.
- BVH8 PNG comparison: ten pixels differ, maximum one 8-bit channel code. Conservative bounds
  and unchanged primitives do not preserve all equal-hit traversal ordering.
- Split shadow: exact half-float RGB comparison passed with zero, one and two cached samples.
  Only two-sample runs have paired controls. Worst-case result-buffer write plus read is
  33.18 MB/frame; unchanged/empty/unlit sample work is skipped.

Compressed bounds are checked outward under both fused and separate f32 decode, and packed
leaf references retain all original leaves. BVH4 collapses two binary levels, BVH8 three;
source depth23 bounds their stacks to12 and8 words respectively. BVH8 uses a simple Morton
centroid/octant ordering, not the paper's complete SAH-optimal wide conversion. Negative
results concern these measured implementations; they do not prove every compressed BVH
algorithm is slow on every GPU. No RTX, hardware ray queries or optional subgroup features
are required. Only M5 Max/Metal was measured; Naga translation is not native portability timing.

## Sources

The independent compressed prototypes use ideas from [Ylitie, Karras and Laine, HPG2017](https://research.nvidia.com/publication/2017-07_efficient-incoherent-ray-traversal-gpus-through-compressed-wide-bvhs)
and [TinyBVH](https://github.com/jbikker/tinybvh). No published benchmark speedup is attributed
to Beastie. Original game geometry, materials, transforms and lighting remain the comparison
reference.

## Matched optimized baseline

`patches/baseline-perf.patch` applies DIRECTLY to the recorded Git commit, without
`base.patch`. It reproduces the retained `baseline-perf-src` snapshot used by the native
optimized-development comparison. Only `Cargo.toml`, `args.rs`, `ray_stats.rs` and
`raytrace.rs` differ from the Git base: the development profile and diagnostic/timestamp
instrumentation change; mesh generation, scene extraction and WGSL renderer remain the
base versions. The patch includes diagnostic probe argument declarations, but no shader
optimization. Use Full/default for matched native runs. The source/file hash validation
passed in a separate copy.

```sh
python3 materialize.py /Users/michael/Code/beastie /tmp/reproduce-baseline-perf baseline-perf
```

From that destination, build with `cargo build -p beastie-game --profile dev-perf`.
The four `baseline-perf-native-{ui,world}.json` / `bounce-perf-native-{ui,world}.json` reports
are included unmodified. The recorded native commands ran the copied binary from the repository directory with no
extra environment variables configured:

```sh
/tmp/beastie-perf-v2-20260909/beastie-baseline-perf --fake-ai --script /Users/michael/Code/beastie/fixtures/scenarios/renderer-perf-ui.jsonl --render-report /tmp/beastie-perf-v2-20260909/baseline-perf-native-ui.json --render-uncapped
/tmp/beastie-perf-v2-20260909/beastie-baseline-perf --fake-ai --script /Users/michael/Code/beastie/fixtures/scenarios/renderer-perf-world.jsonl --render-report /tmp/beastie-perf-v2-20260909/baseline-perf-native-world.json --render-uncapped
```

For reproduction, copy the freshly built `target/dev-perf/beastie-game` to a distinct path,
substitute that binary and the materialized repository path above, and use new report names.
Keep the viewport at 1920x1080 and preserve the scenario and presentation flags. Later native
repeats used a `time -l` wrapper to record maximum resident memory; the initial four reports
here did not require extra environment settings. Native results must not be compared with
offscreen envelope means as though they measured the same quantity.

## Split shadows combined with shadow maps

No combination is proposed for promotion. The split experiment removed shadow traversal from
the shading kernel yet saved only 0.079 ms with the expensive ray-based shadow path. Shadow maps
replace that path with cheaper texture reads, while the split's duplicate receiver reconstruction,
result-buffer traffic and extra dispatch remain. There is no current evidence for a material
additional gain. Reconsider only if the final mapped-shadow ablation or register/occupancy
measurement exposes a new bottleneck; the savings are not additive.
