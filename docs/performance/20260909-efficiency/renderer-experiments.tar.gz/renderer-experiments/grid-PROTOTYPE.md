# Exact stationary shadow visibility prototype

Scratch only. Based on HEAD with current live args/main/ray_stats/ray_validation/raytrace/renderer overlay.

RayStatic tags all environment::setup meshes. All other instances are dynamic. Static revision tracks sorted entity identity, mesh handle, world transform bits and material properties, plus static mesh modification events. It does not depend on primary TLAS ordering or geometry arena compaction. Static/dynamic shadow roots retain primary instance IDs.

Two coverage records per pixel store static visibility/validity bits, stable entity index, and triangle index (24 bytes/pixel; 47.46 MiB at1920x1080). Receiver keys prevent coincident-surface changes caused by primary TLAS reordering from reusing incompatible normals. Generation replacement changes the scene signature and invalidates. Geometry compaction changes triangle keys and lazily refills. Camera matrix/viewport/static revision changes clear validity. Oversized buffers fall back to normal shadows if above device binding size limits.

Only eligible stationary primary receivers and samples0/1 cache. Other receivers and coverage samples use original shadow traversal. Static occlusion skips dynamic traversal; otherwise dynamic root remains current every frame. Six/twelve refinement uses combined visibility. Probe no-shadows still bypasses shadow work. No final lighting/radiance history is reused.

Validation completed:
- stationary_shadow_revision_tracks_only_eligible_scene_changes passed.
- All five headless ray_validation checks passed, including all probe translations.
- Explicit native production GPU traversal oracle passed2145rays581hits on Apple M5Max Metal. It validates traversal and surface attributes, not the newly added lighting cache path.
- Normal cargo build succeeded; existing compact unwind linker warning remains.
- Binary copied to ../beastie-static.

Still required: full-frame cache path pixel comparisons and warm/cold GPU benchmark, moving occluders and camera/UI transitions. No performance claim yet.

## Measured results

Surface-free full production scene, same pipeline and snapshot with caching disabled for the reference dispatch:
- Full p50 7.708042 ms, repeat 7.712458 ms.
- Cold first dispatch 19.645042 ms, repeat 19.997458 ms.
- Both runs: 0 differing RGB pixels out of 2,073,600 at half-float linear precision; maximum and mean difference zero.
- No-shadows p50 5.616416 ms.
- Cache allocated 49,766,400 bytes, 5 explicitly static instances.
- 30 warmup dispatches then179valid timestamp samples outof180requested. Remaining sample discarded by inherited positive/finite timestamp filter.

Native capture-free renderer-perf-world succeeded at1920x1080: GPU p50 7.310 ms,p95 7.602417,p99 7.631083,max7.849625. Wall-frame p99 8.240458 ms. Report ../static-native-world.json. Native8-state gold-reference captured under ../static-gold including gameplay,settings,title andcontinued. Gameplay inspected with expected geometry and contact shadows. Moving-frame before/after pixel comparisons remain unverified; static same-scene reference proof does not cover every invalidation boundary.
