from pathlib import Path
import subprocess,tarfile,io,difflib,hashlib,json,shutil,tempfile
live=Path('/Users/michael/Code/beastie');scratch=Path('/tmp/beastie-perf-v2-20260909');out=scratch/'experiment-archive'
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip()
archive=subprocess.check_output(['git','archive',head],cwd=live)
scope=['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/beastie-game/Cargo.toml']
def files(root):
 paths=scope+[str(p.relative_to(root)) for p in (root/'crates/beastie-game/src').rglob('*') if p.is_file()]
 return {p:(root/p).read_bytes() for p in sorted(set(paths)) if (root/p).is_file()}
def patch(old,new):
 result=[]
 for p in sorted(set(old)|set(new)):
  if old.get(p)==new.get(p):continue
  result.extend(difflib.unified_diff(old.get(p,b'').decode().splitlines(True),new.get(p,b'').decode().splitlines(True),fromfile='a/'+p if p in old else '/dev/null',tofile='b/'+p if p in new else '/dev/null',n=3))
 return ''.join(result).encode()
base=files(live)
variants={n:files(scratch/d) for n,d in [('grid','grid-src'),('compressed4','compressed-src'),('compressed8','compressed8-src'),('splitshadow','splitshadow-src')]}
# The original BVH4 snapshot was later accidentally overlaid with live source.
# Reconstruct its measured harness from the BVH8 fork, which copied BVH4 before
# that overlay. Only the shader/CPU converter and these metadata labels differed.
reconstructed=dict(variants['compressed8'])
reconstructed['crates/beastie-game/src/ray_compressed.rs']=variants['compressed4']['crates/beastie-game/src/ray_compressed.rs']
p='crates/beastie-game/src/ray_benchmark.rs'
s=reconstructed[p].decode().replace('compressed BVH8','compressed BVH4')
s=s.replace(' "compressed_width":8,"compressed_order":"fixed Morton octant XOR",','')
s=s.replace(' "compressed_width": 8, "compressed_order": "fixed Morton octant XOR",','')
# Match the compact serde_json macro formatting actually present.
import re
s=re.sub(r'\s*"compressed_width"\s*:\s*8\s*,\s*"compressed_order"\s*:\s*"fixed Morton octant XOR"\s*,','',s)
reconstructed[p]=s.encode();variants['compressed4']=reconstructed
(out/'patches').mkdir(exist_ok=True);(out/'reports').mkdir(exist_ok=True);(out/'images').mkdir(exist_ok=True)
manifest={'base_commit':head,'base_scope':'Root build manifests plus crates/beastie-game/Cargo.toml and all files in its src directory; unchanged workspace files come from the Git commit.','base_files_sha256':{p:sha(b) for p,b in base.items()},'variants':{},'validation':{}}
with tempfile.TemporaryDirectory(prefix='validate-',dir=out) as tmp:
 tmp=Path(tmp);scaffold=tmp/'head';scaffold.mkdir()
 with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(scaffold,filter='data')
 old=files(scaffold)
 (out/'patches/base.patch').write_bytes(patch(old,base))
 subprocess.run(['git','apply','--check',str(out/'patches/base.patch')],cwd=scaffold,check=True)
 subprocess.run(['git','apply',str(out/'patches/base.patch')],cwd=scaffold,check=True)
 assert files(scaffold)==base
 for name,new in variants.items():
  target=tmp/name;shutil.copytree(scaffold,target)
  pp=out/'patches'/f'{name}.patch';pp.write_bytes(patch(base,new))
  subprocess.run(['git','apply','--check',str(pp)],cwd=target,check=True)
  subprocess.run(['git','apply',str(pp)],cwd=target,check=True)
  actual=files(target);assert actual==new,(name,[p for p in set(actual)|set(new) if actual.get(p)!=new.get(p)])
  manifest['variants'][name]={'files_sha256':{p:sha(b) for p,b in new.items()},'changed_files':[p for p in sorted(set(base)|set(new)) if base.get(p)!=new.get(p)],'patch_sha256':sha(pp.read_bytes()),'patch_bytes':pp.stat().st_size}
  manifest['validation'][name]='git apply --check and actual apply succeeded in independent temporary copy; every scoped file byte matches recorded variant manifest. No compilation or GPU run performed during packaging.'
report_names=['grid-summary','grid-bvh-before','grid-05','grid-1','grid-2','grid-bvh-after','compressed-control-1','compressed-control-batched-1','compressed-batched-1','compressed-control-batched-2','compressed-batched-2','compressed8-control-1','compressed8-candidate-1','compressed8-control-2','compressed8-candidate-2','splitshadow-control-1','splitshadow-candidate-1','splitshadow-control-2','splitshadow-candidate-2','splitshadow-one-cache','splitshadow-no-cache']
for n in report_names:shutil.copy2(scratch/(n+'.json'),out/'reports'/(n+'.json'))
for n in ['grid-bvh-before','grid-2','compressed-control','compressed','compressed8-control','compressed8']:
 shutil.copy2(scratch/(n+'.png'),out/'images'/(n+'.png'))
for n in ['GRID-PROTOTYPE.md','PROTOTYPE.md']:
 if (scratch/'grid-src'/n).exists():shutil.copy2(scratch/'grid-src'/n,out/('grid-'+n))
manifest['provenance_notes']={'compressed4':'BVH4 converter retained verbatim; runtime source reconstructed from its BVH8 fork (created before later accidental BVH4 scratch overlay), reversing only BVH8 benchmark labels/metadata and restoring original BVH4 converter. Source hashes were captured at packaging, not measurement time. Original measured executable hash retained below.','others':'Hashes captured at packaging from retained scratch snapshots, not recorded at measurement time. JSON reports copied without transformation.'}
manifest['measured_binaries_sha256']={n:sha((scratch/n).read_bytes()) for n in ['beastie-grid-test','beastie-compressed-tests','beastie-compressed8-tests','beastie-splitshadow-tests']}
manifest['artifact_sha256']={str(p.relative_to(out)):sha(p.read_bytes()) for p in out.rglob('*') if p.is_file() and p.name not in ['manifest.json','package.py']}
assert files(live)==base,'Live source changed during packaging; rerun to capture coherent base'
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'base':head,'patches':{k:v['patch_bytes'] for k,v in manifest['variants'].items()},'raw_reports':len(report_names),'total_bytes':sum(p.stat().st_size for p in out.rglob('*') if p.is_file())},indent=2))
