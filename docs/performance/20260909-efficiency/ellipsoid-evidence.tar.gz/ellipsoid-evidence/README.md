# Conservative ellipsoid rejection experiment, 2026-09-09

Rejected: no repeatable GPU gain. Original triangles and traversal order are retained for survivors. This is an independent analytic bound fit, not an approximate replacement surface.

The frozen source was copied from the live renderer immediately before this experiment. It includes shadow-map bindings, but every measured run sets `BEASTIE_SHADOW_MAP_CONTROL=trace`, disabling all shadow depth passes. No later live edits were overlaid. Compiler output identified `/private/tmp/beastie-perf-v2-20260909/ellipsoid-src/crates/beastie-game`. The copied test executable is `/tmp/beastie-perf-v2-20260909/beastie-ellipsoid-tests`; its hash is recorded in manifest.json.

## Representation and correctness

Thirteen rounded head/body instances cover 180,972 instanced triangles. Two vec4 records per scene instance add 2,496 bytes. Other parts have disabled records. Each eligible local-space bound uses actual vertex bounds for center and axis scaling, then the greatest normalized vertex radius. Radius padding includes the negative barycentric tolerance and f32 fitting rounding. A segment-to-sphere closest-point calculation avoids the cancellation-prone quadratic discriminant. The shader inflates the radius by a magnitude-scaled floating-point allowance; tiny directions, extreme magnitudes, and uncertain NaNs retain ordinary traversal. Original BLAS traversal, excluded primitive queries, shadow categories and caches are unchanged.

Two targeted tests pass: full Naga cross-backend translation and actual-vertex/tolerated-barycentric enclosure. All four frozen-scene runs independently compare warmed candidate output against the original shader with caches disabled: zero different half-float RGB pixels out of 2,073,600. No native visual suite was run for this rejected scratch candidate. These tests do not establish a universal floating-point proof for arbitrary future scene magnitudes.

## Timing

Read corrected-summary.json. The copied map harness submits batches of ten frames. Its original global envelope includes CPU gaps and its adjacent-completion distribution includes batch boundaries. Those two original summary fields are unsuitable as GPU cost. Corrected results sum 21 within-batch GPU envelopes and divide by 210 dispatched frames; warmed distributions contain 162 intervals with both endpoints after 30 warmup frames, excluding all batch boundaries. Raw timestamp pairs remain in the four untouched JSON reports.

| Run | GPU batch envelopes / 210, ms | Warm within-batch p50, ms |
| --- | ---: | ---: |
| Control 1 | 2.602025 | 2.418167 |
| Ellipsoid 1 | 2.625408 | 2.433625 |
| Control 2 | 2.644642 | 2.423083 |
| Ellipsoid 2 | 2.639381 | 2.431125 |

No explicit rejection counter was added, so the measurements establish the net cost of this bound, not how many individual BLAS entries it rejected. A different tightly fitted exact occluder representation would require separate evidence; there is no measured reason to pursue one for these rounded parts now.

## Reproduction

Run materialize.py with a repository containing commit a19edc90450ed0b6beae6541270730693607ee8c and a nonexistent destination. It applies base.patch followed by ellipsoid.patch and verifies source hashes. No full repository or executable is included. The patches include the coherent map harness snapshot needed for the measured binary; maps must stay disabled for these comparisons.

```
python3 materialize.py /Users/michael/Code/beastie /tmp/reproduce-ellipsoid
cd /tmp/reproduce-ellipsoid
cargo test -p beastie-game ray_ellipsoid -- --nocapture
```

Copy the test executable path printed by Cargo, then run these serially, using unique output paths. Run control, candidate, control, candidate. The candidate flag must be absent for controls, since presence enables it regardless of value.

```
BEASTIE_SHADOW_MAP_CONTROL=trace BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/control.json /tmp/copied-test-binary offscreen_renderer_benchmark --ignored --nocapture
BEASTIE_SHADOW_MAP_CONTROL=trace BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_ELLIPSOID=1 BEASTIE_BENCH_OUTPUT=/tmp/candidate.json /tmp/copied-test-binary offscreen_renderer_benchmark --ignored --nocapture
```

The exact image assertion runs automatically after timing. GPU setup, CPU geometry preparation and original-reference compilation are outside measured dispatches. No optional ray-tracing hardware feature is used.
