#!/usr/bin/env python3
from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,io
repository=Path(sys.argv[1]);destination=Path(sys.argv[2]);package=Path(__file__).resolve().parent
assert not destination.exists()
manifest=json.loads((package/'manifest.json').read_text());destination.mkdir(parents=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',manifest['base_commit']],cwd=repository))) as archive:archive.extractall(destination,filter='data')
for name in manifest['sequence']:
 subprocess.run(['git','apply','--check',str(package/name)],cwd=destination,check=True)
 subprocess.run(['git','apply',str(package/name)],cwd=destination,check=True)
for name,digest in manifest['files_sha256'].items():assert hashlib.sha256((destination/name).read_bytes()).hexdigest()==digest,name
print('Source hashes verified:',destination)
