# Dynamic directional shadow maps experiment

Scratch copied from current live source. Prepared only; no compilation or GPU run yet. Never call its visibility approximation exact.

The existing static visibility masks and bounce cache remain. Twelve Depth32Float layers replace only dynamic-caster shadow traversal. Each uses the original SHADOW_LIGHTS direction, parsed from WGSL as the single source. CPU fits a tight orthographic XY/depth projection to transformed BLAS bounds of all dynamic lit world casters. The original packed triangles/instances rasterize into each layer with no culling, filtering or extra depth bias. Receiver origins keep the exact existing geometric/smooth-normal offsets. Depth comparison retains the original0.0001minimum ray distance. Outside fitted XY bounds is unshadowed; if a stored blocker lies beyond35units, original dynamic traversal resolves the finite-distance ambiguity.

Dynamic receivers trace static occlusion, then sample dynamic maps. Eligible stationary receivers reuse static visibility bits and sample only when static geometry does not already block that direction. Six-to-twelve refinement still uses combined visibility. The maps rasterize every benchmark frame, representing dynamic movement costs even though the benchmark scene itself is frozen. A runtime integration would recompute light fits/draws when casters move; static cache invalidation remains independent.

Memory is12*resolution²*4bytes of depth textures, plus1744bytes of projection uniforms:
-512:12MiB depth
-1024:48MiB depth
-2048:192MiB depth

Frame timestamps begin before the first shadow depth pass and finish after primary raster+compute. Thus all twelve depth passes count in the GPU envelope. The schema3 harness retains raw timestamp validation,isolated latency andbatched throughput/cadence distinctions. The same-binary `trace` control disables depth draws and restores original dynamic/full shadow traversal. After timing, the same scene is rendered with maps and both caches disabled to quantify complete linear half-float RGB differences. Optional PNG evidence supports visual inspection.

The native executable retains its compatible original shader; only offscreen benchmark upload supports these extra resources. Inherited ignored GPU/motion oracles do not bind shadow-map resources and must not be run until adapted. The projection test checks every dynamic triangle vertex lies inside every fitted clip volume.

Commands after coordinated build/GPU slot:

    touch crates/beastie-game/src/main.rs
    cargo test -p beastie-game light_table_and_fit_are_finite_and_conservative -- --nocapture
    cargo test -p beastie-game compute_tracer_translates_without_optional_gpu_capabilities -- --nocapture
    BEASTIE_SHADOW_MAP_CONTROL=trace BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/beastie-perf-v2-20260909/shadowmap-trace-before.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
    BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/beastie-perf-v2-20260909/shadowmap-1024.json BEASTIE_BENCH_PNG=/tmp/beastie-perf-v2-20260909/shadowmap-1024.png BEASTIE_BENCH_REFERENCE_PNG=/tmp/beastie-perf-v2-20260909/shadowmap-reference.png cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture

Repeat512/2048andtracecontrol only if correctness and cost justify continuing. Initial sampling is one nearest texel for each original direction; no PCF/PCSS or temporal filtering is added. Quantify depth precision, thin-feature aliasing, contact shadows and any moving fit shimmer before considering a product change. Twelvepasses may simply cost more than the remaining dynamic BVH rays, and should be rejected if measured so.

## Measured scratch result, September 9

This remains a promising prototype, not a production acceptance. A single
210-frame command buffer and 210 buffers submitted together both failed the
512-map readback with BufferAsyncError. The matched control and all map sizes
completed with 21 bounded batches of 10 frames, each followed by completion and
query resolution. The whole submission envelope contains CPU gaps and is not a
GPU frame-cost measure. `../shadowmap-summary.json` records every chunk.

| Mode | Sum of chunk GPU envelopes / 210 | Warm intra-batch completion median | Different RGB pixels |
| --- | ---: | ---: | ---: |
| Trace before | 2.641 ms | 2.442 ms | 0 |
| Maps 512 | 2.034 ms | 1.850 ms | 2,878 |
| Maps 1024 | 2.066 ms | 1.878 ms | 1,629 |
| Maps 2048 | 2.199 ms | 2.021 ms | 840 |
| Trace after | 2.623 ms | 2.429 ms | 0 |

All 210 timestamp pairs per run were valid. Warm cadence excludes the first
30 frames and every batch-boundary interval, leaving 162 intervals. Separately,
completion-isolated medians were 4.765 ms for trace and 4.261 ms for maps512.
Twelve map passes are included before raster primary visibility and compute.
Depth texture costs are 12/48/192 MiB, plus 1,744 uniform bytes. The maximum
linear RGB error remains about 0.303 even at 2048; at 512 a worst eyebrow-edge
pixel differs by 77 sRGB codes. Small pixel counts do not establish visual
acceptability. Moving penumbra and self-shadow stability remain required.

The native adapter now defaults to 1024, retains the same scene and shaders, and
supports `BEASTIE_SHADOW_MAP_SIZE=512|1024|2048` and
`BEASTIE_SHADOW_MAP_CONTROL=trace`. It reports `dynamic_shadow_maps` separately
from raster visibility and compute, includes map bytes in framebuffer accounting,
and reports CPU `shadow_projection_upload`. Adapter and extended moving oracle
are prepared but not yet compiled or run. `BEASTIE_MAP_ORACLE_CAPTURE_DIR` selects
paired maps/trace PNGs for the 15 existing scene transitions;
`BEASTIE_CACHE_ORACLE_OUTPUT` selects the error report. A trace control still
asserts exact cache equivalence; map errors are quantified rather than asserted
zero. Native validation and motion review determine whether to pursue this.

## Native adapter and moving validation completed

Both the test executable and native executable compiled under the live-matching
`dev-perf` profile. Compiler output names this scratch source directory. Copied
executables are `../beastie-shadowmap-native-perf` (all receivers) and
`../beastie-shadowmap-receivers-native` (adds the startup static-only switch).
Projection containment and WGSL translation tests passed. The 15-frame oracle
completed for maps1024, maps2048, and original-ray control; control was exactly
equal on all frames. Maps1024 differed on 988–3,361 pixels across ordinary scene
transitions; maps2048 on 475–1,843. Deliberate static edits also completed, with
reported errors rather than hidden exactness assertions. See
`../shadowmap-motion1024.json`, `../shadowmap-motion2048.json`, and paired PNG
folders with those names. Native gold-reference capture completed at1024 in
`../shadowmap-native-motion1024/gold-reference/`; `session.mp4`, marker filmstrips,
and native capture images preserve evidence. Broad appearance and motion remain
recognizable and stable in reviewed filmstrips, but sparse eyebrow/eye contact
shadow aliasing is a real fidelity tradeoff, not an exact optimization.

Native comparison uses the accepted `../beastie-current-perf` control:

| Native workload | Wall p50 / p95 / p99 ms | Compute p50 | Maps p50 |
| --- | --- | ---: | ---: |
| Control world | 8.326 / 8.663 / 8.831 | 2.508 | none |
| Maps1024 world | 8.331 / 8.574 / 8.688 | 1.629 | 0.804 |
| Maps2048 world | 8.322 / 8.574 / 8.664 | 1.661 | 0.920 |
| Control UI | 8.330 / 8.631 / 8.771 | 2.307 | none |
| Maps1024 UI repeat | 8.325 / 8.586 / 8.696 | see raw report | see raw report |

Pass percentiles must not be added: passes overlap and sample independently.
The native wall result is limited by roughly120Hz presentation; it does not
establish higher displayed frame rate. GPU-only bounded offscreen throughput is
the evidence for rendering headroom. Projection/upload CPU p50/p95 was
0.0446/0.0543ms for maps1024 world. Reported framebuffer bytes rise from
151,372,800 control to201,706,192 at1024 and352,701,136 at2048. These are nominal
framebuffer allocations, not total GPU memory. `../shadowmap-native-summary.json`
contains selected native measurements. One initial1024 UI run may briefly have
overlapped the next process startup; its serial repeat is the accepted UI result.

### Static receivers only: measured and rejected

`BEASTIE_SHADOW_MAP_RECEIVERS=static` sets map mode2. Static receiver queries use
maps; dynamic receivers retain original combined-BVH shadow tracing. All15
moving frames completed. Cold differences fell to828 pixels/max0.133 linearRGB
and direct facial shadow precision is retained. However, the same copied test
binary produced these GPU-only results:

| Mode | Sum10-frame GPU envelopes /210 | Warm intra-batch median |
| --- | ---: | ---: |
| Original trace | 2.677ms | 2.448ms |
| Maps1024 all receivers | 2.094ms | 1.894ms |
| Maps1024 static receivers only | 2.907ms | 2.724ms |

All210 timestamp pairs are valid in each run. Static-only native world compute
p50 was2.329ms with0.809ms map pass, and wall p50/p95/p99 was
8.325/8.613/8.754ms. Thus static-only does not preserve the throughput advantage;
it is not recommended. See `../shadowmap-static-summary.json` and
`../shadowmap-static-motion1024.json`.

The all-receiver1024 candidate remains an explicit quality/performance tradeoff:
about22% lower GPU envelope/frame in the final matched test,48MiB extra depth
storage, and sparse sampled-shadow errors. The2048 variant spends another144MiB
for fewer errors but does not eliminate high-contrast contact discrepancies.
Do not integrate solely from these timing or differing-pixel counts. Production
selection belongs to the native visual acceptance decision; this scratch work
has not changed the live renderer.

### Consecutive native crops

`../shadowmap-temporal-review/face-consecutive-1x.png` and `4x.png` show
frames66–77; `plant_contact-consecutive-1x.png` and `4x.png` showframes87–98.
Trace rows precede map rows. All504 recorded simulation/presentation/view states
match, and a ±3-frame image-correlation check prefers zero offset. The captured
native video is1280x720 H264/yuv420p; its independent compression affects pixel
errors. At native crop size the reviewed sequences show no obvious distracting
facial flicker. Enlarged crops expose changing small eyebrow/eye boundary tones,
but the video cannot separate all compression differences from shader aliasing.
The direct offscreen framebuffer comparisons establish the actual sparse errors.
The short quiet-motion sample is insufficient to promise imperceptibility at
all resolutions, camera distances, and lighting configurations.

Reproduce the prepared latest source after extracting the source archive:

```sh
cargo test -p beastie-game --profile dev-perf --no-run
cargo build -p beastie-game --profile dev-perf
BEASTIE_SHADOW_MAP_SIZE=1024 target/dev-perf/beastie-game --fake-ai --script fixtures/scenarios/renderer-perf-world.jsonl --render-report /tmp/maps-world.json --render-uncapped
BEASTIE_SHADOW_MAP_CONTROL=trace target/dev-perf/beastie-game --fake-ai --script fixtures/scenarios/renderer-perf-world.jsonl --render-report /tmp/trace-world.json --render-uncapped
```

The `moving_shadow_cache_matches_uncached_frames` ignored test accepts
`BEASTIE_CACHE_ORACLE_OUTPUT` and `BEASTIE_MAP_ORACLE_CAPTURE_DIR`; select
`BEASTIE_SHADOW_MAP_SIZE=1024` or2048, or `BEASTIE_SHADOW_MAP_CONTROL=trace`.
The `offscreen_renderer_benchmark` ignored test accepts `BEASTIE_BENCH_OUTPUT`
and `BEASTIE_BENCH_SUBMISSION=batched`; analyze raw timestamps with
`analyze_shadow_maps.py`. The rejected receiver variant remains selectable with
`BEASTIE_SHADOW_MAP_RECEIVERS=static` in this prototype only.

Integration touchpoints are ray_shadow_maps.rs (projection/caster helpers),
raytrace.rs (depth pipeline, allocations, uploads, passes, compute bindings),
raytrace.wgsl (map visibility), main.rs (module), and test-only ray_benchmark.rs
and ray_shadow_oracle.rs. These are a frozen scratch snapshot. Do not overwrite
new live renderer changes wholesale; port the focused map additions after
reviewing the current resource layouts and timing code.
