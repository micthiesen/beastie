# Frozen dynamic shadow-map experiment

This package reconstructs the measured scratch prototype, including its original-trace control and rejected static-receiver-only switch. It does not overwrite or represent the later production integration. The parent review accepted the all-receiver 1024 variant after native still and sampled motion inspection; sparse shadow aliasing remains an explicit fidelity tradeoff. The chronological `SHADOWMAP-PROTOTYPE.md` preserves earlier preparation and acceptance-pending notes as historical evidence.

## Reconstruct

Requires a Beastie Git repository containing commit `a19edc90450ed0b6beae6541270730693607ee8c`, Python 3.12+, and Git. Choose a destination that does not exist:

```sh
python3 materialize.py /path/to/beastie /tmp/beastie-shadowmap-reconstructed
cd /tmp/beastie-shadowmap-reconstructed
```

The script verifies package hashes, exports that commit into a plain directory, applies the captured exact-cache `base.patch`, checks its scoped source hashes, applies `shadowmap.patch`, and verifies every recorded candidate source hash. The base patch is identical to the shared experiment archive. Candidate bytes came from the frozen source tar whose SHA-256 is in `manifest.json`; the full repository/assets tar and compiled executables are intentionally omitted. The patch includes all nine differing files, including the prototype's reference shader and native tooling change.

Do not apply the candidate patch directly to a current checkout. Integration has evolved since this snapshot. No build or GPU execution is performed by reconstruction.

## Reproduce tests and controls

Use the ordinary dev test profile for these GPU-only experiments. Run each GPU command serially with no other GPU benchmark or game active.

```sh
cargo test -p beastie-game light_table_and_fit_are_finite_and_conservative -- --nocapture
cargo test -p beastie-game compute_tracer_translates_without_optional_gpu_capabilities -- --nocapture
BEASTIE_SHADOW_MAP_CONTROL=trace BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/maps-control.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/maps-all.json BEASTIE_BENCH_PNG=/tmp/maps-all.png cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_SHADOW_MAP_RECEIVERS=static BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_BENCH_SUBMISSION=batched BEASTIE_BENCH_OUTPUT=/tmp/maps-static.json cargo test -p beastie-game offscreen_renderer_benchmark -- --ignored --nocapture
BEASTIE_SHADOW_MAP_SIZE=1024 BEASTIE_CACHE_ORACLE_OUTPUT=/tmp/maps-motion.json BEASTIE_MAP_ORACLE_CAPTURE_DIR=/tmp/maps-motion-images cargo test -p beastie-game moving_shadow_cache_matches_uncached_frames -- --ignored --nocapture
```

Unset `BEASTIE_SHADOW_MAP_CONTROL` for maps and `BEASTIE_SHADOW_MAP_RECEIVERS` for all receivers. Sizes 512, 1024, and 2048 were measured. `BEASTIE_BENCH_REFERENCE_PNG` optionally writes the benchmark's reference image. Repeat the control after candidates to assess drift. Environment settings must not leak from another experiment.

For native CPU/frame pacing comparisons, the measured profile was `dev-perf`:

```sh
cargo build -p beastie-game --profile dev-perf
BEASTIE_SHADOW_MAP_SIZE=1024 target/dev-perf/beastie-game --fake-ai --script fixtures/scenarios/renderer-perf-world.jsonl --render-report /tmp/maps-world.json --render-uncapped
BEASTIE_SHADOW_MAP_CONTROL=trace target/dev-perf/beastie-game --fake-ai --script fixtures/scenarios/renderer-perf-world.jsonl --render-report /tmp/trace-world.json --render-uncapped
```

## Timing interpretation and findings

Metal queries are resolved only after their producing submission completes. The final batched comparison uses 21 bounded batches of 10 frames. Sum of batch GPU envelopes divided by 210 excludes CPU gaps but includes each batch's fill/drain. Warm adjacent completion intervals omit the first 30 frames and inter-batch boundaries, leaving 162 intervals. All 210 timestamp pairs were valid in these matched runs. A whole-run envelope includes CPU gaps and is not GPU-only frame cost. Per-frame cross-pass latency can overlap across frames; it is not throughput. Do not add independently sampled pass percentiles.

The final matched trace/all-receiver1024/static-only1024 costs were 2.677/2.094/2.907 ms per frame, respectively, with warm intra-batch medians 2.448/1.894/2.724 ms. Static-only improved facial shadow fidelity but lost the speed advantage and was rejected. The selected map allocation adds 48 MiB of depth storage plus 1744 uniform bytes. The 2048 variant adds 192 MiB of depth and reduces differing pixels without eliminating high-contrast errors.

Native world compute p50 fell from 2.508 to 1.629 ms while the separate map pass had p50 0.804 ms; native wall pacing remained near 8.33 ms. These pass percentiles cannot establish an additive total or higher displayed frame rate. Raw native reports, including the clean UI repeat, are retained. The earlier first UI run may overlap a subsequent process startup and is not the accepted repeat.

## Visual evidence and limits

Reports preserve direct framebuffer comparisons, including linear-color errors and temporal oracle results. Images include full still comparisons, worst moving pairs, and consecutive native face/contact crops. All-receiver1024 cold differences were sparse but real; reduced pixel count alone is not acceptance evidence. The review found no distracting facial flicker in the inspected native-size sequence and accepted the character of the shadows. Enlarged crops reveal small changing eyebrow/eye tones. H264/yuv420p video compression limits interpretation of tiny video differences, and short sampled sequences do not prove imperceptibility at every camera distance or resolution.

`reports/` contains raw and derived measurement JSON. `images/` retains stills and temporal crops rather than duplicated full videos. Analysis scripts preserve their original scratch paths and may need path adjustment when used elsewhere. The original prototype notes contain additional results, operational failures, and exact controls. Acceptance of the later integrated renderer requires its own validation.
