import json,subprocess
from pathlib import Path
from PIL import Image,ImageChops,ImageDraw,ImageStat
root=Path('/tmp/beastie-perf-v2-20260909');out=root/'shadowmap-temporal-review';out.mkdir(exist_ok=True)
folders={'trace':root/'current-motion/gold-reference','maps':root/'shadowmap-native-motion1024/gold-reference'}
states={key:[json.loads(line) for line in (path/'state.jsonl').read_text().splitlines()] for key,path in folders.items()}
matching=[]
for a,b in zip(states['trace'],states['maps']):
 matching.append(all(a.get(k)==b.get(k) for k in ['frame_index','playback_ms','simulation_ms','presentation_motion','creature','view']))
print('equal state frames',sum(matching),'of',len(matching))
# Lossy videos use the captured native1280x720 resolution. Retain the distinction
# between video errors and direct framebuffer oracle errors in the report.
regions={'face':(550,224,714,324),'plant_contact':(365,445,485,525)}
report={'native_video_size':[1280,720],'video_codec':'H264 yuv420p, differences include independent compression','matching_state_frames':sum(matching),'compared_state_frames':len(matching),'regions':{}}
for region,(x0,y0,x1,y1) in regions.items():
 w,h=x1-x0,y1-y0;frames={}
 for key,path in folders.items():
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path/'session.mp4'),'-t','2','-vf',f'crop={w}:{h}:{x0}:{y0}','-f','rawvideo','-pix_fmt','rgb24','-'])
  frames[key]=[Image.frombytes('RGB',(w,h),raw[i:i+w*h*3]) for i in range(0,len(raw),w*h*3)]
 offsets={}
 for offset in range(-3,4):
  scores=[sum(ImageStat.Stat(ImageChops.difference(frames['trace'][i],frames['maps'][i+offset])).mean)/3 for i in range(3,len(frames['trace'])-3)]
  offsets[offset]=sum(scores)/len(scores)
 print(region,'temporal alignment',offsets)
 metrics=[]
 for i,(a,b) in enumerate(zip(frames['trace'],frames['maps'])):
  dif=ImageChops.difference(a,b);values=list(dif.getdata());metrics.append({'frame':i,'max_rgb_error':max(max(p) for p in values),'mean_abs_rgb_error':sum(sum(p) for p in values)/(w*h*3)})
 worst=max(metrics,key=lambda v:v['mean_abs_rgb_error'])['frame'];start=max(0,min(worst-4,len(metrics)-12))
 for scale in [1,4]:
  tilew=w*scale;tileh=h*scale+14;sheet=Image.new('RGB',(tilew*4,tileh*6));draw=ImageDraw.Draw(sheet)
  for n,frame in enumerate(range(start,start+12)):
   col=n%4;row=(n//4)*2
   for j,key in enumerate(['trace','maps']):
    px=col*tilew;py=(row+j)*tileh;draw.text((px,py),f'{key} frame{frame}',fill='white');sheet.paste(frames[key][frame].resize((tilew,h*scale),Image.Resampling.NEAREST),(px,py+14))
  sheet.save(out/f'{region}-consecutive-{scale}x.png')
 report['regions'][region]={'crop':[x0,y0,x1,y1],'offset_mean_rgb_errors':offsets,'worst_mean_frame':worst,'sequence_start':start,'metrics':metrics}
(out/'temporal-video-metrics.json').write_text(json.dumps(report,indent=2))
