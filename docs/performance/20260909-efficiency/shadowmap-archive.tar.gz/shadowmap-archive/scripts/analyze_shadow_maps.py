import json,statistics,math
from pathlib import Path
root=Path('/tmp/beastie-perf-v2-20260909');rows=[]
for name in ['shadowmap-batch10-control-before','shadowmap-batch10-512','shadowmap-batch10-1024','shadowmap-batch10-2048','shadowmap-batch10-control-after']:
 x=json.loads((root/(name+'.json')).read_text());t=x['timing_validation'];p=t['raw_timestamp_pairs'];ns=t['timestamp_period_ns']/1e6
 assert len(p)==210 and not t['invalid_samples']
 chunks=[];warm=[]
 for start in range(0,210,10):
  pairs=p[start:start+10];envelope=(max(v[1] for v in pairs)-min(v[0] for v in pairs))*ns
  cadence=[(pairs[i][1]-pairs[i-1][1])*ns for i in range(1,10)]
  chunks.append({'first_frame':start,'frames':10,'warmup':start<30,'gpu_envelope_ms':envelope,'gpu_envelope_per_frame_ms':envelope/10,'within_chunk_completion_intervals_ms':cadence})
  if start>=30:warm+=cadence
 s=sorted(warm)
 row={'variant':name,'whole_envelope_div210_ms':t['gpu_envelope_ms']/210,'sum_chunk_envelopes_div210_ms':sum(c['gpu_envelope_ms'] for c in chunks)/210,'warm_sum_chunk_envelopes_div180_ms':sum(c['gpu_envelope_ms'] for c in chunks if not c['warmup'])/180,'warm_intra_batch_completion_median_ms':statistics.median(s),'warm_intra_batch_completion_p95_ms':s[math.ceil(len(s)*.95)-1],'warm_intervals':len(s),'invalid_timestamps':len(t['invalid_samples']),'image_difference':x['shadow_cache']['reference_comparison'],'shadow_maps':x['dynamic_shadow_maps'],'chunks':chunks}
 rows.append(row)
 print(name,'sumchunks/210',round(row['sum_chunk_envelopes_div210_ms'],6),'warmchunks/180',round(row['warm_sum_chunk_envelopes_div180_ms'],6),'warmcadence',round(row['warm_intra_batch_completion_median_ms'],6),'p95',round(row['warm_intra_batch_completion_p95_ms'],6),'diff',row['image_difference']['different_rgb_pixels'])
(root/'shadowmap-summary.json').write_text(json.dumps({'measurement':'21bounded batches of10frames. Sum perchunk GPU envelopes excludes CPU gaps but includes withinchunk fill/drain. Warm intrabatch completion cadence excludes warmupframes0..29 and all interbatch boundaries. Whole envelope/210 includes interbatch GPUwait/readback/CPUrecording gaps and is not a GPU-only cost. Everyframe includes all12dynamic shadow depth passes,primaryvisibility raster andcompute.','runs':rows},indent=2))
