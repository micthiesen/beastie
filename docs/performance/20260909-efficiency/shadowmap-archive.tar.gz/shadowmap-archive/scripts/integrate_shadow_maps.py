from pathlib import Path
b=Path(__file__).resolve().parent/'crates/beastie-game/src';assert '/shadowmap-src/' in str(b)
p=b/'main.rs';s=p.read_text();s=s.replace('#[cfg(test)]\nmod ray_benchmark;','#[cfg(test)]\nmod ray_benchmark;\n#[cfg(test)]\nmod ray_shadow_maps;');p.write_text(s)
p=b/'raytrace.rs';s=p.read_text();a='    let source = include_str!("raytrace.wgsl");';assert s.count(a)==1;s=s.replace(a,'''    // Shadow-map upload is currently wired only to the explicit benchmark.
    let source = if cfg!(test) { include_str!("raytrace.wgsl") }
        else { include_str!("raytrace_original_reference.wgsl") };''');p.write_text(s)
p=b/'raytrace.wgsl';s=p.read_text();a='struct Hit {';assert s.count(a)==1;s=s.replace(a,'''struct ShadowMapParams { clip_from_world:array<mat4x4<f32>,12>, depth_ranges:array<vec4<f32>,12>, info:vec4<u32> }
@group(0) @binding(10) var dynamic_shadow_maps:texture_depth_2d_array;
@group(0) @binding(11) var<uniform> shadow_map_params:ShadowMapParams;
'''+a)
a='fn lighting(';assert s.count(a)==1;s=s.replace(a,'''fn dynamic_shadow_blocked(origin:vec3<f32>,light:vec3<f32>,sample:u32) -> bool {
    if(shadow_map_params.info.x==0u) {
        return trace_root(origin,light,35.0,true,true,params.shadow_roots.y).instance!=0xffffffffu;
    }
    if(shadow_map_params.info.w==0u) { return false; }
    let clip=shadow_map_params.clip_from_world[sample]*vec4(origin,1.0);
    // Outside the fitted projection of all dynamic caster bounds, no caster can
    // intersect this directional ray. Receivers may legitimately lie below z=0.
    if(abs(clip.x)>1.0 || abs(clip.y)>1.0) { return false; }
    let uv=vec2(clip.x*0.5+0.5,0.5-clip.y*0.5);
    let size=i32(shadow_map_params.info.y);
    let pixel=clamp(vec2<i32>(floor(uv*f32(size))),vec2(0),vec2(size-1));
    let depth=textureLoad(dynamic_shadow_maps,pixel,i32(sample),0);
    if(depth==0.0) { return false; }
    let range=shadow_map_params.depth_ranges[sample];
    let distance=(depth-clip.z)*range.y/range.z;
    // A one-layer shadow map cannot resolve a closer blocker hidden behind a
    // blocker beyond the ray limit. Keep exact traversal for that uncommon case.
    if(distance>=35.0) {
        return trace_root(origin,light,35.0,true,true,params.shadow_roots.y).instance!=0xffffffffu;
    }
    return distance>0.0001;
}

'''+a)
a='blocked=trace_root(origin,light,35.0,true,true,params.shadow_roots.y).instance!=0xffffffffu;';assert s.count(a)==1;s=s.replace(a,'blocked=dynamic_shadow_blocked(origin,light,s);')
a='''            } else {
                blocked=trace(origin,light,35.0,true,true).instance!=0xffffffffu;
            }''';assert s.count(a)==1;s=s.replace(a,'''            } else {
                if(shadow_map_params.info.x!=0u) {
                    blocked=trace_root(origin,light,35.0,true,true,params.shadow_roots.x).instance!=0xffffffffu;
                    if(!blocked) { blocked=dynamic_shadow_blocked(origin,light,s); }
                } else {
                    blocked=trace(origin,light,35.0,true,true).instance!=0xffffffffu;
                }
            }''');p.write_text(s)
p=b/'ray_benchmark.rs';s=p.read_text();a='    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {';assert s.count(a)==1;s=s.replace(a,'''    let shadow_resolution=std::env::var("BEASTIE_SHADOW_MAP_SIZE").ok().map(|v|v.parse::<u32>().expect("shadow map size")).unwrap_or(1024);
    let shadow_map_enabled=std::env::var("BEASTIE_SHADOW_MAP_CONTROL").as_deref()!=Ok("trace");
    let (map_params,shadow_casters)=crate::ray_shadow_maps::fit(scene,shadow_resolution,shadow_map_enabled);
    let map_uniform=device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some("dynamic shadow projections"),contents: &encoded(&map_params),
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
    });
    let map_texture=device.create_texture(&wgpu::TextureDescriptor {
        label: Some("twelve dynamic shadow directions"),
        size: wgpu::Extent3d {width:shadow_resolution,height:shadow_resolution,depth_or_array_layers:12},
        mip_level_count:1,sample_count:1,dimension:wgpu::TextureDimension::D2,format:wgpu::TextureFormat::Depth32Float,
        usage:wgpu::TextureUsages::RENDER_ATTACHMENT|wgpu::TextureUsages::TEXTURE_BINDING,view_formats:&[],
    });
    let map_view=map_texture.create_view(&wgpu::TextureViewDescriptor {
        dimension:Some(wgpu::TextureViewDimension::D2Array),aspect:wgpu::TextureAspect::DepthOnly,..Default::default()
    });
    let map_layer_views:Vec<_>=(0..12).map(|index|map_texture.create_view(&wgpu::TextureViewDescriptor {
        dimension:Some(wgpu::TextureViewDimension::D2),aspect:wgpu::TextureAspect::DepthOnly,
        base_array_layer:index,array_layer_count:Some(1),..Default::default()
    })).collect();
    let map_pipeline=device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label:Some("exact dynamic caster depth"),layout:None,
        vertex:wgpu::VertexState {module:&visibility_shader,entry_point:Some("visibility_vertex"),compilation_options:Default::default(),buffers:&[]},
        fragment:None,primitive:wgpu::PrimitiveState {cull_mode:None,..Default::default()},
        depth_stencil:Some(wgpu::DepthStencilState {format:wgpu::TextureFormat::Depth32Float,depth_write_enabled:Some(true),depth_compare:Some(wgpu::CompareFunction::Greater),stencil:Default::default(),bias:Default::default()}),
        multisample:Default::default(),multiview_mask:None,cache:None,
    });
    let map_matrices:Vec<_>=map_params.clip_from_world.iter().map(|matrix|device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label:Some("one shadow projection"),contents:&encoded(matrix),usage:wgpu::BufferUsages::UNIFORM,
    })).collect();
    let map_binds:Vec<_>=map_matrices.iter().map(|matrix|device.create_bind_group(&wgpu::BindGroupDescriptor {
        label:None,layout:&map_pipeline.get_bind_group_layout(0),entries:&[
            wgpu::BindGroupEntry {binding:0,resource:buffers[0].as_entire_binding()},
            wgpu::BindGroupEntry {binding:1,resource:buffers[2].as_entire_binding()},
            wgpu::BindGroupEntry {binding:2,resource:matrix.as_entire_binding()},
        ],
    })).collect();
'''+a)
a='    let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {';assert s.count(a)==1;s=s.replace(a,'''    entries.push(wgpu::BindGroupEntry {binding:10,resource:wgpu::BindingResource::TextureView(&map_view)});
    entries.push(wgpu::BindGroupEntry {binding:11,resource:map_uniform.as_entire_binding()});
'''+a)
a='    let measurements = measure_frames(&device, &queue, |encoder, queries, query_index| {';assert s.count(a)==1;s=s.replace(a,a+'''
        if shadow_map_enabled {
            for layer in 0..12 {
                let mut pass=encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label:Some("dynamic shadow depth"),color_attachments:&[],
                    depth_stencil_attachment:Some(wgpu::RenderPassDepthStencilAttachment {
                        view:&map_layer_views[layer],depth_ops:Some(wgpu::Operations {load:wgpu::LoadOp::Clear(0.0),store:wgpu::StoreOp::Store}),stencil_ops:None,
                    }),
                    timestamp_writes:if layer==0 {Some(wgpu::RenderPassTimestampWrites {query_set:queries,beginning_of_pass_write_index:Some(query_index),end_of_pass_write_index:None})}else{None},
                    occlusion_query_set:None,multiview_mask:None,
                });
                pass.set_pipeline(&map_pipeline);pass.set_bind_group(0,&map_binds[layer],&[]);
                for &index in &shadow_casters {
                    let instance=scene.instances[index];
                    let chunk=scene.geometry.iter().find(|chunk|chunk.node_offset==instance.root).expect("shadow mesh range");
                    pass.draw(chunk.triangle_offset*3..(chunk.triangle_offset+chunk.triangles.len() as u32)*3,index as u32..index as u32+1);
                }
            }
        }''')
a='beginning_of_pass_write_index: Some(query_index),';assert s.count(a)==1;s=s.replace(a,'beginning_of_pass_write_index: if shadow_map_enabled {None}else{Some(query_index)},')
a='    let mut reference_params = params;';assert s.count(a)==1;s=s.replace(a,'''    let mut reference_maps=map_params.clone();reference_maps.info.x=0;
    queue.write_buffer(&map_uniform,0,&encoded(&reference_maps));
'''+a)
a='        "gpu_pass_latency_samples_ms_sorted": timings,';assert s.count(a)==1;s=s.replace(a,'''        "dynamic_shadow_maps": {"enabled":shadow_map_enabled,"resolution":shadow_resolution,"layers":12,"caster_instances":shadow_casters.len(),
            "depth_bytes":u64::from(shadow_resolution)*u64::from(shadow_resolution)*12*4,"uniform_bytes":encoded(&map_params).len()+12*64,
            "measurement_includes_all_twelve_depth_passes":true,"reference":"same shader,original shadow rays,static caches disabled"},
'''+a);p.write_text(s)
