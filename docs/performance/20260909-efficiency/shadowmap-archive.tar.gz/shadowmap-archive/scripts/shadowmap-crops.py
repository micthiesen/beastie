from pathlib import Path
from PIL import Image,ImageChops,ImageEnhance,ImageDraw

base=Path('/tmp/beastie-perf-v2-20260909')
for size in [1024,2048]:
 root=base/f'shadowmap-motion{size}'
 for stem in ['00-cold','02-creature-left-low','04-carried-ball','06-ball-right-plant-sway','08-title']:
  ap=root/f'{stem}-maps.png';bp=root/f'{stem}-trace.png'
  a=Image.open(ap).convert('RGB');b=Image.open(bp).convert('RGB');d=ImageChops.difference(a,b); index,pixel=max(enumerate(d.getdata()),key=lambda item:max(item[1])); y,x=divmod(index,a.width); maximum=max(pixel)
  bounds=(max(0,x-48),max(0,y-48),min(a.width,x+48),min(a.height,y+48));out=Image.new('RGB',(576,300));out.paste(b.crop(bounds).resize((288,288)),(0,12));out.paste(a.crop(bounds).resize((288,288)),(288,12));ImageDraw.Draw(out).text((0,0),f'trace | maps{size}, center {x},{y}, max {maximum}',fill='white');out.save(root/f'{stem}-worst-pair.png')
  ImageEnhance.Brightness(ImageChops.difference(a,b)).enhance(4).save(root/f'{stem}-diff4.png')
  print(size,stem,x,y,int(maximum))
